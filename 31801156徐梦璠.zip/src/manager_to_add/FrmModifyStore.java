package manager_to_add;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import cn.edu.zucc.takeout.PersonPlanUtil;
import cn.edu.zucc.takeout.model.BeanStore;
import cn.edu.zucc.takeout.ui.FrmLogin;
import cn.edu.zucc.takeout.util.BaseException;
import cn.edu.zucc.takeout.util.DbException;


public class FrmModifyStore extends JDialog implements ActionListener {
private JPanel toolBar = new JPanel();
private JPanel workPane = new JPanel();
private Button btnOk = new Button("ȷ��");
private Button btnCancel = new Button("ȡ��");


private JLabel store_id = new JLabel("*�̼ұ�� ��  ");
private JLabel store_name = new JLabel("*�̼��� ��  ");
private JLabel store_level= new JLabel("*�̼��Ǽ���");
private JLabel store_per_consumption = new JLabel("*�˾����ѣ�");
private JLabel store_totalsales = new JLabel("*��������");
private JTextField edtstore_id = new JTextField(18);
private JTextField edtstore_name = new JTextField(18);
private JTextField edtstore_level = new JTextField(18);
private JTextField edtstore_per_consumption = new JTextField(18);
private JTextField edtstore_totalsales= new JTextField(18);
private FrmLogin dlgLogin=null;
public FrmModifyStore(Frame f, String s, boolean b,FrmLogin dlgLogin) {
	super(f, s, b);
	this.dlgLogin=dlgLogin;
	toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
	toolBar.add(this.btnOk);
	toolBar.add(btnCancel);
	this.getContentPane().add(toolBar, BorderLayout.SOUTH);
	workPane.add(store_id);
	workPane.add(edtstore_id);
	workPane.add(store_name);
	workPane.add(edtstore_name);
	workPane.add(store_level);
	workPane.add(edtstore_level);
	workPane.add(store_per_consumption);
	workPane.add(edtstore_per_consumption);
	workPane.add(store_totalsales);
	workPane.add(edtstore_totalsales);
	this.getContentPane().add(workPane, BorderLayout.CENTER);
	this.setSize(220, 500);
	
	// ��Ļ������ʾ
			double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
			double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
			this.setLocation((int) (width - this.getWidth()) / 2,
					(int) (height - this.getHeight()) / 2);
			
	this.btnCancel.addActionListener(this);
	this.btnOk.addActionListener(this);
}
@Override
public void actionPerformed(ActionEvent e) {
	if(e.getSource()==this.btnCancel)
		this.setVisible(false);
	else if(e.getSource()==this.btnOk){
		try {
			PersonPlanUtil.StoreManager.addStore(edtstore_name.getText(),edtstore_level.getText(),
					edtstore_per_consumption.getText(),edtstore_totalsales.getText());
		} catch (DbException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (BaseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		this.setVisible(false);
	}	
	
}


}

