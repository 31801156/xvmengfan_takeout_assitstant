
package manager_to_add;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.sql.Timestamp;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import cn.edu.zucc.takeout.PersonPlanUtil;
import cn.edu.zucc.takeout.model.BeanRider;
import cn.edu.zucc.takeout.model.BeanUser;
import cn.edu.zucc.takeout.ui.FrmLogin;
import cn.edu.zucc.takeout.util.BaseException;

public class FrmModifyRider extends JDialog implements ActionListener {
	private JPanel toolBar = new JPanel();
	private JPanel workPane = new JPanel();
	private Button btnOk = new Button("����");
	private Button btnCancel = new Button("ȡ��");
	
	private JLabel labelrider_name = new JLabel("*����������");
	private JLabel labelrider_entrydate = new JLabel("*��ְ���ڣ�");
	private JLabel labelrider_identity = new JLabel("*�������ݣ�");
	private JLabel labelrider_com = new JLabel("*��ɶ�������");
	private JTextField edtrider_name = new JTextField(20);
	private JTextField edtrider_entrydate = new JTextField(20);
	private JTextField edtrider_identity = new JTextField(20);
	private JTextField edtrider_com = new JTextField(20);
	
	public FrmModifyRider(Frame f, String s, boolean b,FrmLogin dlgLogin) {
		super(f, s, b);
		toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
		toolBar.add(this.btnOk);
		toolBar.add(btnCancel);
		this.getContentPane().add(toolBar, BorderLayout.SOUTH);
		workPane.add(labelrider_name);
		workPane.add(edtrider_name);
		workPane.add(labelrider_identity);
		workPane.add(edtrider_identity);
		workPane.add(labelrider_entrydate);
		workPane.add(edtrider_entrydate);
		workPane.add(labelrider_com);
		workPane.add(edtrider_com);
		this.getContentPane().add(workPane, BorderLayout.CENTER);
		this.setSize(350,180);
		
		// ��Ļ������ʾ
				double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
				double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
				this.setLocation((int) (width - this.getWidth()) / 2,
						(int) (height - this.getHeight()) / 2);
				
		this.btnCancel.addActionListener(this);
		this.btnOk.addActionListener(this);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.btnCancel)
			this.setVisible(false);
		if(e.getSource()==this.btnOk){
			String rider_name=this.edtrider_name.getText();
			Timestamp rider_entrydate=Timestamp.valueOf(this.edtrider_entrydate.getText());
			String rider_identity=this.edtrider_identity.getText();
			int com=Integer.parseInt(this.edtrider_com.getText());
			
			try {
				PersonPlanUtil.RiderManager.addRider(rider_name,rider_entrydate,rider_identity,com);
				this.setVisible(false);
			} catch (BaseException e1) {
				JOptionPane.showMessageDialog(null, e1.getMessage(),"����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			
		}

	}


}


