package cn.edu.zucc.takeout.model;


import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

public class BeanUser {
	public final static String[] tableTitles={"�û����","����","�Ա�","����","�ֻ�����",
			"����","���ڳ���","ע��ʱ��","�Ƿ��Ա"};
	public static  BeanUser currentLoginUser=null;
    private int user_id;
    private String user_name;
    private String sex;
    private String password;
    private String phonenumber;
    private String email;
    private String city;
    private Timestamp registration_time;
    private int member;
    public int getUser_id() {
    	return user_id;
    }
	public void setUser_id(int user_id) {
		this.user_id=user_id;
		
	}//
    public String getUser_name() {
    	return user_name;
    }
	public void setUser_name(String user_name) {
		this.user_name=user_name;
		
	}//
    public String getSex() {
    	return sex;
    }
	public void setSex(String sex) {
		this.sex=sex;
		
	}//
    public String getPassword() {
    	return password;
    }
	public void setPassword(String password) {
		this.password=password;
		
	}//
    public String getPhonenumber() {
    	return phonenumber;
    }
	public void setPhonenumber(String phonenumber) {
		this.phonenumber=phonenumber;
		
	}//
    public String getEmail() {
    	return email;
    }
	public void setEmail(String email) {
		this.email=email;
		
	}//
    public String getCity() {
    	return city;
    }
	public void setCity(String city) {
		this.city=city;
		
	}//
	public Timestamp getRegistration_time() {
		return registration_time; 
	}
	public void setRegistration_time(Timestamp registration_time) {
		this.registration_time=registration_time;
		
	}
	public int getMember() {
		return member; 
	}
	public void setMember(int member) {
		this.member=member;
		
	}
		public String getCell(int col){
			if(col==0) return Integer.toString(this.user_id);
			else if(col==1) return this.user_name;
			else if(col==2) return this.sex;
			else if(col==3) return this.password;
			else if(col==4) return this.phonenumber;
			else if(col==5) return this.email;
			else if(col==6) return this.city;
			else if(col==7) return new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(this.registration_time);
			else if(col==8) return Integer.toString(this.member);
			else return "";
		}
	}
