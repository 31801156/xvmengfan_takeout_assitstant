package cn.edu.zucc.takeout.model;

public class BeanStore {
	public final static String[] tableTitles={"�̼ұ��","�̼���","�̼��Ǽ�",
			"�˾�����","������"};
	    private int store_id;
	    private String store_name;
	    private double store_level;
	    private int store_per_consumption;
	    private int store_totalsales;

	    public int getStore_id() {
	    	return store_id;
	    }
		public void setStore_id(int store_id) {
			this.store_id=store_id;
			
		}//
	    public String getStore_name() {
	    	return store_name;
	    }
		public void setStore_name(String store_name) {
			this.store_name=store_name;
			
		}//
	    public double getStore_level() {
	    	return store_level;
	    }
		public void setStore_level(double store_level) {
			this.store_level=store_level;
			
		}//
	    public double getStore_per_consumption() {
	    	return store_per_consumption;
	    }
		public void setStore_per_consumption(int store_per_consumption) {
			this.store_per_consumption=store_per_consumption;
			
		}//
	    public double getStore_totalsales() {
	    	return store_totalsales;
	    }
		public void setStore_totalsales(int store_totalsales) {
			this.store_totalsales=store_totalsales;
			
		}//
	public String getCell(int col){
		if(col==0) return Integer.toString(this.store_id);
		else if(col==1) return this.store_name;
		else if(col==2) return Double.toString(this.store_level);
		else if(col==3) return Integer.toString(this.store_per_consumption);
		else if(col==4) return Integer.toString(this.store_totalsales);
		else return "";
	}

}


