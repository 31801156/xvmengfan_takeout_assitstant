package cn.edu.zucc.takeout.model;

import java.sql.Struct;
import java.util.List;

public class BeanAddress {
	public static final String[] tableTitles={"��ַ���","�û����","ʡ","��","��","��ַ","��ϵ��","�绰"};
	public BeanUser currentLoginUser=null;    
	private int address_id;
	private int user_id;
	private String province;
	private String city;
	private String area;
	    private String address;
	    private String user_name;
	    private String phonenumber;
	    public int getAddress_id() {
	    	return address_id;
	    }
		public void setAddress_id(int address_id) {
			this.address_id=address_id;
			
		}//
	    public int getUser_id() {
	    	return user_id;
	    }
		public void setUser_id(int user_id) {
			this.user_id=user_id;
			
		}//
	    public String getProvince() {
	    	return province;
	    }
		public void setProvince(String province) {
			this.province=province;
			
		}//
	    public String getCity() {
	    	return city;
	    }
		public void setCity(String city) {
			this.city=city;
			
		}//
	    public String getArea() {
	    	return area;
	    }
		public void setArea(String area) {
			this.area=area;
			
		}//
	    public String getAddress() {
	    	return address;
	    }
		public void setAddress(String address) {
			this.address=address;	
		}//
	    public String getUser_name() {
	    	return user_name;
	    }
		public void setUser_name(String user_name) {
			this.user_name=user_name;
			
		}//
	    public String getPhonenumber() {
	    	return phonenumber;
	    }
		public void setPhonenumber(String phonenumber) {
			this.phonenumber=phonenumber;
			
		}//
	public String getCell(int col){
		if(col==0) return Integer.toString(this.address_id);
		else if(col==1) return Integer.toString(this.user_id);
		else if(col==2) return this.province;
		else if(col==3) return this.city;
		else if(col==4) return this.area;
		else if(col==5) return this.address;
		else if(col==6) return this.user_name;
		else if(col==7) return this.phonenumber;
		else return "";
	}

}


