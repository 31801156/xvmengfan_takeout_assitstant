package cn.edu.zucc.takeout.model;

import java.sql.Date;
import java.sql.Struct;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.List;

public class BeanUserconpon {
	public final static String[] tableTitles={"�û����","�Ż�ȯ���","�����̼ұ��","�Żݽ��","����","��ֹ����"};
	    private int user_id;
	    private int coupon_id;
	    private int store_id;
	    private int coupon_money;
	    private int coupon_count;
	    private Timestamp coupon_end_time;
	    
	    public int getUser_id() {
	    	return user_id;
	    }
		public void setUser_id(int user_id) {
			this.user_id=user_id;
			
		}//
	    public int getCoupon_id() {
	    	return coupon_id;
	    }
		public void setCoupon_id(int coupon_id) {
			this.coupon_id=coupon_id;
			
		}//
	    public int getStore_id() {
	    	return store_id;
	    }
		public void setStore_id(int store_id) {
			this.store_id=store_id;
			
		}//
	    public int getCoupon_money() {
	    	return coupon_money;
	    }
		public void setCoupon_money(int coupon_money) {
			this.coupon_money=coupon_money;
			
		}//
	    public int getCoupon_count() {
	    	return coupon_count;
	    }
		public void setCoupon_count(int coupon_count) {
			this.coupon_count=coupon_count;
			
		}//
	    public Timestamp getCoupon_end_time() {
	    	return coupon_end_time;
	    }
		public void setCoupon_end_time(Timestamp coupon_end_time) {
			this.coupon_end_time=coupon_end_time;
			
		}//
	public String getCell(int col){
		if(col==0) return Integer.toString(this.user_id);
	    else if(col==1) return Integer.toString(this.coupon_id);
	    else if(col==2) return Integer.toString(this.store_id);
		else if(col==3) return Integer.toString(this.coupon_money);
		else if(col==4) return Integer.toString(this.coupon_count);
		else if(col==5) return new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(this.coupon_end_time);
		else return "";
	}

}


