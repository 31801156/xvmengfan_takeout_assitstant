package cn.edu.zucc.takeout.model;

import java.sql.Struct;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class BeanShoppingcart{
	public static final String[] tableTitles={"�̼ұ��","��Ʒ���","������","�û����","���빺�ﳵʱ��"};
	    private int store_id;
	    private int goods_id;
	    private int type_id;
	    private int user_id;
	    private Timestamp time;
	    
	    public int getStore_id() {
	    	return store_id;
	    }
		public void setStore_id(int store_id) {
			this.store_id=store_id;
			
		}//
	    public int getGoods_id() {
	    	return goods_id;
	    }
		public void setGoods_id(int goods_id) {
			this.goods_id=goods_id;
			
		}//
	    public int getType_id() {
	    	return type_id;
	    }
		public void setType_id(int type_id) {
			this.type_id=type_id;
			
		}//
	    public int getUser_id() {
	    	return user_id;
	    }
		public void setUser_id(int user_id) {
			this.user_id=user_id;
			
		}//
		  public Timestamp getTime() {
		    	return time;
		    }
			public void setTime(Timestamp time) {
				this.time=time;
				
			}//

	public String getCell(int col){
		if(col==0) return Integer.toString(this.store_id);
		else if(col==1) return Integer.toString(this.goods_id);
		else if(col==2) return Integer.toString(this.type_id);
		else if(col==3) return Integer.toString(this.user_id);
		else if(col==4) return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(this.time);
		else return "";
	}


}


