package cn.edu.zucc.takeout.model;

import java.sql.Struct;
import java.util.List;

public class BeanOrder_conpon {
	public final static String[] tableTitles={"�û����","�̼ұ��","�Ż�ȯ���","����Ҫ����","�Ѷ�����"};
	    private int user_id;
	    private int store_id;
	    private int conpon_id;
	    private int conpon_require_number;
	    private int ordercount;

	    public int getUser_id() {
	    	return user_id;
	    }
		public void setUser_id(int user_id) {
			this.user_id=user_id;
			
		}//
	    public int getStore_id() {
	    	return store_id;
	    }
		public void setStore_id(int store_id) {
			this.store_id=store_id;
			
		}//
	    public int getConpon_id() {
	    	return conpon_id;
	    }
		public void setConpon_id(int conpon_id) {
			this.conpon_id=conpon_id;
			
		}//
	    public int getConpon_require_number() {
	    	return conpon_require_number;
	    }
		public void setConpon_require_number(int conpon_require_number) {
			this.conpon_require_number=conpon_require_number;
			
		}//
	    public int getOrdercount() {
	    	return ordercount;
	    }
		public void setOrdercount(int ordercount) {
			this.ordercount=ordercount;
			
		}//
	public String getCell(int col){
		if(col==0) return Integer.toString(this.user_id);
		else if(col==1) return Integer.toString(this.store_id);
		else if(col==2) return Integer.toString(this.conpon_id);
		else if(col==3) return Integer.toString(this.conpon_require_number);
		else if(col==4) return Integer.toString(this.ordercount);
		else return "";
	}

}


