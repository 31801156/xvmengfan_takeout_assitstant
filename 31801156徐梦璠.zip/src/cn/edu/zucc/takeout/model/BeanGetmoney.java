
	package cn.edu.zucc.takeout.model;

	import java.sql.Struct;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
	import java.util.Date;
	import java.util.List;

	public class BeanGetmoney{
		public static final String[] tableTitles={"���ֱ��","���Ӷ������","ʱ��",
				"�û�����","��������","��������"};
		    private int rider_id;
		    private int order_id;
		    private Timestamp gettime;
		    private String user_access;
		    private double income;
		    private String assesscontent;
		    
		    public int getRider_id() {
		    	return rider_id;
		    }
			public void setRider_id(int rider_id) {
				this.rider_id=rider_id;
				
			}//
		    public int getOrder_id() {
		    	return order_id;
		    }
			public void setOrder_id(int order_id) {
				this.order_id=order_id;
				
			}//
		    public Timestamp getGettime() {
		    	return gettime;
		    }
			public void setGettime(Timestamp gettime) {
				this.gettime=gettime;
				
			}//
		    public String getUser_access() {
		    	return user_access;
		    }
			public void setUser_access(String user_access) {
				this.user_access=user_access;
				
			}//
		    public double getIncome() {
		    	return income;
		    }
			public void setIncome(double income) {
				this.income=income;
				
			}//
		    public String getAssesscontent() {
		    	return assesscontent;
		    }
			public void setAssesscontent(String assesscontent) {
				this.assesscontent=assesscontent;
				
			}//
		public String getCell(int col){
			if(col==0) return Integer.toString(this.rider_id);
			else if(col==1) return Integer.toString(this.order_id);
			else if(col==2) return new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(this.gettime);
			else if(col==3) return this.user_access;
			else if(col==4) return Double.toString(this.income);
			else if(col==5) return this.assesscontent;
			else return "";
		}

	}


