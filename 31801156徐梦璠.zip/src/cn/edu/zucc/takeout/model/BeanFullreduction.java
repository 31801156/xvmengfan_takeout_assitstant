
package cn.edu.zucc.takeout.model;

import java.sql.Struct;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class BeanFullreduction{
	public static final String[] tableTitles={"�������","�������","�Żݽ��","�Ƿ�����Ż�ȯ����"};
	    private int fullreduction_id;
	    private int fullreduction_money;
	    private int reduction_money;
	    private int with_coupon;
	    
	    public int getFullreduction_id() {
	    	return fullreduction_id;
	    }
		public void setFullreduction_id(int fullreduction_id) {
			this.fullreduction_id=fullreduction_id;
			
		}//
	    public int getFullreduction_money() {
	    	return fullreduction_money;
	    }
		public void setFullreduction_money(int fullreduction_money) {
			this.fullreduction_money=fullreduction_money;
			
		}//
	    public int getReduction_money() {
	    	return reduction_money;
	    }
		public void setReduction_money(int reduction_money) {
			this.reduction_money=reduction_money;
			
		}//
	    public int getWith_coupon() {
	    	return with_coupon;
	    }
		public void setWith_coupon(int with_coupon) {
			this.with_coupon=with_coupon;
			
		}//

	public String getCell(int col){
		if(col==0) return Integer.toString(this.fullreduction_id);
		else if(col==1) return Integer.toString(this.fullreduction_money);
		else if(col==2) return Integer.toString(this.reduction_money);
		else if(col==3) return Double.toString(this.with_coupon);
		else return "";
	}

}


