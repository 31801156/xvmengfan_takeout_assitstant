package cn.edu.zucc.takeout.model;

import java.sql.Struct;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class BeanGooddetails{
	public static final String[] tableTitles={"��Ʒ���","����������","��Ʒ��",
			"�۸�","�Żݼ۸�","��Ʒ����"};
	    private int goods_id;
	    private int type_id;
	    private String goods_name;
	    private double goods_money;
	    private double coupon_money;
	    private int goods_count;
	    public int getGoods_id() {
	    	return goods_id;
	    }
		public void setGoods_id(int goods_id) {
			this.goods_id=goods_id;
			
		}//
	    public int getType_id() {
	    	return type_id;
	    }
		public void setType_id(int type_id) {
			this.type_id=type_id;
			
		}//
	    public String getGoods_name() {
	    	return goods_name;
	    }
		public void setGoods_name(String goods_name) {
			this.goods_name=goods_name;
			
		}//
	    public double getGoods_money() {
	    	return goods_money;
	    }
		public void setGoods_money(double goods_money) {
			this.goods_money=goods_money;
			
		}//
	    public double getCoupon_money() {
	    	return coupon_money;
	    }
		public void setCoupon_money(double coupon_money) {
			this.coupon_money=coupon_money;
			
		}//
		 public int getGoods_count() {
		    	return goods_count;
		    }
		public void setGoods_count(int goods_count) {
				this.goods_count=goods_count;
				
			}//
	public String getCell(int col){
		if(col==0) return Integer.toString(this.goods_id);
		else if(col==1) return Integer.toString(this.type_id);
		else if(col==2) return this.goods_name;
		else if(col==3) return Double.toString(this.goods_money);
		else if(col==4) return Double.toString(this.coupon_money);
		else if(col==5) return Integer.toString(this.goods_count);
		else return "";
	}

}


