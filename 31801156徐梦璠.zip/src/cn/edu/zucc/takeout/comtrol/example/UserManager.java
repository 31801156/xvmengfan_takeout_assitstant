package cn.edu.zucc.takeout.comtrol.example;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.JOptionPane;

//�û�����
import cn.edu.zucc.takeout.itf.IUserManager;
import cn.edu.zucc.takeout.model.BeanAddress;
import cn.edu.zucc.takeout.model.BeanGooddetails;
import cn.edu.zucc.takeout.model.BeanGoodsassess;
import cn.edu.zucc.takeout.model.BeanGoodstype;
import cn.edu.zucc.takeout.model.BeanManager;
import cn.edu.zucc.takeout.model.BeanRider;
import cn.edu.zucc.takeout.model.BeanShoppingcart;
import cn.edu.zucc.takeout.model.BeanStore;
import cn.edu.zucc.takeout.model.BeanUser;
import cn.edu.zucc.takeout.model.BeanUserconpon;
import cn.edu.zucc.takeout.util.BaseException;
import cn.edu.zucc.takeout.util.BusinessException;
import cn.edu.zucc.takeout.util.DBUtil;
import cn.edu.zucc.takeout.util.DbException;

public class UserManager implements IUserManager {

	@Override
	//�û�ע��
	public BeanUser reg(String username, String pwd,String pwd2) throws BaseException {
		if(username==null||"".equals(username))
			throw new BusinessException("�û�������Ϊ��");
		if(pwd==null||"".equals(pwd))
			throw new BusinessException("���벻��Ϊ��");
		if(!pwd.equals(pwd2))
			throw new BusinessException("������������벻һ��");
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql= "select user_name from user where user_name=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,username);
			java.sql.ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				rs.close();
				pst.close();
				throw new BusinessException("�û��Ѵ���");
			}
		
			sql="select max(user_id) from user";
			java.sql.Statement st=conn.createStatement();
			rs=st.executeQuery(sql);
			int user_id=0;
			if(rs.next()) {
				user_id=rs.getInt(1)+1;
			}
			else
				user_id=1;

			rs.close();
			st.close();
			
			sql= "insert into user(user_id,user_name,password,registration_time,member) values(?,?,?,?,0)";
			pst=conn.prepareStatement(sql);
			pst.setInt(1,user_id);
			pst.setString(2,username);
			pst.setString(3,pwd);
			pst.setTimestamp(4, new java.sql.Timestamp(System.currentTimeMillis()));
			pst.execute();

			BeanUser user=new BeanUser();
			user.setUser_id(user_id);
			user.setUser_name(username);
			user.setPassword(pwd);
			user.setRegistration_time(new java.sql.Timestamp(System.currentTimeMillis()));
			rs.close();
			pst.close();
			return user;
//			sql="insert into relationship_manager_user(manager_id,user_id) select manager_id,? from manager";
//			pst=conn.prepareStatement(sql);
//			pst.setInt(1,user_id);
//			pst.execute();
			}catch(SQLException ex) {
			throw new DbException(ex);
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}


	
	@Override
	//�û���¼
	public BeanUser login(String username, String pwd) throws BaseException {
		Connection conn=null;
		BeanUser user=null;
		try {
			conn=DBUtil.getConnection();
			int user_id=0;
			String sql= "select user_id,registration_time,password from user where user_name=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,username);
			java.sql.ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				user_id=rs.getInt(1);
				if(!pwd.equals(rs.getString(3))) {
					throw new BusinessException("�������");
				}
				
				rs.close();
				pst.close();
				
				user=new BeanUser();
				user.setUser_id(user_id);
				user.setUser_name(username);
				//user.setRegistration_time(rs.getTimestamp(1));
				user.setPassword(pwd);
				return user;
			}else {
				throw new BusinessException("�û�������");
			}
		}catch(SQLException ex) {
			throw new DbException(ex);
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}


	@Override
	//�޸��û�����
	public void changePwd(BeanUser user, String oldPwd, String newPwd,
			String newPwd2) throws BaseException {
		if(newPwd==null||"".equals(newPwd))
			throw new BusinessException("���벻��Ϊ��");
		if(!oldPwd.equals(user.getPassword()))
			throw new BusinessException("�������������");
		if(!newPwd.equals(newPwd2))
			throw new BusinessException("��������������벻һ��");
		if(oldPwd.equals(newPwd))
			throw new BusinessException("���������������ͬ");
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql= "update user set password=?,registration_time=? where user_name=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,newPwd);
			pst.setTimestamp(2, new java.sql.Timestamp(System.currentTimeMillis()));
			pst.setString(3,user.getUser_name());
			pst.execute();
			user.setRegistration_time(new java.sql.Timestamp(System.currentTimeMillis()));
			user.setUser_name(user.getUser_name());
			user.setUser_id(user.getUser_id());
			user.setPassword(newPwd);
			}catch(SQLException ex) {
			throw new DbException(ex);
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
//@Override
//public void changeName(BeanUser user,String newName) throws BaseException {
//	if(newName==null||"".equals(newName))
//		throw new BusinessException("�û�������Ϊ��");
//	Connection conn=null;
//	try {
//		conn=DBUtil.getConnection();
//		String sql= "update user set user_name=? where user_id=?";
//		java.sql.PreparedStatement pst=conn.prepareStatement(sql);
//		pst.setString(1,newName);
//		pst.setString(2,user.getUser_id());
//		pst.execute();
//		user.setUser_name(newName);
//		user.setUser_id(user.getUser_id());
//		}catch(SQLException ex) {
//		throw new DbException(ex);
//	}finally {
//		if(conn!=null) {
//			try {
//				conn.close();
//			}catch(SQLException e) {
//				e.printStackTrace();
//			}
//		}
//	}
//}
@Override
//�޸��û���Ϣ
public void changeinFormation(String sex, String phonenumber, String email,
		String city, int member) throws DbException, ParseException {
	Connection conn=null;
	BeanUser user=BeanUser.currentLoginUser;
	try {
		conn=DBUtil.getConnection();
		String sql= "update user set sex=?,phonenumber=?,email=?,city=?,member=? where user_name=?";
		java.sql.PreparedStatement pst=conn.prepareStatement(sql);
		pst.setString(1,sex);
		pst.setString(2,phonenumber);
		pst.setString(3,email);
		pst.setString(4,city);
		pst.setInt(5,member);
		pst.setString(6,user.getUser_name());
		pst.execute();
		user.setSex(sex);
		user.setUser_name(user.getUser_name());
		user.setPhonenumber(phonenumber);
		user.setEmail(email);
		user.setCity(city);
		user.setMember(member);
		}catch(SQLException ex) {
		throw new DbException(ex);
	}finally {
		if(conn!=null) {
			try {
				conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
public void changeinFormation2(BeanUser user,String sex, String phonenumber, String email,
		String city, int member) throws DbException, ParseException {
	Connection conn=null;
	try {
		conn=DBUtil.getConnection();
		String sql= "update user set sex=?,phonenumber=?,email=?,city=?,member=? where user_name=?";
		java.sql.PreparedStatement pst=conn.prepareStatement(sql);
		pst.setString(1,sex);
		pst.setString(2,phonenumber);
		pst.setString(3,email);
		pst.setString(4,city);
		pst.setInt(5,member);
		pst.setString(6,user.getUser_name());
		pst.execute();
		user.setSex(sex);
		user.setUser_name(user.getUser_name());
		user.setPhonenumber(phonenumber);
		user.setEmail(email);
		user.setCity(city);
		user.setMember(member);
		}catch(SQLException ex) {
		throw new DbException(ex);
	}finally {
		if(conn!=null) {
			try {
				conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}
}

@Override
//ĳ�û���Ϣ
public List<BeanUser> loadAll() throws BaseException {
	List<BeanUser> result=new ArrayList<BeanUser>();
	Connection conn=null;
	try {
		conn=DBUtil.getConnection();
		String sql="select * from user where user_name=?";
		java.sql.PreparedStatement pst=conn.prepareStatement(sql);
		pst.setString(1,BeanUser.currentLoginUser.getUser_name());
		java.sql.ResultSet rs=pst.executeQuery();
		while(rs.next()) {
			BeanUser p=new BeanUser();
			p.setUser_id(rs.getInt(1));
			p.setUser_name(rs.getString(2));;
			p.setSex(rs.getString(3));
			p.setPassword(rs.getString(4));
			p.setPhonenumber(rs.getString(5));
			p.setEmail(rs.getString(6));
			p.setCity(rs.getString(7));
			p.setRegistration_time(rs.getTimestamp(8));
			p.setMember(rs.getInt(9));
			result.add(p);
		}
		rs.close();
		pst.close();
		conn.close();
		return result;
	}catch(SQLException ex) {
        ex.printStackTrace();
		throw new DbException(ex);
	}finally {
		if(conn!=null) {
			try {
				conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}

	
}
@Override
//�û��б�
public List<BeanUser> loadAll1() throws BaseException {
	List<BeanUser> result=new ArrayList<BeanUser>();
	Connection conn=null;
	try {
		conn=DBUtil.getConnection();
		String sql="select * from user";
		java.sql.Statement st=conn.createStatement();
		java.sql.ResultSet rs=st.executeQuery(sql);
		while(rs.next()) {
			BeanUser p=new BeanUser();
			p.setUser_id(rs.getInt(1));
			p.setUser_name(rs.getString(2));;
			p.setSex(rs.getString(3));
			p.setPassword(rs.getString(4));
			p.setPhonenumber(rs.getString(5));
			p.setEmail(rs.getString(6));
			p.setCity(rs.getString(7));
			p.setRegistration_time(rs.getTimestamp(8));
			p.setMember(rs.getInt(9));
			result.add(p);
		}
		rs.close();
		st.close();
		conn.close();
		return result;
	}catch(SQLException ex) {
        ex.printStackTrace();
		throw new DbException(ex);
	}finally {
		if(conn!=null) {
			try {
				conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}

	
}
@Override
//ɾ��ĳ�û�
public void deleteUser(BeanUser user) throws BaseException, SQLException {
	int user_id=user.getUser_id();
	Connection conn=null;
	try {
		conn=DBUtil.getConnection();
		conn.setAutoCommit(false);
		String sql="select * from goods_order where order_status='������' or order_status='��ʱ' and user_id="+user_id;
		java.sql.Statement st=conn.createStatement();
		java.sql.ResultSet rs=st.executeQuery(sql);
		if(rs.next()){
				throw new BusinessException("���û���δ�����Ķ���������ɾ��");
		}
		rs.close();
		sql="select user_id from user where user_id="+user_id;
		rs=st.executeQuery(sql);
		int user_user_id=0;
		if(rs.next()) {
			user_user_id=rs.getInt(1);
		}else {
			rs.close();
			st.close();
			throw new BusinessException("���û�������");
		}
		rs.close();
		if(!(user.getUser_id()==(user_user_id))){
			st.close();
			throw new BusinessException("����ɾ�������û�");
		}
		sql="delete from user where user_id="+user_id;
		st.execute(sql);
		st.close();
		conn.commit();
	}catch(BaseException e) {
		try {
			conn.rollback();
		}catch(SQLException ex) {
			e.printStackTrace();
		}
		throw e;
	}
	catch(SQLException ex) {
        ex.printStackTrace();
		try {
			conn.rollback();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		throw new DbException(ex);
	}finally {
		if(conn!=null) {
			try {
				conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}
}



@Override
//������Ʒ����
public void addgoodsorder(BeanStore store, BeanGoodstype goodstype, BeanGooddetails gooddetails) throws DbException, BusinessException {
	Connection conn=null;
	try {
		conn=DBUtil.getConnection();
		if(gooddetails.getGoods_count()<1) {
			throw new BusinessException("��治�㣬��ѡ��������Ʒ");
			//JOptionPane.showMessageDialog(null, "��治�㣬��ѡ��������Ʒ", "����",JOptionPane.ERROR_MESSAGE);
		}
		else
			gooddetails.setGoods_count(gooddetails.getGoods_count()-1);
	String sql="insert into shoppingcart(store_id,type_id,goods_id,user_id,time) values(?,?,?,?,?)";
	java.sql.PreparedStatement pst=conn.prepareStatement(sql);
	pst.setInt(1,store.getStore_id());
	pst.setInt(2,goodstype.getType_id());
	pst.setInt(3,gooddetails.getGoods_id());
	pst.setInt(4,BeanUser.currentLoginUser.getUser_id());
	pst.setTimestamp(5,new java.sql.Timestamp(System.currentTimeMillis()));
	pst.execute();
	pst.close();

	
}catch(SQLException ex) {
        ex.printStackTrace();
		throw new DbException(ex);
	}finally {
		if(conn!=null) {
			try {
				conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}

}



@Override
//�µ�
public void placeorder(BeanStore store, BeanGoodstype goodstype, BeanGooddetails gooddetails, int addressid) throws DbException {
	Connection conn=null;
	try {
		conn=DBUtil.getConnection();
		conn.setAutoCommit(false);
		int orderid=0;
	String sql="select max(order_id) from goods_order";
	java.sql.Statement st=conn.createStatement();
	java.sql.ResultSet rs=st.executeQuery(sql);
	if(rs.next()) {
		orderid=rs.getInt(1)+1;
	}else {
		orderid=1;
	}
    double couponmoney=0;
	if(BeanUser.currentLoginUser.getMember()==1) {
		couponmoney=2;		
	}
	
	sql="select sum(goods_money),gooddetails.goods_id from gooddetails where "
			+ "gooddetails.goods_id in(select shoppingcart.goods_id from shoppingcart where store_id=?)";
	java.sql.PreparedStatement pst=conn.prepareStatement(sql);
	pst.setInt(1,store.getStore_id());
	rs=pst.executeQuery();
	pst.execute();
	
	double originalmoney = 0;
	if(rs.next()) {
		originalmoney=rs.getInt(1);
	}
	
	
	sql="select sum(goods_money-?),gooddetails.goods_id from gooddetails where "
			+ "gooddetails.goods_id in(select shoppingcart.goods_id from shoppingcart where store_id=?)";
	 pst=conn.prepareStatement(sql);
	pst.setDouble(1,couponmoney);
	pst.setInt(2,store.getStore_id());
	rs=pst.executeQuery();
	pst.execute();
	
	double originalmoney2 = 0;
	if(rs.next()) {
		originalmoney2=rs.getInt(1);
	}
	
	
	sql="select reduction_money,max(fullreduction_money),fullreduction.fullreduction_id from fullreduction where fullreduction_money<=?" + 
			" and fullreduction.fullreduction_id in" + 
			"(select fullreduction_id from relationship_store_fullreduction where relationship_store_fullreduction.store_id)";
	pst=conn.prepareStatement(sql);
	pst.setDouble(1,originalmoney2);
	rs=pst.executeQuery();
	pst.execute();
	double endmoney = 0;
	int fullreductionid=0;
	if(rs.next()) {
		endmoney=originalmoney2-rs.getInt(1);
		fullreductionid=rs.getInt(3);
	}
	
//	sql="select count(*) from goods_order where order_status=? and user_id="+BeanUser.currentLoginUser.getUser_id();
//	pst=conn.prepareStatement(sql);
//	pst.setString(1,"���ʹ�");
//	pst.execute();
//	int count = 0;
//	if(rs.next()) {
//		count=rs.getInt(1);
//	}
	
	sql="select user_id,coupon_id,store_id,coupon_money,coupon_count from"
			+ " usercoupon where store_id=? and user_id="+BeanUser.currentLoginUser.getUser_id();
	pst=conn.prepareStatement(sql);
	pst.setInt(1,store.getStore_id());
	rs=pst.executeQuery();
	pst.execute();
	int count = 0;
	int couponid=0;
	int couponmoney1=0;
	if(rs.next()) {
		count=rs.getInt(5);
		couponid=rs.getInt(2);
		couponmoney1=rs.getInt(4);
		if(count>0) {
			sql="update usercoupon set coupon_count=coupon_count-1"
					+ "where store_id=? and user_id="+BeanUser.currentLoginUser.getUser_id();
			pst=conn.prepareStatement(sql);
			pst.setInt(1,store.getStore_id());
			pst.execute();
		}
		else couponid=0;
	}

	if(couponid>0) {
		endmoney=endmoney-couponmoney1;
	}
	BeanUserconpon d=new BeanUserconpon();
	d.setUser_id(BeanUser.currentLoginUser.getUser_id());
	d.setCoupon_id(couponid);
	d.setStore_id(store.getStore_id());
	d.setCoupon_money(couponmoney1);
	d.setCoupon_count(count);
	
	int riderid=0;
	sql="SELECT rider_id FROM rider ORDER BY RAND() LIMIT 1";
	rs=st.executeQuery(sql);
	if(rs.next()) {
		riderid=rs.getInt(1);
	}
	
	
	long currentTime = System.currentTimeMillis() + 45*60*1000;
	
	sql="insert into goods_order"
			+ "(order_id,store_id,user_id,rider_id,original_money,"
			+ "end_money,fullreduction_id,coupon_id,order_time,require_arrive_time,"
			+ "address_id,order_status,assessstore_status,assessrider_status) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	pst=conn.prepareStatement(sql);
	pst.setInt(1,orderid);
	pst.setInt(2,store.getStore_id());
	pst.setInt(3,BeanUser.currentLoginUser.getUser_id());
	pst.setInt(4,riderid);
	pst.setDouble(5,originalmoney);
	pst.setDouble(6,endmoney);
	pst.setInt(7,fullreductionid);
	pst.setInt(8,couponid);
	pst.setTimestamp(9,new java.sql.Timestamp(System.currentTimeMillis()));
	pst.setTimestamp(10,new java.sql.Timestamp(currentTime));
	pst.setInt(11,addressid);
	pst.setString(12,"������");
	pst.setString(13,"δ����");
	pst.setString(14,"δ����");
	pst.execute();
	
	sql="insert into getmoney(rider_id,order_id,gettime,user_access,income,assesscontent)"
			+ " values(?,?,null,null,0,null)";
	pst=conn.prepareStatement(sql);
	pst.setInt(1,riderid);
	pst.setInt(2,orderid);
	pst.execute();
	
	
	
	sql="insert into order_details(order_id,goods_id,count,money,per_reduce_money)" + 
			"select ?,shoppingcart.goods_id,count(*),goods_money,?" + 
			"from shoppingcart,gooddetails where store_id=? and shoppingcart.goods_id=gooddetails.goods_id " + 
			"group by shoppingcart.goods_id";
	pst=conn.prepareStatement(sql);
	pst.setInt(1,orderid);
	pst.setDouble(2,2);
	pst.setInt(3,store.getStore_id());
	pst.execute();
	
	
	sql="delete from shoppingcart where store_id="+store.getStore_id();
	pst=conn.prepareStatement(sql);
	pst.execute();
	conn.commit();
	}catch(SQLException ex) {
        ex.printStackTrace();
		try {
			conn.rollback();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		throw new DbException(ex);
	}finally {
		if(conn!=null) {
			try {
				conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}

}



@Override
//ĳ�û��Ĺ��ﳵ�б�
public List<BeanShoppingcart> loadAll2() throws DbException {
	List<BeanShoppingcart> result=new ArrayList<BeanShoppingcart>();
	Connection conn=null;
	try {
		conn=DBUtil.getConnection();
		String sql="select * from shoppingcart where user_id="+BeanUser.currentLoginUser.getUser_id();
		java.sql.Statement st=conn.createStatement();
		java.sql.ResultSet rs=st.executeQuery(sql);

		while(rs.next()) {
			BeanShoppingcart p=new BeanShoppingcart();
			p.setStore_id(rs.getInt(1));
			p.setGoods_id(rs.getInt(2));;
			p.setType_id(rs.getInt(3));
			p.setUser_id(rs.getInt(4));
			p.setTime(rs.getTimestamp(5));
			
			result.add(p);
		}
		rs.close();
		st.close();
		conn.close();
		return result;
	}catch(SQLException ex) {
        ex.printStackTrace();
		throw new DbException(ex);
	}finally {
		if(conn!=null) {
			try {
				conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}}



@Override
//ĳ�û�����Ʒ����
public List<BeanGoodsassess> loadAll3() throws DbException {
	List<BeanGoodsassess> result=new ArrayList<BeanGoodsassess>();
	Connection conn=null;
	try {
		conn=DBUtil.getConnection();
		String sql="select * from goodsassess where user_id="+BeanUser.currentLoginUser.getUser_id();
		java.sql.Statement st=conn.createStatement();
		java.sql.ResultSet rs=st.executeQuery(sql);

		while(rs.next()) {
			BeanGoodsassess p=new BeanGoodsassess();
			p.setStore_id(rs.getInt(1));
			p.setGoods_id(rs.getInt(2));;
			p.setUser_id(rs.getInt(3));
			p.setContent(rs.getString(4));
			p.setTime(rs.getTimestamp(5));
			p.setLevel(rs.getInt(6));
			result.add(p);
		}
		rs.close();
		st.close();
		conn.close();
		return result;
	}catch(SQLException ex) {
        ex.printStackTrace();
		throw new DbException(ex);
	}finally {
		if(conn!=null) {
			try {
				conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}}}
