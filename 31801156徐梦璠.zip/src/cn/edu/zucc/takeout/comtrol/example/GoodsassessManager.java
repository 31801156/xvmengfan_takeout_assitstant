package cn.edu.zucc.takeout.comtrol.example;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

//��Ʒ���۹���
import cn.edu.zucc.takeout.itf.IGoodsassessManager;
import cn.edu.zucc.takeout.model.BeanGooddetails;
import cn.edu.zucc.takeout.model.BeanGoodsassess;
import cn.edu.zucc.takeout.util.DBUtil;
import cn.edu.zucc.takeout.util.DbException;


public class GoodsassessManager implements IGoodsassessManager {

	@Override
	//ĳ��Ʒ����Ʒ����
	public List<BeanGoodsassess> loadAll(BeanGooddetails gooddetails) throws DbException {
		List<BeanGoodsassess> result=new ArrayList<BeanGoodsassess>();
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from goodsassess where goods_id=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,gooddetails.getGoods_id());
			java.sql.ResultSet rs=pst.executeQuery();
			while(rs.next()) {
				BeanGoodsassess p=new BeanGoodsassess();
				p.setGoods_id(rs.getInt(1));;
				p.setStore_id(rs.getInt(2));;
				p.setUser_id(rs.getInt(3));;
				p.setContent(rs.getString(4));
				p.setTime(rs.getTimestamp(5));
				p.setLevel(rs.getInt(6));
				//p.setPhoto(rs.getDouble(5));
				result.add(p);
			}
			rs.close();
			pst.close();
			conn.close();
			return result;
		}catch(SQLException ex) {
	        ex.printStackTrace();
			throw new DbException(ex);
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
		}}
