
package cn.edu.zucc.takeout.comtrol.example;

import java.util.List;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

//�������˹���
import cn.edu.zucc.takeout.itf.IGetmoneyManager;
import cn.edu.zucc.takeout.itf.IGooddetailsManager;
import cn.edu.zucc.takeout.model.BeanGetmoney;
import cn.edu.zucc.takeout.model.BeanGooddetails;
import cn.edu.zucc.takeout.model.BeanGoodstype;
import cn.edu.zucc.takeout.model.BeanRider;
import cn.edu.zucc.takeout.model.BeanUser;
import cn.edu.zucc.takeout.util.BaseException;
import cn.edu.zucc.takeout.util.DBUtil;
import cn.edu.zucc.takeout.util.DbException;

public class GetmoneyManager implements IGetmoneyManager {
@Override
//ĳ���ֵ��������˱�
public List<BeanGetmoney> loadAll(BeanRider rider) throws BaseException {
	List<BeanGetmoney> result=new ArrayList<BeanGetmoney>();
	Connection conn=null;
	try {
		conn=DBUtil.getConnection();
		String sql="select * from getmoney where rider_id=?";
		java.sql.PreparedStatement pst=conn.prepareStatement(sql);
		pst.setInt(1,rider.getRider_id());
		java.sql.ResultSet rs=pst.executeQuery();
		while(rs.next()) {
			BeanGetmoney p=new BeanGetmoney();
			p.setRider_id(rs.getInt(1));;
			p.setOrder_id(rs.getInt(2));;
			p.setGettime(rs.getTimestamp(3));
			p.setUser_access(rs.getString(4));;
			p.setIncome(rs.getDouble(5));
			result.add(p);
		}
		rs.close();
		pst.close();
		conn.close();
		return result;
	}catch(SQLException ex) {
        ex.printStackTrace();
		throw new DbException(ex);
	}finally {
		if(conn!=null) {
			try {
				conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}

}

}