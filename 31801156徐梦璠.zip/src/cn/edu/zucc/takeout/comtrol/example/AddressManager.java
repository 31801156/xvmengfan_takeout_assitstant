package cn.edu.zucc.takeout.comtrol.example;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.JOptionPane;

import cn.edu.zucc.takeout.itf.IAddressManager;
import cn.edu.zucc.takeout.model.BeanAddress;
import cn.edu.zucc.takeout.model.BeanUser;
import cn.edu.zucc.takeout.util.BaseException;
import cn.edu.zucc.takeout.util.BusinessException;
import cn.edu.zucc.takeout.util.DBUtil;
import cn.edu.zucc.takeout.util.DbException;

//���͵�ַ����

public class AddressManager implements IAddressManager {
	@Override
	//�û��������͵�ַ
	public BeanAddress addAddress(BeanUser user, int addressid, String province, String city, String area, String address,
			String username, String phonenumber) throws BaseException {
		
		if(province==null||"".equals(province))
			throw new BusinessException("ʡ�ݲ���Ϊ��");
		else if(city==null||"".equals(city))
			throw new BusinessException("���в���Ϊ��");
		else if(area==null||"".equals(area))
			throw new BusinessException("��������Ϊ��");
		else if(address==null||"".equals(address))
			throw new BusinessException("��ַ����Ϊ��");
		else if(username==null||"".equals(username))
			throw new BusinessException("�ջ��˲���Ϊ��");
		else if(phonenumber==null||"".equals(phonenumber))
			throw new BusinessException("�ջ��˵绰����Ϊ��");
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select address_id from address where address_id=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,addressid);
			java.sql.ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				rs.close();
				pst.close();
				throw new BusinessException("ͬ�����͵�ַ�Ѵ���");//�Ѿ�������ͬ��ַ���׳�����
			}
			rs.close();
			pst.close();
			sql= "insert into address(address_id,user_id,province,city,area,address,user_name,phonenumber)"
						+ " values(?,?,?,?,?,?,?,?)";//��ַ��Ϣ�������ݿ�
			pst=conn.prepareStatement(sql);
			pst.setInt(1,addressid);
			pst.setInt(2,BeanUser.currentLoginUser.getUser_id());
			pst.setString(3,province);
			pst.setString(4,city);
			pst.setString(5,area);
			pst.setString(6,address);
			pst.setString(7,user.getUser_name());
			pst.setString(8,phonenumber);
			pst.execute();
			BeanAddress p=new BeanAddress();//��ַ��Ϣ���浽BeanAddress��
			p.setAddress_id(addressid);
			p.setUser_id(user.getUser_id());;
			p.setProvince(province);
			p.setCity(city);
			p.setArea(area);
			p.setAddress(address);
			p.setUser_name(username);
			p.setPhonenumber(phonenumber);
			rs.close();
			pst.close();
			return p;
			}catch(SQLException ex) {
				throw new DbException(ex);
			}finally {
				if(conn!=null) {
					try {
						conn.close();
					}catch(SQLException e) {
						e.printStackTrace();
					}
				}
			}
	}

	@Override
	//��ǰ�û��ĵ�ַ�б�
	public List<BeanAddress> loadAll() throws BaseException {
		List<BeanAddress> result=new ArrayList<BeanAddress>();
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from address where user_name=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,BeanUser.currentLoginUser.getUser_name());//BeanUser.currentLoginUser.getUser_id()
			java.sql.ResultSet rs=pst.executeQuery();
			while(rs.next()) {
				BeanAddress p=new BeanAddress();
				p.setAddress_id(rs.getInt(1));
				p.setUser_id(rs.getInt(2));;
				p.setProvince(rs.getString(3));
				p.setCity(rs.getString(4));
				p.setArea(rs.getString(5));
				p.setAddress(rs.getString(6));
				p.setUser_name(rs.getString(7));
				p.setPhonenumber(rs.getString(8));
				result.add(p);
			}
			rs.close();
			pst.close();
			conn.close();
			return result;
		}catch(SQLException ex) {
	        ex.printStackTrace();
			throw new DbException(ex);
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	
		
	}
	}
