package cn.edu.zucc.takeout.comtrol.example;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

//����Ա����
import cn.edu.zucc.takeout.itf.IManager;
import cn.edu.zucc.takeout.model.BeanManager;
import cn.edu.zucc.takeout.model.BeanUser;
import cn.edu.zucc.takeout.util.BaseException;
import cn.edu.zucc.takeout.util.BusinessException;
import cn.edu.zucc.takeout.util.DBUtil;
import cn.edu.zucc.takeout.util.DbException;


public class ManagerManager implements IManager {

	@Override
	//����Աע��
	public BeanManager reg(String managername, String pwd,String pwd2) throws BaseException {
		if(managername==null||"".equals(managername))
			throw new BusinessException("����Ա������Ϊ��");
		if(pwd==null||"".equals(pwd))
			throw new BusinessException("���벻��Ϊ��");
		if(!pwd.equals(pwd2))
			throw new BusinessException("������������벻һ��");
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			int manager_id=0;
			String sql= "select manager_name from manager where manager_name=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,managername);
			java.sql.ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				rs.close();
				pst.close();
				throw new BusinessException("����Ա�Ѵ���");
			}
			rs.close();
			pst.close();
			
			sql="select max(manager_id) from manager";
			java.sql.Statement st=conn.createStatement();
			rs=st.executeQuery(sql);
			if(rs.next()) {
				manager_id=rs.getInt(1)+1;
			}else {
				manager_id=1;
			}
			rs.close();
			st.close();
			
			sql= "insert into manager(manager_id,manager_name,password) values(?,?,?)";
			pst=conn.prepareStatement(sql);
			pst.setInt(1,manager_id);
			pst.setString(2,managername);
			pst.setString(3,pwd);
			pst.execute();
			BeanManager user=new BeanManager();
			user.setManager_id(manager_id);
			user.setManager_name(managername);
			user.setPassword(pwd);
//			
//			sql="insert into relationship_manager_user(manager_id,user_id) select ?,user_id from user";
//			pst=conn.prepareStatement(sql);
//			pst.setString(1,manager_id);
//			pst.execute();
			return user;
			}catch(SQLException ex) {
			throw new DbException(ex);
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}


	
	@Override
	//����Ա��¼
	public BeanManager login(String managername, String pwd) throws BaseException {
		Connection conn=null;
		BeanManager user=null;
		try {
			conn=DBUtil.getConnection();
			int manager_id=0;
			String sql= "select manager_id,manager_name,password from manager where manager_name=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,managername);
			java.sql.ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				manager_id=rs.getInt(1);
				if(!pwd.equals(rs.getString(3))) {
					throw new BusinessException("�������");
				}
				user=new BeanManager();
				user.setManager_id(manager_id);
				user.setManager_name(managername);
				user.setPassword(pwd);
				return user;
			}else {
				throw new BusinessException("����Ա������");
			}
		}catch(SQLException ex) {
			throw new DbException(ex);
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}


	@Override
	//����Ա�޸�����
	public void changePwd(BeanManager manager, String oldPwd, String newPwd,
			String newPwd2) throws BaseException {
		if(newPwd==null||"".equals(newPwd))
			throw new BusinessException("���벻��Ϊ��");
		if(!oldPwd.equals(manager.getPassword()))
			throw new BusinessException("�������������");
		if(!newPwd.equals(newPwd2))
			throw new BusinessException("��������������벻һ��");
		if(oldPwd.equals(newPwd))
			throw new BusinessException("���������������ͬ");
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql= "update manager set password=? where manager_name=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,newPwd);
			pst.setString(2,manager.getManager_name());
			pst.execute();
			manager.setManager_name(manager.getManager_name());
			manager.setPassword(newPwd);

			}catch(SQLException ex) {
			throw new DbException(ex);
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}



//	@Override
//	public void changeName(BeanManager manager, String newName) throws BaseException {
//			if(newName==null||"".equals(newName))
//				throw new BusinessException("�û�������Ϊ��");
//			Connection conn=null;
//			try {
//				conn=DBUtil.getConnection();
//				String sql= "update manager set manager_name=? where manager_name=?";
//				java.sql.PreparedStatement pst=conn.prepareStatement(sql);
//				pst.setString(1,newName);
//				pst.setString(2,manager.getManager_name());
//				pst.execute();
//				manager.setManager_name(newName);
//				}catch(SQLException ex) {
//				throw new DbException(ex);
//			}finally {
//				if(conn!=null) {
//					try {
//						conn.close();
//					}catch(SQLException e) {
//						e.printStackTrace();
//					}
//				}
//			}
//		}
	@Override
	//ĳ����Ա����Ϣ�б�
	public List<BeanManager> loadAll() throws BaseException {
		List<BeanManager> result=new ArrayList<BeanManager>();
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from manager where manager_name=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,BeanManager.currentLoginUser.getManager_name());
			java.sql.ResultSet rs=pst.executeQuery();
			while(rs.next()) {
				BeanManager p=new BeanManager();
				p.setManager_id(rs.getInt(1));
				p.setManager_name(rs.getString(2));;
				p.setPassword(rs.getString(3));
				result.add(p);
			}
			rs.close();
			pst.close();
			conn.close();
			return result;
		}catch(SQLException ex) {
	        ex.printStackTrace();
			throw new DbException(ex);
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}

		
	}

}