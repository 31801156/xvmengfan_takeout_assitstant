package cn.edu.zucc.takeout.comtrol.example;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

//��Ʒ��������
import cn.edu.zucc.takeout.itf.IGoods_orderManager;
import cn.edu.zucc.takeout.model.BeanGoods_order;
import cn.edu.zucc.takeout.model.BeanUser;
import cn.edu.zucc.takeout.util.BaseException;
import cn.edu.zucc.takeout.util.DBUtil;
import cn.edu.zucc.takeout.util.DbException;

public class Goods_orderManager implements IGoods_orderManager {
@Override
//��ǰ�û�����Ʒ��������
public List<BeanGoods_order> loadAll() throws BaseException {
	List<BeanGoods_order> result=new ArrayList<BeanGoods_order>();
	Connection conn=null;
	try {
		conn=DBUtil.getConnection();
		
		String sql="select * from goods_order where user_id=?";
		java.sql.PreparedStatement pst=conn.prepareStatement(sql);
		pst.setInt(1,BeanUser.currentLoginUser.getUser_id());
		java.sql.ResultSet rs=pst.executeQuery();
		while(rs.next()) {
			BeanGoods_order p=new BeanGoods_order();
			p.setOrder_id(rs.getInt(1));
			p.setStore_id(rs.getInt(2));
			p.setUser_id(rs.getInt(3));
			p.setRider_id(rs.getInt(4));
			p.setOriginal_money(rs.getDouble(5));
			p.setEnd_money(rs.getDouble(6));
			p.setFullreduction_id(rs.getInt(7));
			p.setCoupon_id(rs.getInt(8));
			p.setOrder_time(rs.getTimestamp(9));
			p.setRequire_arrive_time(rs.getTimestamp(10));
			p.setAddress_id(rs.getInt(11));
			p.setOrder_status(rs.getString(12));
			p.setAssessstore_status(rs.getString(13));
			p.setAssessrider_status(rs.getString(14));
			result.add(p);
		}
		
		rs.close();
		pst.close();
		conn.close();
		return result;
	}catch(SQLException ex) {
        ex.printStackTrace();
		throw new DbException(ex);
	}finally {
		if(conn!=null) {
			try {
				conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}

}}