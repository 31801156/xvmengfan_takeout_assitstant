package cn.edu.zucc.takeout.comtrol.example;

import java.util.List;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

//��Ʒ������
import cn.edu.zucc.takeout.itf.IGoodstypeManager;
import cn.edu.zucc.takeout.model.BeanGoodstype;
import cn.edu.zucc.takeout.model.BeanStore;
import cn.edu.zucc.takeout.model.BeanUser;
import cn.edu.zucc.takeout.util.BaseException;
import cn.edu.zucc.takeout.util.DBUtil;
import cn.edu.zucc.takeout.util.DbException;

public class GoodstypeManager implements IGoodstypeManager {
@Override
//ĳ�̵����Ʒ����б�
public List<BeanGoodstype> loadAll(BeanStore store) throws BaseException {
	List<BeanGoodstype> result=new ArrayList<BeanGoodstype>();
	Connection conn=null;
	try {
		conn=DBUtil.getConnection();
		String sql="select * from goodstype where type_id in("
				+ "select type_id from relationship_store_goodstype where store_id=?)";
		java.sql.PreparedStatement pst=conn.prepareStatement(sql);
		pst.setInt(1,store.getStore_id());
		java.sql.ResultSet rs=pst.executeQuery();
		while(rs.next()) {
			BeanGoodstype p=new BeanGoodstype();
			p.setType_id(rs.getInt(1));;
			p.setType_name(rs.getString(2));;
			p.setGoods_count(rs.getInt(3));
			result.add(p);
		}
		rs.close();
		pst.close();
		conn.close();
		return result;
	}catch(SQLException ex) {
        ex.printStackTrace();
		throw new DbException(ex);
	}finally {
		if(conn!=null) {
			try {
				conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}

}

@Override
public void addTypegooods(BeanGoodstype goodtype, int goods_id, String goods_name, double goods_money, double coupon_money,int count) throws DbException {
	Connection conn=null;
	try {
		conn=DBUtil.getConnection();
		String sql="insert into gooddetails(goods_id,type_id,goods_name,goods_money,coupon_money,goods_count) values(?,?,?,?,?,?)";
		java.sql.PreparedStatement pst = null;
		pst = conn.prepareStatement(sql);
		pst.setInt(1,goods_id);
		pst.setInt(2,goodtype.getType_id());
		pst.setString(3,goods_name);
		pst.setDouble(4,goods_money);
		pst.setDouble(5,coupon_money);
		pst.setInt(6,count);
		pst.execute();
		
		pst.close();
		}catch(SQLException ex) {
		throw new DbException(ex);
	}finally {
		if(conn!=null) {
			try {
				conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}
}}



//@Override
//public void actionPerformed(ActionEvent e) {
//	if(e.getSource()==this.btnCancel)
//		this.setVisible(false);
//	else if(e.getSource()==this.btnOk){
//		Connection conn=null;
//		try {
//			conn=DBUtil.getConnection();
//			String sql="insert into gooddetails(goods_id,type_id,goods_name,goods_money,coupon_money) values(?,?,?,?,?)";
//			java.sql.PreparedStatement pst = null;
//			pst = conn.prepareStatement(sql);
//			pst.setInt(1,Integer.parseInt(edtgoodsid.getText()));
//			pst.setInt(2,goodtype.getType_id());
//			pst.setString(3,edtgoodsname.getText());
//			pst.setInt(4,Integer.parseInt(edtmoney.getText()));
//			pst.setInt(5,Integer.parseInt(edtreducemoney.getText()));
//			
//		} catch (SQLException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
//		this.setVisible(false);
//
//			}
//		}
//
//
//}