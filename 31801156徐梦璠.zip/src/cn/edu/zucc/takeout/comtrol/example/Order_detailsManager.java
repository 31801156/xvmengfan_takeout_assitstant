package cn.edu.zucc.takeout.comtrol.example;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

//�����������
import cn.edu.zucc.takeout.itf.IOrder_detailsManager;
import cn.edu.zucc.takeout.model.BeanGoods_order;
import cn.edu.zucc.takeout.model.BeanOrder_details;
import cn.edu.zucc.takeout.util.BaseException;
import cn.edu.zucc.takeout.util.DBUtil;
import cn.edu.zucc.takeout.util.DbException;


public class Order_detailsManager extends IOrder_detailsManager {
	@Override
	//ĳ�����Ķ�������
	public List<BeanOrder_details> loadAll(BeanGoods_order goodsorder) throws BaseException {
		List<BeanOrder_details> result=new ArrayList<BeanOrder_details>();
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from order_details where order_id=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,goodsorder.getOrder_id());
			java.sql.ResultSet rs=pst.executeQuery();
			while(rs.next()) {
				BeanOrder_details p=new BeanOrder_details();
				p.setOrder_id(rs.getInt(1));;
				p.setGoods_id(rs.getInt(2));;
				p.setCount(rs.getInt(3));
				p.setMoney(rs.getDouble(4));;
				p.setPer_reduce_money(rs.getInt(5));
				result.add(p);
			}
			rs.close();
			pst.close();
			conn.close();
			return result;
		}catch(SQLException ex) {
	        ex.printStackTrace();
			throw new DbException(ex);
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}}