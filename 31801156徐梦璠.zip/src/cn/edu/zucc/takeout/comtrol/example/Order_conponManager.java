package cn.edu.zucc.takeout.comtrol.example;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

//�����Ż�ȯ����
import cn.edu.zucc.takeout.itf.IAddressManager;
import cn.edu.zucc.takeout.itf.IOrder_conponManager;
import cn.edu.zucc.takeout.model.BeanOrder_conpon;
import cn.edu.zucc.takeout.model.BeanUser;
import cn.edu.zucc.takeout.util.BaseException;
import cn.edu.zucc.takeout.util.DBUtil;
import cn.edu.zucc.takeout.util.DbException;

public class Order_conponManager implements IOrder_conponManager {
@Override
//��ǰ�û��ļ����Ż�ȯ����
public List<BeanOrder_conpon> loadAll() throws BaseException {
	List<BeanOrder_conpon> result=new ArrayList<BeanOrder_conpon>();
	Connection conn=null;
	try {
		conn=DBUtil.getConnection();

		String sql="select * from orders_conpons where user_id=?";
		java.sql.PreparedStatement pst=conn.prepareStatement(sql);
		pst.setInt(1,BeanUser.currentLoginUser.getUser_id());
		java.sql.ResultSet rs=pst.executeQuery();
		while(rs.next()) {
			BeanOrder_conpon p=new BeanOrder_conpon();
			p.setUser_id(rs.getInt(1));;
			p.setStore_id(rs.getInt(2));
			p.setConpon_id(rs.getInt(3));
			p.setConpon_require_number(rs.getInt(4));
			p.setOrdercount(rs.getInt(5));
			result.add(p);
		}
		rs.close();
		pst.close();
		conn.close();
		return result;
	}catch(SQLException ex) {
        ex.printStackTrace();
		throw new DbException(ex);
	}finally {
		if(conn!=null) {
			try {
				conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}

}}