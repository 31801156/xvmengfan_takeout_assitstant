package cn.edu.zucc.takeout.comtrol.example;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import cn.edu.zucc.takeout.itf.IFullreductionManager;
import cn.edu.zucc.takeout.model.BeanCoupon;
import cn.edu.zucc.takeout.model.BeanFullreduction;
import cn.edu.zucc.takeout.model.BeanStore;
import cn.edu.zucc.takeout.util.DBUtil;
import cn.edu.zucc.takeout.util.DbException;

//��������

public class FullreductionManager implements IFullreductionManager {

	@Override
	//ĳ�̵�������б�
	public List<BeanFullreduction> loadAll(BeanStore store) throws DbException {
		List<BeanFullreduction> result=new ArrayList<BeanFullreduction>();
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from fullreduction where fullreduction.fullreduction_id in"
					+ "(select relationship_store_fullreduction.fullreduction_id from relationship_store_fullreduction where store_id=?)";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,store.getStore_id());
			java.sql.ResultSet rs=pst.executeQuery();
			while(rs.next()) {
				BeanFullreduction p=new BeanFullreduction();
				p.setFullreduction_id(rs.getInt(1));;
				p.setFullreduction_money(rs.getInt(2));;
				p.setReduction_money(rs.getInt(3));
				p.setWith_coupon(rs.getInt(4));;
				result.add(p);
			}
			rs.close();
			pst.close();
			conn.close();
			return result;
		}catch(SQLException ex) {
	        ex.printStackTrace();
			throw new DbException(ex);
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	@Override
	public void fullreduce(int fullreductionid, int fullreductionmoney, int reductionmoney, int withcoupon) throws DbException {
		
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql= "insert into fullreduction(fullreduction_id,fullreduction_money,reduction_money,with_coupon)"
						+ " values(?,?,?,?)";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,fullreductionid);
			pst.setInt(2,fullreductionmoney);
			pst.setInt(3,reductionmoney);
			pst.setInt(4,withcoupon);
			pst.execute();
			BeanFullreduction p=new BeanFullreduction();
			p.setFullreduction_id(fullreductionid);
			p.setFullreduction_money(fullreductionmoney);;
			p.setReduction_money(reductionmoney);
			p.setWith_coupon(withcoupon);

			pst.close();
			}catch(SQLException ex) {
	        ex.printStackTrace();
			throw new DbException(ex);
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	@Override
	public List<BeanFullreduction> loadAll1() throws DbException {
		List<BeanFullreduction> result=new ArrayList<BeanFullreduction>();
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from fullreduction";
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				BeanFullreduction p=new BeanFullreduction();
				p.setFullreduction_id(rs.getInt(1));;
				p.setFullreduction_money(rs.getInt(2));;
				p.setReduction_money(rs.getInt(3));
				p.setWith_coupon(rs.getInt(4));;
				result.add(p);
			}
			rs.close();
			st.close();
			conn.close();
			return result;
		}catch(SQLException ex) {
	        ex.printStackTrace();
			throw new DbException(ex);
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
}