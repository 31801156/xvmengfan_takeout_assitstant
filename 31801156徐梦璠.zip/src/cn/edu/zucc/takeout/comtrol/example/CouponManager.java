package cn.edu.zucc.takeout.comtrol.example;

import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;

import cn.edu.zucc.takeout.itf.ICouponManager;
import cn.edu.zucc.takeout.itf.IGooddetailsManager;
import cn.edu.zucc.takeout.model.BeanAddress;
import cn.edu.zucc.takeout.model.BeanCoupon;
import cn.edu.zucc.takeout.model.BeanStore;
import cn.edu.zucc.takeout.model.BeanUser;
import cn.edu.zucc.takeout.util.BusinessException;
import cn.edu.zucc.takeout.util.DBUtil;
import cn.edu.zucc.takeout.util.DbException;

//�Ż�ȯ����

public class CouponManager implements ICouponManager {

	@Override
	//ĳ�̼ҵ��Ż�ȯ�б�
	public List<BeanCoupon> loadAll(BeanStore store) throws DbException {
		List<BeanCoupon> result=new ArrayList<BeanCoupon>();
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from coupon where coupon.coupon_id in"
					+ "(select relationship_store_coupon.coupon_id from relationship_store_coupon where store_id=?)";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,store.getStore_id());
			java.sql.ResultSet rs=pst.executeQuery();
			while(rs.next()) {
				BeanCoupon p=new BeanCoupon();
				p.setCoupon_id(rs.getInt(1));;
				p.setCoupon_money(rs.getInt(2));;
				p.setCoupon_require_number(rs.getInt(3));
				p.setCoupon_begin_time(rs.getTimestamp(4));;
				p.setCoupon_end_time(rs.getTimestamp(5));
				result.add(p);
			}
			rs.close();
			pst.close();
			conn.close();
			return result;
		}catch(SQLException ex) {
	        ex.printStackTrace();
			throw new DbException(ex);
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	@Override
	public void addcoupon(int couponid,int couponmoney,int requirenumber, Timestamp begin, Timestamp end) throws DbException {
		
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql= "insert into coupon(coupon_id,coupon_money,coupon_require_number,coupon_begin_time,coupon_end_time)"
						+ " values(?,?,?,?,?)";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,couponid);
			pst.setInt(2,couponmoney);
			pst.setInt(3,requirenumber);
			pst.setTimestamp(4,begin);
			pst.setTimestamp(5,end);
			pst.execute();
			BeanCoupon p=new BeanCoupon();
			p.setCoupon_id(couponid);
			p.setCoupon_money(couponmoney);;
			p.setCoupon_require_number(requirenumber);
			p.setCoupon_begin_time(begin);
			p.setCoupon_end_time(end);

			pst.close();
			}catch(SQLException ex) {
	        ex.printStackTrace();
			throw new DbException(ex);
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	@Override
	public List<BeanCoupon> loadAll1() throws DbException {
		List<BeanCoupon> result=new ArrayList<BeanCoupon>();
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from coupon";
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				BeanCoupon p=new BeanCoupon();
				p.setCoupon_id(rs.getInt(1));;
				p.setCoupon_money(rs.getInt(2));;
				p.setCoupon_require_number(rs.getInt(3));
				p.setCoupon_begin_time(rs.getTimestamp(4));;
				p.setCoupon_end_time(rs.getTimestamp(5));
				result.add(p);
			}
			rs.close();
			st.close();
			conn.close();
			return result;
		}catch(SQLException ex) {
	        ex.printStackTrace();
			throw new DbException(ex);
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
}