package cn.edu.zucc.takeout;


import cn.edu.zucc.takeout.comtrol.example.AddressManager;
import cn.edu.zucc.takeout.comtrol.example.CouponManager;
import cn.edu.zucc.takeout.comtrol.example.FullreductionManager;
import cn.edu.zucc.takeout.comtrol.example.GetmoneyManager;
import cn.edu.zucc.takeout.comtrol.example.GooddetailsManager;
import cn.edu.zucc.takeout.comtrol.example.Goods_orderManager;
import cn.edu.zucc.takeout.comtrol.example.GoodsassessManager;
import cn.edu.zucc.takeout.comtrol.example.GoodstypeManager;
import cn.edu.zucc.takeout.comtrol.example.ManagerManager;
import cn.edu.zucc.takeout.comtrol.example.Order_conponManager;
import cn.edu.zucc.takeout.comtrol.example.Order_detailsManager;
import cn.edu.zucc.takeout.comtrol.example.RiderManager;
import cn.edu.zucc.takeout.comtrol.example.StoreManager;
import cn.edu.zucc.takeout.comtrol.example.UserManager;
import cn.edu.zucc.takeout.comtrol.example.UsercouponManager;
import cn.edu.zucc.takeout.itf.IAddressManager;
import cn.edu.zucc.takeout.itf.ICouponManager;
import cn.edu.zucc.takeout.itf.IFullreductionManager;
import cn.edu.zucc.takeout.itf.IGetmoneyManager;
import cn.edu.zucc.takeout.itf.IGooddetailsManager;
import cn.edu.zucc.takeout.itf.IGoods_orderManager;
import cn.edu.zucc.takeout.itf.IGoodsassessManager;
import cn.edu.zucc.takeout.itf.IGoodstypeManager;
import cn.edu.zucc.takeout.itf.IManager;
import cn.edu.zucc.takeout.itf.IOrder_conponManager;
import cn.edu.zucc.takeout.itf.IOrder_detailsManager;
import cn.edu.zucc.takeout.itf.IRiderManager;
import cn.edu.zucc.takeout.itf.IStoreManager;
import cn.edu.zucc.takeout.itf.IUserManager;
import cn.edu.zucc.takeout.itf.IUsercouponManager;

public class PersonPlanUtil {

	
	
	public static IOrder_conponManager Order_conponManager = new Order_conponManager();//������ȯ����
	public static IUserManager UserManager=new UserManager();//�û�����
	public static IManager ManagerManager=new ManagerManager();//����Ա����
	public static IAddressManager AddressManager=new AddressManager();//�û����͵�ַ����
	public static IUsercouponManager UsercouponManager = new UsercouponManager();//�û��Ż�ȯ����
	public static IGoods_orderManager Goods_orderManager = new Goods_orderManager();//��Ʒ��������
	public static IStoreManager StoreManager = new StoreManager();//�̵����
	public static IRiderManager RiderManager = new RiderManager();//���ֹ���
	public static IGoodstypeManager GoodstypeManager = new GoodstypeManager();//��Ʒ�������
	public static IGooddetailsManager GooddetailsManager = new GooddetailsManager();//��Ʒ�������
	public static IOrder_detailsManager Order_detailsManager=new Order_detailsManager();//�����������
	public static ICouponManager CouponManager=new CouponManager();//�Ż�ȯ����
	public static IGoodsassessManager GoodsassessManager=new GoodsassessManager();//��Ʒ���۹���
	public static IGetmoneyManager GetmoneyManager= new GetmoneyManager();//�������˹���
	public static IFullreductionManager FullreductionManager=new FullreductionManager();//�̼���������
}
