package cn.edu.zucc.takeout.itf;

import java.util.List;

import cn.edu.zucc.takeout.model.BeanFullreduction;
import cn.edu.zucc.takeout.model.BeanStore;
import cn.edu.zucc.takeout.util.DbException;

public interface IFullreductionManager {

	List<BeanFullreduction> loadAll(BeanStore store) throws DbException;

	void fullreduce(int fullreductionid, int fullreductionmoney, int reductionmoney, int withcoupon) throws DbException;

	List<BeanFullreduction> loadAll1() throws DbException;

}
