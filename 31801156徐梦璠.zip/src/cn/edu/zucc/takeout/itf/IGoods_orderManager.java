package cn.edu.zucc.takeout.itf;

import java.util.List;

import cn.edu.zucc.takeout.model.BeanGoods_order;
import cn.edu.zucc.takeout.util.BaseException;

public interface IGoods_orderManager {
	List<BeanGoods_order> loadAll() throws BaseException;
}
