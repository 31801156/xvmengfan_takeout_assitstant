package cn.edu.zucc.takeout.itf;

import java.util.List;

import cn.edu.zucc.takeout.model.BeanGetmoney;
import cn.edu.zucc.takeout.model.BeanRider;
import cn.edu.zucc.takeout.util.BaseException;

public interface IGetmoneyManager {

	List<BeanGetmoney> loadAll(BeanRider rider) throws BaseException;

}
