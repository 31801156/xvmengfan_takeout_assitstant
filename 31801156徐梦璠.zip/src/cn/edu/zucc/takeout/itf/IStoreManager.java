package cn.edu.zucc.takeout.itf;

import java.sql.SQLException;
import java.util.List;

import cn.edu.zucc.takeout.model.BeanCoupon;
import cn.edu.zucc.takeout.model.BeanStore;
import cn.edu.zucc.takeout.util.BaseException;
import cn.edu.zucc.takeout.util.DbException;

public interface IStoreManager {
	List<BeanStore> loadAll() throws BaseException;

	void deleteStore(BeanStore store) throws BaseException, SQLException;


//	void changeName(BeanStore user, String newName) throws BaseException;

	BeanStore addStore(String store_name, String store_level, String store_per_consumption, String store_totalsales)
			throws BaseException;

	void addStoretype(BeanStore store, int typeid) throws DbException;

	void addStoreconpon(BeanStore store, int couponid) throws DbException;

	void addStorereduce(BeanStore store, int fullreductionid) throws DbException;

}
