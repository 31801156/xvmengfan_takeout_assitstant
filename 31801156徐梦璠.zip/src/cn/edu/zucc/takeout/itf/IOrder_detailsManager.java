package cn.edu.zucc.takeout.itf;

import java.util.List;

import cn.edu.zucc.takeout.model.BeanGooddetails;
import cn.edu.zucc.takeout.model.BeanGoods_order;
import cn.edu.zucc.takeout.model.BeanGoodstype;
import cn.edu.zucc.takeout.model.BeanOrder_details;
import cn.edu.zucc.takeout.util.BaseException;

public class IOrder_detailsManager {

	public List<BeanOrder_details> loadAll(BeanGoods_order goodsorder) throws BaseException {
		// TODO Auto-generated method stub
		return null;
	}


}
