package cn.edu.zucc.takeout.itf;

import java.util.List;

import cn.edu.zucc.takeout.model.BeanAddress;
import cn.edu.zucc.takeout.model.BeanOrder_conpon;
import cn.edu.zucc.takeout.util.BaseException;

public interface  IOrder_conponManager {

	List<BeanOrder_conpon> loadAll() throws BaseException;

}
