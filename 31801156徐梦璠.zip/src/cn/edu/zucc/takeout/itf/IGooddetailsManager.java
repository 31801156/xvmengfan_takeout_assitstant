package cn.edu.zucc.takeout.itf;

import java.util.List;

import cn.edu.zucc.takeout.model.BeanGooddetails;
import cn.edu.zucc.takeout.model.BeanGoods_order;
import cn.edu.zucc.takeout.model.BeanGoodstype;
import cn.edu.zucc.takeout.model.BeanOrder_details;
import cn.edu.zucc.takeout.util.BaseException;

public interface IGooddetailsManager {


	List<BeanGooddetails> loadAll(BeanGoodstype goodstype) throws BaseException;

}
