package cn.edu.zucc.takeout.itf;

import java.util.List;

import cn.edu.zucc.takeout.model.BeanUserconpon;
import cn.edu.zucc.takeout.util.BaseException;

public interface IUsercouponManager {

	List<BeanUserconpon> loadAll() throws BaseException;

}
