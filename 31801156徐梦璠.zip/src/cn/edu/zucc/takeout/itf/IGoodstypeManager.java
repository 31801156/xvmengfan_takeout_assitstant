package cn.edu.zucc.takeout.itf;

import java.util.List;

import cn.edu.zucc.takeout.model.BeanGoodstype;
import cn.edu.zucc.takeout.model.BeanStore;
import cn.edu.zucc.takeout.util.BaseException;
import cn.edu.zucc.takeout.util.DbException;

public interface IGoodstypeManager {
	List<BeanGoodstype> loadAll(BeanStore curStore) throws BaseException;


	void addTypegooods(BeanGoodstype goodtype, int goods_id, String goods_name, double goods_money, double coupon_money, int count)
			throws DbException;
}
