package cn.edu.zucc.takeout.itf;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

import cn.edu.zucc.takeout.model.BeanGetmoney;
import cn.edu.zucc.takeout.model.BeanRider;
import cn.edu.zucc.takeout.util.BaseException;
import cn.edu.zucc.takeout.util.BusinessException;

public interface IRiderManager {
	List<BeanRider> loadAll() throws BaseException;

	void deleteRider(BeanRider rider) throws BaseException, SQLException;

	void changeRiderinfo(BeanRider rider, String rider_name, String rider_entrydate) throws BusinessException;

	BeanRider addRider(String rider_name, Timestamp rider_entrydate, String rider_identity, int com) throws BaseException;

}
