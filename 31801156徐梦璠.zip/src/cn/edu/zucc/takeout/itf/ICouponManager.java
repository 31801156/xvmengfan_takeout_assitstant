package cn.edu.zucc.takeout.itf;

import java.sql.Timestamp;
import java.util.List;

import cn.edu.zucc.takeout.model.BeanCoupon;
import cn.edu.zucc.takeout.model.BeanStore;
import cn.edu.zucc.takeout.util.DbException;

public interface ICouponManager {

	List<BeanCoupon> loadAll(BeanStore store) throws DbException;

	void addcoupon(int couponid, int couponmoney, int couponrequirenumber, Timestamp begin, Timestamp end) throws DbException;

	List<BeanCoupon> loadAll1() throws DbException;

}
