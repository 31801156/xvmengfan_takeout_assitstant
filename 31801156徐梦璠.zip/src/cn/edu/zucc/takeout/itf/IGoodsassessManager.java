package cn.edu.zucc.takeout.itf;

import java.util.List;

import cn.edu.zucc.takeout.model.BeanGooddetails;
import cn.edu.zucc.takeout.model.BeanGoodsassess;
import cn.edu.zucc.takeout.util.DbException;

public interface IGoodsassessManager {

	List<BeanGoodsassess> loadAll(BeanGooddetails gooddetails) throws DbException;

}
