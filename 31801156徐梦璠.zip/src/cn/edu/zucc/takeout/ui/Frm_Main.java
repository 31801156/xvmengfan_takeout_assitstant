package cn.edu.zucc.takeout.ui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import cn.edu.zucc.takeout.PersonPlanUtil;
import cn.edu.zucc.takeout.model.BeanAddress;
import cn.edu.zucc.takeout.model.BeanGooddetails;
import cn.edu.zucc.takeout.model.BeanGoodstype;
import cn.edu.zucc.takeout.model.BeanManager;
import cn.edu.zucc.takeout.model.BeanRider;
import cn.edu.zucc.takeout.model.BeanStore;
import cn.edu.zucc.takeout.model.BeanUser;
import cn.edu.zucc.takeout.util.BaseException;
import cn.edu.zucc.takeout.util.BusinessException;
import cn.edu.zucc.takeout.util.DBUtil;
import cn.edu.zucc.takeout.util.DbException;
import manager_to_add.FrmModifyRider;
import manager_to_add.FrmModifyStore;
import manager_to_add.FrmModifyUser;
import manager_to_modify.FrmModifyRiderinformation;

public class Frm_Main extends JFrame implements ActionListener {
//��ͬ����
	private static final long serialVersionUID = 1L;
	private JMenuBar menubar=new JMenuBar(); ;
    private JMenu menu_more=new JMenu("����");
    private JMenuItem  menuItem_modifyPwd=new JMenuItem("�޸��ҵ�����");
    //�û�����
    private JMenuItem  menuItem_seeinfo=new JMenuItem("�鿴�ҵĻ�����Ϣ");
    private JMenuItem  menuItem_seeaddress=new JMenuItem("�鿴�ҵ����͵�ַ");
    private JMenuItem  menuItem_modifyinformation=new JMenuItem("����/�޸��ҵĻ�����Ϣ");
    private JMenuItem  menuItem_mycoupon=new JMenuItem("�ҵļ�����ȯ");
    private JMenuItem  menuItem_mycoupon1=new JMenuItem("�ҵ��Ż�ȯ");
    private JMenuItem  menuItem_myaddress=new JMenuItem("�������͵�ַ");
    private JMenuItem  menuItem_myorder=new JMenuItem("�ҵĶ���");
//    private JMenuItem  menuItem_myorder1=new JMenuItem("�ҵĶ�������");
    private JMenuItem  menuItem_order=new JMenuItem("�̼�");
    private JMenuItem  menuItem_mybus=new JMenuItem("�ҵĹ��ﳵ");
    private JMenuItem  menuItem_bus=new JMenuItem("���빺�ﳵ");
    private JMenuItem  menuItem_placeorder=new JMenuItem("�µ�");
    private JMenuItem  menuItem_access=new JMenuItem("�ҵ�����");
    private JMenuItem  menuItem_storecoupon=new JMenuItem("�鿴�̼��Ż�ȯ");
    private JMenuItem  menuItem_storefullreduce=new JMenuItem("�鿴�̼�����");
    private JMenu  menu_hb=new JMenu("�����ȯ");
    private JMenu  menu_xx=new JMenu("�ҵ���Ϣ");
    private JMenu  menu_dd=new JMenu("�ҵĶ���");
    private JMenu  menu_oo=new JMenu("������");
    
    //����Ա����
    private JMenu menu_user=new JMenu("�û�����");
    private JMenu menu_store=new JMenu("�̼ҹ���");
    private JMenu menu_rider=new JMenu("���ֹ���");
    private JMenu menu_my=new JMenu("�ҵ���Ϣ");
    private JMenu menu_coupon=new JMenu("�Ż�ȯ��������");
    private JMenuItem  seeinfo=new JMenuItem("�鿴�ҵĻ�����Ϣ");
    private JMenuItem  a1=new JMenuItem("��ѯ�̼���Ϣ");
    private JMenuItem  a2=new JMenuItem("�����̼���Ϣ");
    private JMenuItem  a4=new JMenuItem("ɾ���̼���Ϣ");
    private JMenuItem  a11=new JMenuItem("�鿴�̼��Ż�ȯ��Ϣ");
    private JMenuItem  a5=new JMenuItem("���̼������Ż�ȯ��Ϣ");
    private JMenuItem  a12=new JMenuItem("�鿴�̼�������Ϣ");
    private JMenuItem  a13=new JMenuItem("���̼�����������Ϣ");
    private JMenuItem  a6=new JMenuItem("������Ʒ���");
    private JMenuItem  a7=new JMenuItem("������Ʒ����");
    private JMenuItem  a8=new JMenuItem("��ѯ��Ʒ����");
    private JMenuItem  b1=new JMenuItem("��ѯ������Ϣ");
    private JMenuItem  b2=new JMenuItem("����������Ϣ");
    private JMenuItem  b3=new JMenuItem("�޸�������Ϣ");
    private JMenuItem b4=new JMenuItem("ɾ��������Ϣ");
    private JMenuItem  b5=new JMenuItem("��ѯ��������");
    private JMenuItem  c1=new JMenuItem("��ѯ�û���Ϣ");
    private JMenuItem  c2=new JMenuItem("�����û���Ϣ");
    private JMenuItem  c3=new JMenuItem("�޸��û���Ϣ");
    private JMenuItem  c4=new JMenuItem("ɾ���û���Ϣ");
    private JMenuItem  d1=new JMenuItem("�����Ż�ȯ");
    private JMenuItem  d2=new JMenuItem("�鿴�Ż�ȯ");
    private JMenuItem  d3=new JMenuItem("��������");
    private JMenuItem  d4=new JMenuItem("�鿴����");
//    private JMenuItem  c5=new JMenuItem("�����û��Ż�ȯ����");
//    private JMenuItem  c6=new JMenuItem("��¼������ȯ");
//    private JMenuItem  c7=new JMenuItem("������Ʒ��������Ϣ");
//    private JMenuItem  c8=new JMenuItem("���Ӷ�����������Ϣ");
   
    
	private FrmLogin dlgLogin=null;
	private JPanel statusBar = new JPanel();


	
//�û��Ļ�����Ϣ
	private Object tblManager_see_userTitle[]=BeanUser.tableTitles;
	private Object tblManager_see_userData[][];
	DefaultTableModel tabManager_see_userModel=new DefaultTableModel();
	private  JTable dataTableManager_see_user=new JTable(tabManager_see_userModel);
	
	private BeanUser curUser=null;
	List<BeanUser> allUser=null;
	private Window dlg;
	private void reloadManager_see_user() throws BaseException{//���ǲ������ݣ���Ҫ��ʵ�����滻
		allUser=PersonPlanUtil.UserManager.loadAll1();
		tblManager_see_userData =  new Object[allUser.size()][BeanUser.tableTitles.length];
		for(int i=0;i<allUser.size();i++){
			for(int j=0;j<BeanUser.tableTitles.length;j++)
				tblManager_see_userData[i][j]=allUser.get(i).getCell(j);
		}
		tabManager_see_userModel.setDataVector(tblManager_see_userData,tblManager_see_userTitle);
		this.dataTableManager_see_user.validate();
		this.dataTableManager_see_user.repaint();
	}
//�̼ҵĻ�����Ϣ
	private Object tblManager_see_storeTitle[]=BeanStore.tableTitles;
	private Object tblManager_see_storeData[][];
	DefaultTableModel tabManager_see_storeModel=new DefaultTableModel();
	private  JTable dataTableManager_see_store=new JTable(tabManager_see_storeModel);
	
	private BeanStore curStore=null;
	List<BeanStore> allStore=null;
	//private Window dlg;
	private void reloadManager_see_store() throws BaseException{//���ǲ������ݣ���Ҫ��ʵ�����滻
		allStore=PersonPlanUtil.StoreManager.loadAll();
		tblManager_see_storeData =  new Object[allStore.size()][BeanStore.tableTitles.length];
		for(int i=0;i<allStore.size();i++){
			for(int j=0;j<BeanStore.tableTitles.length;j++)
				tblManager_see_storeData[i][j]=allStore.get(i).getCell(j);
		}
		tabManager_see_storeModel.setDataVector(tblManager_see_storeData,tblManager_see_storeTitle);
		this.dataTableManager_see_store.validate();
		this.dataTableManager_see_store.repaint();
	}
//��Ʒ�����Ϣ
	private Object tblGoodstypeTitle[]=BeanGoodstype.tableTitles;
	private Object tblGoodstypeData[][];
	DefaultTableModel tabGoodstypeModel=new DefaultTableModel();
	private JTable dataTableGoodstype=new JTable(tabGoodstypeModel);
	private BeanGoodstype curStoretype=null;
	List<BeanGoodstype> allStoretype=null;
	//private Window dlg;
	private void reloadGoodstype(int k) throws BaseException{//���ǲ������ݣ���Ҫ��ʵ�����滻
		if(k<0) {
			return;
		}
		curStore=allStore.get(k);
		try {
			allStoretype=PersonPlanUtil.GoodstypeManager.loadAll(curStore);
		} catch (BaseException e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
			return;
		}
		tblGoodstypeData =new Object[allStoretype.size()][BeanGoodstype.tableTitles.length];
		for(int i=0;i<allStoretype.size();i++){
			for(int j=0;j<BeanGoodstype.tableTitles.length;j++)
				tblGoodstypeData[i][j]=allStoretype.get(i).getCell(j);
		}
		
		tabGoodstypeModel.setDataVector(tblGoodstypeData,tblGoodstypeTitle);
		this.dataTableGoodstype.validate();
		this.dataTableGoodstype.repaint();
	}

//��Ʒ����
	private Object tblGooddetailsTitle[]=BeanGooddetails.tableTitles;
	private Object tblGooddetailsData[][];
	DefaultTableModel tabGooddetailsModel=new DefaultTableModel();
	private JTable dataTableGooddetails=new JTable(tabGooddetailsModel);
	List<BeanGooddetails> Typegoods=null;
	//private Window dlg;
	private void reloadGooddetails(int k) throws BaseException{//���ǲ������ݣ���Ҫ��ʵ�����滻
		if(k<0) {
			return;
		}
		curStoretype=allStoretype.get(k);
		try {
			Typegoods=PersonPlanUtil.GooddetailsManager.loadAll(curStoretype);
		} catch (BaseException e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
			return;
		}
		tblGooddetailsData =new Object[Typegoods.size()][BeanGooddetails.tableTitles.length];
		for(int i=0;i<Typegoods.size();i++){
			for(int j=0;j<BeanGooddetails.tableTitles.length;j++)
				tblGooddetailsData[i][j]=Typegoods.get(i).getCell(j);
		}
		
		tabGooddetailsModel.setDataVector(tblGooddetailsData,tblGooddetailsTitle);
		this.dataTableGooddetails.validate();
		this.dataTableGooddetails.repaint();
	}
//���ֵĻ�����Ϣ
	private Object tblManager_see_riderTitle[]=BeanRider.tableTitles;
	private Object tblManager_see_riderData[][];
	DefaultTableModel tabManager_see_riderModel=new DefaultTableModel();
	private  JTable dataTableManager_see_rider=new JTable(tabManager_see_riderModel);
	
	private BeanRider curRider=null;
	List<BeanRider> allRider=null;
//private Window dls;
	private void reloadManager_see_rider() throws BaseException{//���ǲ������ݣ���Ҫ��ʵ�����滻
		allRider=PersonPlanUtil.RiderManager.loadAll();
		tblManager_see_riderData =  new Object[allRider.size()][BeanRider.tableTitles.length];
		for(int i=0;i<allRider.size();i++){
			for(int j=0;j<BeanRider.tableTitles.length;j++)
				tblManager_see_riderData[i][j]=allRider.get(i).getCell(j);
		}
		tabManager_see_riderModel.setDataVector(tblManager_see_riderData,tblManager_see_riderTitle);
		this.dataTableManager_see_rider.validate();
		this.dataTableManager_see_rider.repaint();
	}
	public Frm_Main(){
		
		this.setExtendedState(Frame.MAXIMIZED_BOTH);
		dlgLogin=new FrmLogin(this,"��¼",true);
		dlgLogin.setVisible(true);
		
		if(!FrmLogin.c1.isSelected()) {
			this.setTitle("�������ֹ���ϵͳ(����Ա)");
			this.menu_user.add(this.c1); this.c1.addActionListener(this);
		    this.menu_user.add(this.c2); this.c2.addActionListener(this);
		    this.menu_user.add(this.c3); this.c3.addActionListener(this);
		    this.menu_user.add(this.c4); this.c4.addActionListener(this);
//		    this.menu_user.add(this.c5); this.c5.addActionListener(this);
//		    this.menu_user.add(this.c6); this.c6.addActionListener(this);
//		    this.menu_user.add(this.c7); this.c7.addActionListener(this);
//		    this.menu_user.add(this.c8); this.c8.addActionListener(this);
		    this.menu_store.add(this.a1); this.a1.addActionListener(this);
		    this.menu_store.add(this.a2); this.a2.addActionListener(this);
		    this.menu_store.add(this.a4); this.a4.addActionListener(this);
		    this.menu_store.add(this.a5); this.a5.addActionListener(this);
		    this.menu_store.add(this.a6); this.a6.addActionListener(this);
		    this.menu_store.add(this.a7); this.a7.addActionListener(this);
		    this.menu_store.add(this.a8); this.a8.addActionListener(this);
		    this.menu_store.add(this.a11); this.a11.addActionListener(this);
		    this.menu_store.add(this.a12); this.a12.addActionListener(this);
		    this.menu_store.add(this.a13); this.a13.addActionListener(this);
		    this.menu_rider.add(this.b1); this.b1.addActionListener(this);
		    this.menu_rider.add(this.b2); this.b2.addActionListener(this);
		    this.menu_rider.add(this.b3); this.b3.addActionListener(this);
		    this.menu_rider.add(this.b4); this.b4.addActionListener(this);
		    this.menu_rider.add(this.b5); this.b5.addActionListener(this);
		    this.menu_my.add(this.seeinfo); this.seeinfo.addActionListener(this);
		    this.menu_my.add(this.menuItem_modifyPwd); this.menuItem_modifyPwd.addActionListener(this);
		    this.menu_coupon.add(this.d1); this.d1.addActionListener(this);
		    this.menu_coupon.add(this.d2); this.d2.addActionListener(this);
		    this.menu_coupon.add(this.d3); this.d3.addActionListener(this);
		    this.menu_coupon.add(this.d4); this.d4.addActionListener(this);
		    
		    
		    menubar.add(menu_my);menubar.add(menu_user);menubar.add(menu_store);menubar.add(menu_rider);
		    menubar.add(menu_coupon);menubar.add(menu_more);
		    JScrollPane s1=new JScrollPane(this.dataTableManager_see_user);
		    this.getContentPane().add(s1, BorderLayout.NORTH);
		    
		    JScrollPane s2=new JScrollPane(this.dataTableManager_see_store);
		    this.getContentPane().add(s2, BorderLayout.WEST);
		    this.dataTableManager_see_store.addMouseListener(new MouseAdapter (){

						@Override
						public void mouseClicked(MouseEvent e) {
							int i=Frm_Main.this.dataTableManager_see_store.getSelectedRow();
							if(i<0) {
								return;
							}
							try {
								Frm_Main.this.reloadGoodstype(i);
							} catch (BaseException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						}
				    	
				    });
		    JScrollPane s3=new JScrollPane(this.dataTableGoodstype);
				    this.getContentPane().add(s3, BorderLayout.CENTER);
				    this.dataTableGoodstype.addMouseListener(new MouseAdapter (){

						@Override
						public void mouseClicked(MouseEvent e) {
							int i=Frm_Main.this.dataTableGoodstype.getSelectedRow();
							if(i<0) {
								return;
							}
							try {
								Frm_Main.this.reloadGooddetails(i);
							} catch (BaseException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						}
				    	
				    });
				    JScrollPane s4=new JScrollPane(this.dataTableGooddetails);
				    this.getContentPane().add(s4, BorderLayout.EAST);
//				    this.dataTableGooddetails.addMouseListener(new MouseAdapter (){
//
//						@Override
//						public void mouseClicked(MouseEvent e) {
//							int i=Frm_Main.this.dataTableGooddetails.getSelectedRow();
//							if(i<0) {
//								return;
//							}
//							try {
//								Frm_Main.this.reloadGooddetails(i);
//							} catch (BaseException e1) {
//								// TODO Auto-generated catch block
//								e1.printStackTrace();
//							}
//						}
//				    	
//				    });
		    
				    JScrollPane s5=new JScrollPane(this.dataTableManager_see_rider);
		    this.getContentPane().add(s5, BorderLayout.SOUTH);
		    this.setJMenuBar(menubar);
		   s1.setPreferredSize(new Dimension(0,300));
		   s2.setPreferredSize(new Dimension(600,80));
		   s3.setPreferredSize(new Dimension(50,80));
		   s4.setPreferredSize(new Dimension(500,80));
		   s5.setPreferredSize(new Dimension(0,200));
		    //״̬��
//		    statusBar.setLayout(new FlowLayout(FlowLayout.LEFT));
//		    JLabel label=new JLabel("����!");//�޸ĳ�   ���ã�+��½�û���
//		    statusBar.add(label);
//		    this.getContentPane().add(statusBar,BorderLayout.SOUTH);
		    this.addWindowListener(new WindowAdapter(){   
		    	public void windowClosing(WindowEvent e){ 
		    		System.exit(0);
	             }
	        });
		    this.setVisible(true);
		}
		else {
			this.setTitle("�������ֹ���ϵͳ(�û�)");
			this.menu_xx.add(this.menuItem_seeinfo); this.menuItem_seeinfo.addActionListener(this);
			this.menu_xx.add(this.menuItem_seeaddress); this.menuItem_seeaddress.addActionListener(this);
		    this.menu_xx.add(this.menuItem_modifyPwd); this.menuItem_modifyPwd.addActionListener(this);
		    this.menu_xx.add(this.menuItem_modifyinformation); this.menuItem_modifyinformation.addActionListener(this);
		    this.menu_xx.add(this.menuItem_myaddress); this.menuItem_myaddress.addActionListener(this);
		    this.menu_hb.add(this.menuItem_mycoupon); this.menuItem_mycoupon.addActionListener(this);
		    this.menu_hb.add(this.menuItem_mycoupon1); this.menuItem_mycoupon1.addActionListener(this);
		    this.menu_dd.add(this.menuItem_myorder); this.menuItem_myorder.addActionListener(this);
//		    this.menu_dd.add(this.menuItem_myorder1); this.menuItem_myorder1.addActionListener(this);
		    this.menu_oo.add(this.menuItem_order); this.menuItem_order.addActionListener(this);
		    this.menu_oo.add(this.menuItem_storecoupon); this.menuItem_storecoupon.addActionListener(this);
		    this.menu_oo.add(this.menuItem_storefullreduce); this.menuItem_storefullreduce.addActionListener(this);
		    this.menu_oo.add(this.menuItem_bus); this.menuItem_bus.addActionListener(this);
		    this.menu_oo.add(this.menuItem_mybus); this.menuItem_mybus.addActionListener(this);
		    this.menu_oo.add(this.menuItem_access); this.menuItem_access.addActionListener(this);
		    this.menu_oo.add(this.menuItem_placeorder); this.menuItem_placeorder.addActionListener(this);
		    menubar.add(menu_xx); menubar.add(menu_hb);menubar.add(menu_dd);
		    menubar.add(menu_oo);menubar.add(menu_more);
		    this.setJMenuBar(menubar);
		    this.getContentPane().add(new JScrollPane(this.dataTableManager_see_store), BorderLayout.WEST);
		    this.dataTableManager_see_store.addMouseListener(new MouseAdapter (){

				@Override
				public void mouseClicked(MouseEvent e) {
					int i=Frm_Main.this.dataTableManager_see_store.getSelectedRow();
					if(i<0) {
						return;
					}
					try {
						Frm_Main.this.reloadGoodstype(i);
					} catch (BaseException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
		    	
		    });
		    this.getContentPane().add(new JScrollPane(this.dataTableGoodstype), BorderLayout.CENTER);
		    this.dataTableGoodstype.addMouseListener(new MouseAdapter (){

				@Override
				public void mouseClicked(MouseEvent e) {
					int i=Frm_Main.this.dataTableGoodstype.getSelectedRow();
					if(i<0) {
						return;
					}
					try {
						Frm_Main.this.reloadGooddetails(i);
					} catch (BaseException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
		    	
		    });
		    this.getContentPane().add(new JScrollPane(this.dataTableGooddetails), BorderLayout.EAST);
		    //״̬��
		    statusBar.setLayout(new FlowLayout(FlowLayout.LEFT));
		    JLabel label=new JLabel("����!");//�޸ĳ�   ���ã�+��½�û���
		    statusBar.add(label);
		    this.getContentPane().add(statusBar,BorderLayout.SOUTH);
		    this.addWindowListener(new WindowAdapter(){   
		    	public void windowClosing(WindowEvent e){ 
		    		System.exit(0);
	             }
	        });
		    this.setVisible(true);
		}
		}
	  
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.menuItem_modifyPwd){
			FrmModifyPwd dlg=new FrmModifyPwd(this,"�����޸�",true,dlgLogin);
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.menuItem_modifyinformation){
			FrmModifyUserinformation dlg=new FrmModifyUserinformation(this,"����/�޸��ҵĻ�����Ϣ",true,dlgLogin,BeanUser.currentLoginUser);
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.menuItem_myaddress){
			FrmModifyAddress dlg=new FrmModifyAddress(this,"�������͵�ַ",true,dlgLogin);
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.menuItem_seeinfo){//�û��鿴�ҵĻ�����Ϣ
			Frm_info dlg=new Frm_info();
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.menuItem_seeaddress){//�û��鿴�ҵĵ�ַ
			Frm_address dlg=new Frm_address();
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.menuItem_mycoupon){//�û��鿴�ҵļ����Ż�ȯ
			Frm_order_conpon dlg=new Frm_order_conpon();
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.menuItem_mycoupon1){//�û��鿴�ҵ��Ż�ȯ
			Frm_Monifyusercoupon dlg=new Frm_Monifyusercoupon();
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.seeinfo){
			Frm_managerinfo dlg=new Frm_managerinfo();
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.c1){
			try {
				this.reloadManager_see_user();
			} catch (BaseException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		else if(e.getSource()==this.a1){
			try {
				this.reloadManager_see_store();
			} catch (BaseException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		else if(e.getSource()==this.b1){
			try {
				this.reloadManager_see_rider();
			} catch (BaseException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		else if(e.getSource()==this.c2){
			FrmModifyUser dlg=new FrmModifyUser(this,"�����û�",true,dlgLogin);
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.b2){
			FrmModifyRider dlg=new FrmModifyRider(this,"��������",true,dlgLogin);
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.a2){
			FrmModifyStore dlg=new FrmModifyStore(this,"�����̵�",true,dlgLogin);
			dlg.setVisible(true);
		}		
		else if(e.getSource()==this.a6){
			int i=Frm_Main.this.dataTableManager_see_store.getSelectedRow();
			if(i<0) {
				JOptionPane.showMessageDialog(null, "��ѡ���̵�", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			FrmModifyStoretype dlg=new FrmModifyStoretype(this,"������Ʒ���",true,dlgLogin,allStore.get(i));
			dlg.setVisible(true); 
		}	
		else if(e.getSource()==this.a8){
			int i=Frm_Main.this.dataTableGooddetails.getSelectedRow();
			if(i<0) {
				JOptionPane.showMessageDialog(null, "��ѡ����Ʒ", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			Frm_Goodsaccess dlg=new Frm_Goodsaccess(Typegoods.get(i));
			dlg.setVisible(true); 
		}
		else if(e.getSource()==this.a11){
			int i=Frm_Main.this.dataTableManager_see_store.getSelectedRow();
			if(i<0) {
				JOptionPane.showMessageDialog(null, "��ѡ���̵�", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			Frm_Storehavecoupon dlg=new Frm_Storehavecoupon(allStore.get(i));
			dlg.setVisible(true); 
		}
		else if(e.getSource()==this.menuItem_storecoupon){
			int i=Frm_Main.this.dataTableManager_see_store.getSelectedRow();
			if(i<0) {
				JOptionPane.showMessageDialog(null, "��ѡ���̵�", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			Frm_Storehavecoupon dlg=new Frm_Storehavecoupon(allStore.get(i));
			dlg.setVisible(true); 
		}
		else if(e.getSource()==this.a5){
			int i=Frm_Main.this.dataTableManager_see_store.getSelectedRow();
			if(i<0) {
				JOptionPane.showMessageDialog(null, "��ѡ���̵�", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			Frm_ModifyStorecoupon dlg=new Frm_ModifyStorecoupon(this,"�����̵��Ż�ȯ",true,dlgLogin,allStore.get(i));
			dlg.setVisible(true); 
		}
		else if(e.getSource()==this.a12){//�鿴����
			int i=Frm_Main.this.dataTableManager_see_store.getSelectedRow();
			if(i<0) {
				JOptionPane.showMessageDialog(null, "��ѡ���̵�", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			Frm_Store_seereduce dlg=new Frm_Store_seereduce(this,"�鿴�̵�����",true,dlgLogin,allStore.get(i));
			dlg.setVisible(true); 
		}	
		else if(e.getSource()==this.menuItem_storefullreduce){//�鿴����
			int i=Frm_Main.this.dataTableManager_see_store.getSelectedRow();
			if(i<0) {
				JOptionPane.showMessageDialog(null, "��ѡ���̵�", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			Frm_Store_seereduce dlg=new Frm_Store_seereduce(this,"�鿴�̵�����",true,dlgLogin,allStore.get(i));
			dlg.setVisible(true); 
		}	
		else if(e.getSource()==this.a13){//��������
			int i=Frm_Main.this.dataTableManager_see_store.getSelectedRow();
			if(i<0) {
				JOptionPane.showMessageDialog(null, "��ѡ���̵�", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			Frm_Store_addreduce dlg=new Frm_Store_addreduce(this,"�����̵�����",true,dlgLogin,allStore.get(i));
			dlg.setVisible(true); 
		}
		else if(e.getSource()==this.b5){//��ѯ��������
			int i=Frm_Main.this.dataTableManager_see_rider.getSelectedRow();
			if(i<0) {
				JOptionPane.showMessageDialog(null, "��ѡ������", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			System.out.print(allRider.get(i));
			Frm_Ridergetmoney dlg=new Frm_Ridergetmoney(allRider.get(i));
			dlg.setVisible(true); 
		}
		else if(e.getSource()==this.c4){
			int i=Frm_Main.this.dataTableManager_see_user.getSelectedRow();
			if(i<0) {
				JOptionPane.showMessageDialog(null, "��ѡ���û�", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			try {
				PersonPlanUtil.UserManager.deleteUser(allUser.get(i));
				} catch ( BaseException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
					return;
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
		}
		else if(e.getSource()==c3){
			int i=Frm_Main.this.dataTableManager_see_user.getSelectedRow();
			if(i<0) {
				JOptionPane.showMessageDialog(null, "��ѡ���û�", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			FrmModifyUserinformation dlg=new FrmModifyUserinformation(this,"�޸��û�������Ϣ",true,dlgLogin,allUser.get(i));
			dlg.setVisible(true);
		}
		else if(e.getSource()==b3){
			int i=Frm_Main.this.dataTableManager_see_rider.getSelectedRow();
			if(i<0) {
				JOptionPane.showMessageDialog(null, "��ѡ������", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			FrmModifyRiderinformation dlg=new FrmModifyRiderinformation(this,"�޸����ֻ�����Ϣ",true,dlgLogin,allRider.get(i));
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.a4){
			int i=Frm_Main.this.dataTableManager_see_store.getSelectedRow();
			if(i<0) {
				JOptionPane.showMessageDialog(null, "��ѡ���̵�", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			try {
				PersonPlanUtil.StoreManager.deleteStore(allStore.get(i));
				} catch ( BaseException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
					return;
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
		}
		else if(e.getSource()==this.a5){//���̼������Ż�ȯ��Ϣ
			int i=Frm_Main.this.dataTableManager_see_store.getSelectedRow();
			if(i<0) {
				JOptionPane.showMessageDialog(null, "��ѡ���̵�", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			Frm_ModifyStorecoupon dlg=new Frm_ModifyStorecoupon(this,"���̼������Ż�ȯ",true,dlgLogin,allStore.get(i));
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.a7){//������Ʒ����
			int i=Frm_Main.this.dataTableGoodstype.getSelectedRow();
			if(i<0) {
				JOptionPane.showMessageDialog(null, "��ѡ����Ʒ����", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			Frm_Modifytypegooods dlg=new Frm_Modifytypegooods(this,"������Ʒ����",true,dlgLogin,allStoretype.get(i));
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.b4){
			int i=Frm_Main.this.dataTableManager_see_rider.getSelectedRow();
			if(i<0) {
				JOptionPane.showMessageDialog(null, "��ѡ������", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			try {
				PersonPlanUtil.RiderManager.deleteRider(allRider.get(i));
				} catch ( BaseException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
					return;
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
		}
		else if(e.getSource()==this.d1){//�����Ż�ȯ
			Frm_Modifycoupon dlg=new Frm_Modifycoupon(this,"�����Ż�ȯ",true,dlgLogin);
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.d2){//�鿴�Ż�ȯ
			Frm_seecoupon dlg=new Frm_seecoupon(this,"�鿴�Ż�ȯ",true,dlgLogin);
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.d3){//��������
			Frm_Modifyfullreduce dlg=new Frm_Modifyfullreduce(this,"��������",true,dlgLogin);
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.d4){//�鿴����
			Frm_seefullreduce dlg=new Frm_seefullreduce(this,"�鿴����",true,dlgLogin);
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.menuItem_myorder){
			Frm_Goods_order_and_Order_details dlg=new Frm_Goods_order_and_Order_details(this,"�ҵĶ���",true,dlgLogin);
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.menuItem_order){
			try {
				this.reloadManager_see_store();
			} catch (BaseException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		else if(e.getSource()==this.menuItem_bus){
			int i=Frm_Main.this.dataTableManager_see_store.getSelectedRow();
			int j=Frm_Main.this.dataTableGoodstype.getSelectedRow();
			int k=Frm_Main.this.dataTableGooddetails.getSelectedRow();
			if(i<0||j<0||k<0) {
				JOptionPane.showMessageDialog(null, "��ѡ����Ʒ", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			Frm_Modifyshoppingcart dlg=new Frm_Modifyshoppingcart(this,"���빺�ﳵ",true,dlgLogin,allStore.get(i),allStoretype.get(j),Typegoods.get(k));
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.menuItem_mybus){
			try {
				Frm_see_shoppingcart dlg=new Frm_see_shoppingcart(this,"�ҵĹ��ﳵ",true,dlgLogin);
				dlg.setVisible(true);
			} catch (DbException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		else if(e.getSource()==this.menuItem_placeorder){
			int i=Frm_Main.this.dataTableManager_see_store.getSelectedRow();
			int j=Frm_Main.this.dataTableGoodstype.getSelectedRow();
			int k=Frm_Main.this.dataTableGooddetails.getSelectedRow();
			if(i<0||j<0||k<0) {
				JOptionPane.showMessageDialog(null, "��ѡ��,ѡ���̵�;ע���µ�ʱ����ͬʱ��һ���̵�ķ�������Ʒ(�������)", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			Frm_Modifyplaceorder dlg=new Frm_Modifyplaceorder(this,"�µ�",true,dlgLogin,allStore.get(i),allStoretype.get(j),Typegoods.get(k));
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.menuItem_access){
			try {
				Frm_see_myassess dlg=new Frm_see_myassess(this,"�ҵ�����",true,dlgLogin);
				dlg.setVisible(true);
			} catch (DbException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
	}