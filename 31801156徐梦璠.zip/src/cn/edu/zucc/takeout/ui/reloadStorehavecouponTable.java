
package cn.edu.zucc.takeout.ui;
import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import cn.edu.zucc.takeout.PersonPlanUtil;
import cn.edu.zucc.takeout.model.BeanCoupon;
import cn.edu.zucc.takeout.model.BeanStore;
import cn.edu.zucc.takeout.model.BeanUserconpon;
import cn.edu.zucc.takeout.util.BaseException;
import cn.edu.zucc.takeout.util.DbException;

public class reloadStorehavecouponTable{

	Object tblStorehavecouponTitle[]=BeanCoupon.tableTitles;
	Object tblStorehavecouponData[][];
	static DefaultTableModel tabStorehavecouponModel=new DefaultTableModel();
	static JTable dataTableStorehavecoupon=new JTable(tabStorehavecouponModel);
	
	BeanCoupon curStorehavecoupon=null;
	List<BeanCoupon> allStorehavecoupon=null;
	public reloadStorehavecouponTable(BeanStore store) throws DbException{
		allStorehavecoupon=PersonPlanUtil.CouponManager.loadAll(store);
		tblStorehavecouponData =  new Object[allStorehavecoupon.size()][BeanCoupon.tableTitles.length];
		System.out.print(allStorehavecoupon.size());
		for(int i=0;i<allStorehavecoupon.size();i++){
			for(int j=0;j<BeanCoupon.tableTitles.length;j++)
				tblStorehavecouponData[i][j]=allStorehavecoupon.get(i).getCell(j);
		}
		tabStorehavecouponModel.setDataVector(tblStorehavecouponData,tblStorehavecouponTitle);
		this.dataTableStorehavecoupon.validate();
		this.dataTableStorehavecoupon.repaint();
	}
}