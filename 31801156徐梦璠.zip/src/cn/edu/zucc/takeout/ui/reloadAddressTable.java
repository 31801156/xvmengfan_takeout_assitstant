package cn.edu.zucc.takeout.ui;

import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import cn.edu.zucc.takeout.PersonPlanUtil;
import cn.edu.zucc.takeout.model.BeanAddress;
import cn.edu.zucc.takeout.util.BaseException;

public class reloadAddressTable {
//	�ҵ����͵�ַ
	Object tblAddressTitle[]=BeanAddress.tableTitles;
	Object tblAddressData[][];
	static DefaultTableModel tabAddressModel=new DefaultTableModel();
	static JTable dataTableAddress=new JTable(tabAddressModel);
	
	BeanAddress curAddress=null;
	List<BeanAddress> allAddress=null;
	public reloadAddressTable(){
		try {
			allAddress=PersonPlanUtil.AddressManager.loadAll();
		} catch (BaseException e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
			return;
		}
		tblAddressData =  new Object[allAddress.size()][BeanAddress.tableTitles.length];
		System.out.print(allAddress.size());
		for(int i=0;i<allAddress.size();i++){
			for(int j=0;j<BeanAddress.tableTitles.length;j++)
				tblAddressData[i][j]=allAddress.get(i).getCell(j);
		}
		tabAddressModel.setDataVector(tblAddressData,tblAddressTitle);
		this.dataTableAddress.validate();
		this.dataTableAddress.repaint();
	}
}