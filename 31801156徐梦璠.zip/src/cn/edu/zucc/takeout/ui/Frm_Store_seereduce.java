
package cn.edu.zucc.takeout.ui;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import cn.edu.zucc.takeout.model.BeanStore;
import cn.edu.zucc.takeout.model.BeanUser;
import cn.edu.zucc.takeout.util.DbException;

public class Frm_Store_seereduce extends JDialog implements ActionListener {
	private JPanel toolBar = new JPanel();
	private Button btnOk = new Button("ȷ��");
	private Button btnCancel = new Button("ȡ��");
	
	public Frm_Store_seereduce(Frame f, String s, boolean b,FrmLogin dlgLogin,BeanStore store) {
		this.getContentPane().add(new JScrollPane(reloadStore_seereduceTable.dataTableStore_seereduce), BorderLayout.WEST);
		try {
			new reloadStore_seereduceTable(store);
		} catch (DbException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
		toolBar.add(btnOk);
		toolBar.add(btnCancel);
		this .getContentPane().add(toolBar, BorderLayout.SOUTH);
		this.setSize(800, 500);
		
		// ��Ļ������ʾ
				double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
				double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
				this.setLocation((int) (width - this.getWidth()) / 2,
						(int) (height - this.getHeight()) / 2);
				
		this.btnCancel.addActionListener(this);
		this.btnOk.addActionListener(this);
		}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.btnCancel)
			this.setVisible(false);
		else if(e.getSource()==this.btnOk){
			;
			this.setVisible(false);
		}	
		
	}

}
