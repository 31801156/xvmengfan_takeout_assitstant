package cn.edu.zucc.takeout.ui;

import java.sql.Connection;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import cn.edu.zucc.takeout.model.BeanGoods_order;
import cn.edu.zucc.takeout.model.BeanUser;
import cn.edu.zucc.takeout.util.BaseException;
import cn.edu.zucc.takeout.util.DBUtil;
import cn.edu.zucc.takeout.util.DbException;

public class Frm_getgoods {

	public Frm_getgoods(BeanGoods_order goodsorder) throws DbException {
		if(!(goodsorder.getOrder_status().equals("��ʱ")||goodsorder.getOrder_status().equals("������"))) {
			JOptionPane.showMessageDialog(null, "�ö������ջ�!!!", "����",JOptionPane.ERROR_MESSAGE);
			return;
		}
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			conn.setAutoCommit(false);
			String sql="update goods_order set order_status=? where order_status=? or order_status=? "
					+ "and order_id=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,"���ʹ�");
			pst.setString(2,"��ʱ");
			pst.setString(3,"������");
			pst.setInt(4,goodsorder.getOrder_id());
			pst.execute();
			BeanGoods_order a=new BeanGoods_order();
			a.setOrder_status("���ʹ�");
			
			sql="select rider_id,rider_identity,completecount from rider where rider_id=?";
			pst=conn.prepareStatement(sql);
			pst.setInt(1,goodsorder.getRider_id());
			java.sql.ResultSet rs=pst.executeQuery();
			String identity=null;
			int completecount=0;
			double pergetmoney=0;
			if(rs.next()){
				identity=rs.getString(2);
				completecount=rs.getInt(3);
				
				if(identity.equals("����")) {
					pergetmoney=pergetmoney+0.5;
				if(completecount<100)
					pergetmoney=pergetmoney+2;
				else if(completecount>=100&&completecount<300)
					pergetmoney=pergetmoney+3;
				else if(completecount>=300&&completecount<450)
					pergetmoney=pergetmoney+5;
				else if(completecount>=450&&completecount<550) {
					if(completecount>500) {
						pergetmoney=pergetmoney+6.5;
					}
					else
						pergetmoney=pergetmoney+6;
				}
				else if(completecount>=550&&completecount<650)
					pergetmoney=pergetmoney+7.5;
				else if(completecount>=650)
					pergetmoney=pergetmoney+8.5;
				}
				else {
					
					if(completecount<100)
						pergetmoney=pergetmoney+2;
					else if(completecount>=100&&completecount<300)
						pergetmoney=pergetmoney+3;
					else if(completecount>=300&&completecount<450)
						pergetmoney=pergetmoney+5;
					else if(completecount>=450&&completecount<550)
							pergetmoney=pergetmoney+6;
					else if(completecount>=550&&completecount<650)
						pergetmoney=pergetmoney+7;
					else if(completecount>=650)
						pergetmoney=pergetmoney+8;
					
				}
				
				}
			sql="update getmoney set gettime=?,income=income+? where rider_id=? and order_id=?";
			pst=conn.prepareStatement(sql);
			pst.setTimestamp(1,new java.sql.Timestamp(System.currentTimeMillis()));
			pst.setDouble(2,pergetmoney);
			pst.setInt(3,goodsorder.getRider_id());
			pst.setInt(4,goodsorder.getOrder_id());
			pst.execute();
			
			sql="update rider set completecount=completecount+1 where rider_id=?";
			pst=conn.prepareStatement(sql);
			pst.setInt(1,goodsorder.getRider_id());
			pst.execute();
			
			
			sql="update orders_conpons set ordercount=ordercount+1 "
					+ "where coupon_id=? and store_id=? and user_id="+BeanUser.currentLoginUser.getUser_id();
			pst=conn.prepareStatement(sql);
			pst.setInt(1,goodsorder.getCoupon_id());
			pst.setInt(2,goodsorder.getStore_id());
			pst.execute();
			
			
			sql="select user_id,store_id,coupon_id,coupon_require_number,"
					+ "ordercount from orders_conpons"
					+ " where store_id=? and coupon_id=? and user_id="+BeanUser.currentLoginUser.getUser_id();
			pst=conn.prepareStatement(sql);
			pst.setInt(1,goodsorder.getStore_id());
			pst.setInt(2,goodsorder.getCoupon_id());
			pst.execute();
			rs=pst.executeQuery();
			int couponrequirenumber=0;int ordercount=0;
			if(rs.next()) {
				couponrequirenumber=rs.getInt(4);
				ordercount=rs.getInt(5);
				if(ordercount>=couponrequirenumber) {
					sql="update orders_conpons set ordercount=ordercount-coupon_require_number "
							+ "where coupon_id=? and store_id=? and user_id="+BeanUser.currentLoginUser.getUser_id();
					pst=conn.prepareStatement(sql);
					pst.setInt(1,goodsorder.getCoupon_id());
					pst.setInt(2,goodsorder.getStore_id());
					pst.execute();
					
					sql="update usercoupon set coupon_count=coupon_count+1 where"
							+ "store_id=? and coupon_id=? and user_id="+BeanUser.currentLoginUser.getUser_id();
					pst=conn.prepareStatement(sql);
					pst.setInt(1,goodsorder.getStore_id());
					pst.setInt(2,goodsorder.getCoupon_id());
					pst.execute();
				}
				
				
			}
			
			sql="update store set store_totalsales=store_totalsales+1,store_per_consumption"
					+ "=(store_per_consumption*(store_totalsales-1)+?)/store_totalsales "
					+ "where store_id=?";
			pst=conn.prepareStatement(sql);
			pst.setInt(1,(int) goodsorder.getEnd_money());
			pst.setInt(2,goodsorder.getStore_id());
			pst.execute();
			conn.commit();
			
		}catch(SQLException ex) {
	        ex.printStackTrace();
			try {
				conn.rollback();
			}catch(SQLException e) {
				e.printStackTrace();
			}
			throw new DbException(ex);
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
	}}

