
package cn.edu.zucc.takeout.ui;
import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import cn.edu.zucc.takeout.PersonPlanUtil;
import cn.edu.zucc.takeout.model.BeanFullreduction;
import cn.edu.zucc.takeout.model.BeanStore;
import cn.edu.zucc.takeout.util.BaseException;
import cn.edu.zucc.takeout.util.DbException;

public class reloadStore_seereduceTable{

	Object tblStore_seereduceTitle[]=BeanFullreduction.tableTitles;
	Object tblStore_seereduceData[][];
	static DefaultTableModel tabStore_seereduceModel=new DefaultTableModel();
	static JTable dataTableStore_seereduce=new JTable(tabStore_seereduceModel);
	
	BeanFullreduction curStore_seereduce=null;
	List<BeanFullreduction> allStore_seereduce=null;
	public reloadStore_seereduceTable(BeanStore store) throws DbException{
		allStore_seereduce=PersonPlanUtil.FullreductionManager.loadAll(store);
		tblStore_seereduceData =  new Object[allStore_seereduce.size()][BeanFullreduction.tableTitles.length];
		for(int i=0;i<allStore_seereduce.size();i++){
			for(int j=0;j<BeanFullreduction.tableTitles.length;j++)
				tblStore_seereduceData[i][j]=allStore_seereduce.get(i).getCell(j);
		}
		tabStore_seereduceModel.setDataVector(tblStore_seereduceData,tblStore_seereduceTitle);
		this.dataTableStore_seereduce.validate();
		this.dataTableStore_seereduce.repaint();
	}
}