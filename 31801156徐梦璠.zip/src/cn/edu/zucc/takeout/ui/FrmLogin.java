package cn.edu.zucc.takeout.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import cn.edu.zucc.takeout.PersonPlanUtil;
import cn.edu.zucc.takeout.model.BeanManager;
import cn.edu.zucc.takeout.model.BeanUser;
import cn.edu.zucc.takeout.util.BaseException;

import javax.swing.JFrame;   //�������� (���)
import javax.swing.JPanel; //�м����� 
import javax.swing.JLabel;   //��ǩ
import javax.swing.JRadioButton; //��ѡ��ʵ����
import javax.swing.ButtonGroup;
import javax.swing.JFrame;   //�������� (���)
import javax.swing.JPanel; //�м����� 
import javax.swing.JLabel;   //��ǩ
import javax.swing.JRadioButton; //��ѡ��ʵ����
import javax.swing.ButtonGroup;

public class FrmLogin extends JDialog implements ActionListener {
	private JPanel toolBar = new JPanel();
	private JPanel workPane = new JPanel();
	private JButton btnLogin = new JButton("��¼");
	private JButton btnCancel = new JButton("�˳�");
	private JButton btnRegister = new JButton("ע��");
	static JRadioButton c1 = new JRadioButton("�û�",true);
	static JRadioButton c2 = new JRadioButton("����Ա");
	private JLabel labelUser = new JLabel("*�û�����");
	private JLabel labelPwd = new JLabel(" *���룺");
	private JTextField edtUsername = new JTextField(24);
	private JPasswordField edtPwd = new JPasswordField(24);
	public FrmLogin(Frame f, String s, boolean b) {
		super(f, s, b);
		ButtonGroup  group= new ButtonGroup();
		group.add(c1);
		group.add(c2);
		toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
		toolBar.add(c1);
		toolBar.add(c2);

		toolBar.add(this.btnRegister);
		toolBar.add(btnLogin);
		toolBar.add(btnCancel);
		
		workPane.add(labelUser);
		workPane.add(edtUsername);
		workPane.add(labelPwd);
		workPane.add(edtPwd); 
		this.getContentPane().add(workPane, BorderLayout.CENTER);
		this.getContentPane().add(toolBar, BorderLayout.SOUTH);
		this.setSize(350,160);
		// ��Ļ������ʾ
		double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		this.setLocation((int) (width - this.getWidth()) / 2,
				(int) (height - this.getHeight()) / 2);
       

		btnLogin.addActionListener(this);
		btnCancel.addActionListener(this);
		this.btnRegister.addActionListener(this);

		
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
	}
	

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == this.btnLogin&&c1.isSelected()) {
			String username=this.edtUsername.getText();
			String pwd=new String(this.edtPwd.getPassword());
			try {
				BeanUser.currentLoginUser= PersonPlanUtil.UserManager.login(username, pwd);
			} catch (BaseException e1) {
				JOptionPane.showMessageDialog(null, e1.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			this.setVisible(false);
		}
		else if(e.getSource() == this.btnLogin&&c2.isSelected()) {
			String managername=this.edtUsername.getText(); 
			String pwd=new String(this.edtPwd.getPassword());
			try {
				BeanManager.currentLoginUser= PersonPlanUtil.ManagerManager.login(managername, pwd);
			} catch (BaseException e1) {
				JOptionPane.showMessageDialog(null, e1.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			this.setVisible(false);
			
		}
		
		else if (e.getSource() == this.btnCancel) {
			System.exit(0);
		} else if(e.getSource()==this.btnRegister&&c1.isSelected()){
			FrmRegister dlg=new FrmRegister(this,"ע��",true,1);
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.btnRegister&&c2.isSelected()){
			FrmRegister dlg=new FrmRegister(this,"ע��",true,2);
			dlg.setVisible(true);
		}
	}

}
