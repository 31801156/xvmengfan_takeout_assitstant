package cn.edu.zucc.takeout.ui;
import java.util.List;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import cn.edu.zucc.takeout.PersonPlanUtil;
import cn.edu.zucc.takeout.model.BeanUser;
import cn.edu.zucc.takeout.util.BaseException;

import javax.swing.JOptionPane;


public class reloadUserTable {
//	�ҵ����͵�ַ
	Object tblUserTitle[]=BeanUser.tableTitles;
	Object tblUserData[][];
	static DefaultTableModel tabUserModel=new DefaultTableModel();
	public static JTable dataTableUser=new JTable(tabUserModel);
	
	BeanUser curUser=null;
	List<BeanUser> allUser=null;
	public reloadUserTable(){
		try {
			System.out.print(BeanUser.currentLoginUser.getUser_id());
			allUser=PersonPlanUtil.UserManager.loadAll();
		} catch (BaseException e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
			return;
		}
		tblUserData =  new Object[allUser.size()][BeanUser.tableTitles.length];
		for(int i=0;i<allUser.size();i++){
			for(int j=0;j<BeanUser.tableTitles.length;j++)
				tblUserData[i][j]=allUser.get(i).getCell(j);
		}
		tabUserModel.setDataVector(tblUserData,tblUserTitle);
		this.dataTableUser.validate();
		this.dataTableUser.repaint();
	}
}