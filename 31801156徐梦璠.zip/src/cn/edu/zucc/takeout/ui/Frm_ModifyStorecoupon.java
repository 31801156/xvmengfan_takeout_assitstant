
package cn.edu.zucc.takeout.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import cn.edu.zucc.takeout.PersonPlanUtil;
import cn.edu.zucc.takeout.model.BeanGooddetails;
import cn.edu.zucc.takeout.model.BeanManager;
import cn.edu.zucc.takeout.model.BeanStore;
import cn.edu.zucc.takeout.model.BeanUserconpon;
import cn.edu.zucc.takeout.util.BaseException;
import cn.edu.zucc.takeout.util.BusinessException;
import cn.edu.zucc.takeout.util.DBUtil;
import cn.edu.zucc.takeout.util.DbException;

public class Frm_ModifyStorecoupon extends JDialog implements ActionListener {
	private JPanel toolBar = new JPanel();
	private JPanel workPane = new JPanel();
	private Button btnOk = new Button("ȷ��");
	private Button btnCancel = new Button("ȡ��");
	

	private JLabel conponid = new JLabel("*�Ż�ȯID: ");
	private JTextField edtconponid = new JTextField(18);
	private FrmLogin dlgLogin=null;
	private BeanStore store=null;
	public Frm_ModifyStorecoupon(Frame f, String s, boolean b,FrmLogin dlgLogin, BeanStore store) {
		super(f, s, b);
		this.dlgLogin=dlgLogin;
		this.store=store;
		toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
		toolBar.add(this.btnOk);
		toolBar.add(btnCancel);
		this.getContentPane().add(toolBar, BorderLayout.SOUTH);
		workPane.add(conponid);
		workPane.add(edtconponid);
		this.getContentPane().add(workPane, BorderLayout.CENTER);
		this.setSize(300, 180);
		
		// ��Ļ������ʾ
				double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
				double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
				this.setLocation((int) (width - this.getWidth()) / 2,
						(int) (height - this.getHeight()) / 2);
				
		this.btnCancel.addActionListener(this);
		this.btnOk.addActionListener(this);
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.btnCancel)
			this.setVisible(false);
		else if(e.getSource()==this.btnOk){
			System.out.print("this.btnOk");
			Connection conn=null;
			try {
				conn=DBUtil.getConnection();
				conn.setAutoCommit(false);
				int conid=Integer.parseInt(this.edtconponid.getText());
				
				String sql="insert into relationship_store_coupon(store_id,coupon_id) values(?,?)";
				java.sql.PreparedStatement pst=conn.prepareStatement(sql);
					pst.setInt(1,store.getStore_id());
					pst.setInt(2,conid);
					pst.execute();
					
			sql="select coupon_id,coupon_money,coupon_require_number,coupon_end_time"
					+ " from coupon where coupon_id=?";
			pst=conn.prepareStatement(sql);
			pst.setInt(1,conid);
			java.sql.ResultSet rs=pst.executeQuery();
			int couponmoney = 0;int coupon_require_number = 0;Timestamp coupon_end_time = null;
			if(rs.next()) {
				couponmoney=rs.getInt(2);
				coupon_require_number=rs.getInt(3);		
				coupon_end_time=rs.getTimestamp(4);		
			}
			rs.close();
			
			sql="insert into usercoupon(user_id,coupon_id,store_id,coupon_money,coupon_count,coupon_end_time)"
					+ "(select user_id,?,?,?,0,? from user)";
			pst=conn.prepareStatement(sql);
			pst.setInt(1,conid);		
			pst.setInt(2,store.getStore_id());	
			pst.setInt(3,couponmoney);	
			pst.setTimestamp(4,coupon_end_time);
			pst.execute();
			BeanUserconpon c=new BeanUserconpon();
			c.setCoupon_id(conid);		
			c.setStore_id(store.getStore_id());	
			c.setCoupon_money(couponmoney);	
			c.setCoupon_end_time(coupon_end_time);
			
			sql="insert into orders_conpons(user_id,store_id,coupon_id,coupon_require_number,ordercount)"
					+ "(select user_id,?,?,?,0 from user)";
			pst=conn.prepareStatement(sql);
			pst.setInt(1,store.getStore_id());		
			pst.setInt(2,conid);	
			pst.setInt(3,coupon_require_number);
			pst.execute();
					
			pst.close();
			conn.commit();
			}catch(SQLException ex) {
		        ex.printStackTrace();
				try {
					conn.rollback();
				}catch(SQLException e1) {
					e1.printStackTrace();
				}
			}finally {
				if(conn!=null) {
					try {
						conn.close();
					}catch(SQLException e1) {
						e1.printStackTrace();
					}
				}
			}
			this.setVisible(false);
		}

	}}