
package cn.edu.zucc.takeout.ui;
import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import cn.edu.zucc.takeout.PersonPlanUtil;
import cn.edu.zucc.takeout.model.BeanCoupon;
import cn.edu.zucc.takeout.model.BeanFullreduction;
import cn.edu.zucc.takeout.util.BaseException;
import cn.edu.zucc.takeout.util.DbException;

public class reloadseefullreduceTable {

	Object tblseefullreduceTitle[]=BeanFullreduction.tableTitles;
	Object tblseefullreduceData[][];
	static DefaultTableModel tabseefullreduceModel=new DefaultTableModel();
	static JTable dataTableseefullreduce=new JTable(tabseefullreduceModel);
	
	BeanFullreduction curseefullreduce=null;
	List<BeanFullreduction> allseefullreduce=null;
	public reloadseefullreduceTable() throws DbException{
		allseefullreduce=PersonPlanUtil.FullreductionManager.loadAll1();
		tblseefullreduceData =  new Object[allseefullreduce.size()][BeanFullreduction.tableTitles.length];
		for(int i=0;i<allseefullreduce.size();i++){
			for(int j=0;j<BeanFullreduction.tableTitles.length;j++)
				tblseefullreduceData[i][j]=allseefullreduce.get(i).getCell(j);
		}
		tabseefullreduceModel.setDataVector(tblseefullreduceData,tblseefullreduceTitle);
		this.dataTableseefullreduce.validate();
		this.dataTableseefullreduce.repaint();
	}
}