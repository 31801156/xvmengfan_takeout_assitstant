package cn.edu.zucc.takeout.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import cn.edu.zucc.takeout.PersonPlanUtil;
import cn.edu.zucc.takeout.model.BeanGooddetails;
import cn.edu.zucc.takeout.model.BeanGoodstype;
import cn.edu.zucc.takeout.model.BeanManager;
import cn.edu.zucc.takeout.model.BeanStore;
import cn.edu.zucc.takeout.util.BaseException;
import cn.edu.zucc.takeout.util.BusinessException;
import cn.edu.zucc.takeout.util.DBUtil;
import cn.edu.zucc.takeout.util.DbException;

public class Frm_Modifyshoppingcart extends JDialog implements ActionListener {
	private JPanel toolBar = new JPanel();
	private JPanel workPane = new JPanel();
	private Button btnOk = new Button("ȷ��");
	private Button btnCancel = new Button("ȡ��");
	
	private FrmLogin dlgLogin=null;
	private BeanStore store=null;
	private BeanGoodstype goodstype=null;
	private BeanGooddetails gooddetails=null;
	public Frm_Modifyshoppingcart(Frame f, String s, boolean b,FrmLogin dlgLogin, BeanStore store,BeanGoodstype goodstype, BeanGooddetails gooddetails) {
		super(f, s, b);
		this.dlgLogin=dlgLogin;
		this.store=store;
		this.goodstype=goodstype;
		this.gooddetails=gooddetails;
		toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
		toolBar.add(this.btnOk);
		toolBar.add(btnCancel);
		this.getContentPane().add(toolBar, BorderLayout.SOUTH);
		this.getContentPane().add(workPane, BorderLayout.CENTER);
		this.setSize(300, 180);
		
		// ��Ļ������ʾ
				double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
				double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
				this.setLocation((int) (width - this.getWidth()) / 2,
						(int) (height - this.getHeight()) / 2);
				
		this.btnCancel.addActionListener(this);
		this.btnOk.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.btnCancel)
			this.setVisible(false);
		else if(e.getSource()==this.btnOk){
			try {
				try {
					PersonPlanUtil.UserManager.addgoodsorder(this.store,this.goodstype,this.gooddetails);
				} catch (BusinessException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			} catch (NumberFormatException e1) {
				e1.printStackTrace();
			} catch (DbException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			this.setVisible(false);
		}	
		
	}
	}