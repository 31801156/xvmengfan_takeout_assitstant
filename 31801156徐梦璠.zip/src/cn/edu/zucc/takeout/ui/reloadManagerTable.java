package cn.edu.zucc.takeout.ui;
import java.util.List;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import cn.edu.zucc.takeout.PersonPlanUtil;
import cn.edu.zucc.takeout.model.BeanManager;
import cn.edu.zucc.takeout.util.BaseException;

import javax.swing.JOptionPane;


public class reloadManagerTable {
//	�ҵ����͵�ַ
	Object tblManagerTitle[]=BeanManager.tableTitles;
	Object tblManagerData[][];
	static DefaultTableModel tabManagerModel=new DefaultTableModel();
	static JTable dataTableManager=new JTable(tabManagerModel);
	
	BeanManager curManager=null;
	List<BeanManager> allManager=null;
	public reloadManagerTable(){
		try {
			allManager=PersonPlanUtil.ManagerManager.loadAll();
		} catch (BaseException e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
			return;
		}
		tblManagerData =  new Object[allManager.size()][BeanManager.tableTitles.length];
		System.out.print(allManager.size());
		for(int i=0;i<allManager.size();i++){
			for(int j=0;j<BeanManager.tableTitles.length;j++)
				tblManagerData[i][j]=allManager.get(i).getCell(j);
		}
		tabManagerModel.setDataVector(tblManagerData,tblManagerTitle);
		this.dataTableManager.validate();
		this.dataTableManager.repaint();
	}
}