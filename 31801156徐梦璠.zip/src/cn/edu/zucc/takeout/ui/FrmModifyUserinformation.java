
package cn.edu.zucc.takeout.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import cn.edu.zucc.takeout.PersonPlanUtil;
import cn.edu.zucc.takeout.model.BeanManager;
import cn.edu.zucc.takeout.model.BeanUser;
import cn.edu.zucc.takeout.util.BaseException;
import cn.edu.zucc.takeout.util.DbException;

public class FrmModifyUserinformation extends JDialog implements ActionListener {
	private JPanel toolBar = new JPanel();
	private JPanel workPane = new JPanel();
	private Button btnOk = new Button("ȷ��");
	private Button btnCancel = new Button("ȡ��");
	

	private JLabel sex = new JLabel("*�Ա� ��  ");
	private JLabel phonenumber = new JLabel("*�ֻ����룺");
	private JLabel email = new JLabel("*���� ��  ");
	private JLabel city = new JLabel("*���ڳ��У�");
	private JLabel member = new JLabel("*�Ƿ��Ա(1��0)��");
	private JTextField edtsex = new JTextField(18);
	private JTextField edtphonenumber = new JTextField(18);
	private JTextField edtemail = new JTextField(18);
	private JTextField edtcity = new JTextField(18);
	private JTextField edtmember = new JTextField(18);
	private FrmLogin dlgLogin=null;
	private BeanUser user=null;
	public FrmModifyUserinformation(Frame f, String s, boolean b,FrmLogin dlgLogin,BeanUser user) {
		super(f, s, b);
		this.dlgLogin=dlgLogin;
		this.user=user;
		toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
		toolBar.add(this.btnOk);
		toolBar.add(btnCancel);
		this.getContentPane().add(toolBar, BorderLayout.SOUTH);
		workPane.add(sex);
		workPane.add(edtsex);
		workPane.add(phonenumber);
		workPane.add(edtphonenumber);
		workPane.add(email);
		workPane.add(edtemail);
		workPane.add(city);
		workPane.add(edtcity);
		workPane.add(member);
		workPane.add(edtmember);
		this.getContentPane().add(workPane, BorderLayout.CENTER);
		this.setSize(250, 500);
		
		// ��Ļ������ʾ
				double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
				double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
				this.setLocation((int) (width - this.getWidth()) / 2,
						(int) (height - this.getHeight()) / 2);
				
		this.btnCancel.addActionListener(this);
		this.btnOk.addActionListener(this);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.btnCancel)
			this.setVisible(false);
		else if(e.getSource()==this.btnOk){
			
			if(edtsex.getText()==null||"".equals(edtsex.getText()))
				JOptionPane.showMessageDialog(null, "�Ա���Ϊ��", "����",JOptionPane.ERROR_MESSAGE);
			if(edtphonenumber.getText()==null||"".equals(edtphonenumber.getText()))
				JOptionPane.showMessageDialog(null, "�ֻ����벻��Ϊ��", "����",JOptionPane.ERROR_MESSAGE);
			if(edtemail.getText()==null||"".equals(edtemail.getText()))	
				JOptionPane.showMessageDialog(null, "���䲻��Ϊ��", "����",JOptionPane.ERROR_MESSAGE);
			if(edtcity.getText()==null||"".equals(edtcity.getText()))
				JOptionPane.showMessageDialog(null, "���ڳ��в���Ϊ��", "����",JOptionPane.ERROR_MESSAGE);
			if(edtmember.getText()==null||"".equals(edtmember.getText()))
				JOptionPane.showMessageDialog(null, "�Ƿ��Ա����Ϊ��", "����",JOptionPane.ERROR_MESSAGE);
			try {
				PersonPlanUtil.UserManager.changeinFormation2(this.user,this.edtsex.getText(),edtphonenumber.getText(),
						edtemail.getText(),edtcity.getText(),
						Integer.parseInt(edtmember.getText()));
			} catch (DbException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (ParseException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			this.setVisible(false);
		}	
		
	}


}
