
package cn.edu.zucc.takeout.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import cn.edu.zucc.takeout.PersonPlanUtil;
import cn.edu.zucc.takeout.model.BeanShoppingcart;
import cn.edu.zucc.takeout.model.BeanStore;
import cn.edu.zucc.takeout.model.BeanUser;
import cn.edu.zucc.takeout.util.DBUtil;
import cn.edu.zucc.takeout.util.DbException;
public class Frm_see_shoppingcart extends JDialog implements ActionListener {
	private JPanel toolBar = new JPanel();
	private Button btnOk = new Button("ȷ��");
	private Button btnCancel = new Button("ȡ��");
	private Button delete = new Button("�Ƴ����ﳵ");
	
	
	Object tblreloadsee_shoppingcartTitle[]=BeanShoppingcart.tableTitles;
	Object tblreloadsee_shoppingcartData[][];
	static DefaultTableModel tabreloadsee_shoppingcartModel=new DefaultTableModel();
	static JTable dataTablereloadsee_shoppingcart=new JTable(tabreloadsee_shoppingcartModel);
	
	BeanShoppingcart curreloadsee_shoppingcart=null;
	 List<BeanShoppingcart> allreloadsee_shoppingcart=null;
	 void reloadsee_shoppingcartTable() throws DbException {
		allreloadsee_shoppingcart=PersonPlanUtil.UserManager.loadAll2();
		tblreloadsee_shoppingcartData =  new Object[allreloadsee_shoppingcart.size()][BeanShoppingcart.tableTitles.length];
		for(int i=0;i<allreloadsee_shoppingcart.size();i++){
			for(int j=0;j<BeanShoppingcart.tableTitles.length;j++)
				tblreloadsee_shoppingcartData[i][j]=allreloadsee_shoppingcart.get(i).getCell(j);
		}
		tabreloadsee_shoppingcartModel.setDataVector(tblreloadsee_shoppingcartData,tblreloadsee_shoppingcartTitle);
		this.dataTablereloadsee_shoppingcart.validate();
		this.dataTablereloadsee_shoppingcart.repaint();
	}
	
	
	public Frm_see_shoppingcart(Frame f, String s, boolean b,FrmLogin dlgLogin) throws DbException {
		super(f, s, b);
		this.getContentPane().add(new JScrollPane(this.dataTablereloadsee_shoppingcart), BorderLayout.WEST);
		reloadsee_shoppingcartTable();
		toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
		toolBar.add(delete);
		toolBar.add(btnOk);
		toolBar.add(btnCancel);
		this .getContentPane().add(toolBar, BorderLayout.SOUTH);
		this.setSize(800, 500);
		
		// ��Ļ������ʾ
				double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
				double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
				this.setLocation((int) (width - this.getWidth()) / 2,
						(int) (height - this.getHeight()) / 2);
				
		this.btnCancel.addActionListener(this);
		this.btnOk.addActionListener(this);
		this.delete.addActionListener(this);
		}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.btnCancel)
			this.setVisible(false);
		else if(e.getSource()==this.btnOk){
			;
			this.setVisible(false);
		}
		else if(e.getSource()==this.delete){
			int i=this.dataTablereloadsee_shoppingcart.getSelectedRow();
			BeanShoppingcart Shoppingcart=allreloadsee_shoppingcart.get(i);
			Connection conn=null;
			try {
				conn=DBUtil.getConnection();
				String sql="delete from shoppingcart where user_id=? and store_id=? and type_id=? and goods_id=? and time=?";
				java.sql.PreparedStatement pst=conn.prepareStatement(sql);
				pst.setInt(1,Shoppingcart.getUser_id());
				pst.setInt(2,Shoppingcart.getStore_id());
				pst.setInt(3,Shoppingcart.getType_id());
				pst.setInt(4,Shoppingcart.getGoods_id());
				pst.setTimestamp(5,Shoppingcart.getTime());
				pst.execute();
			}catch(SQLException ex) {
		        ex.printStackTrace();
				try {
					throw new DbException(ex);
				} catch (DbException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}finally {
				if(conn!=null) {
					try {
						conn.close();
					}catch(SQLException e1) {
						e1.printStackTrace();
					}
				}
			}}
			this.setVisible(false);
		}
		
	}
