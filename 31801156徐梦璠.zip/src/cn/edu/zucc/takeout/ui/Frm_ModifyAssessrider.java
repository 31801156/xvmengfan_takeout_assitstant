
package cn.edu.zucc.takeout.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import cn.edu.zucc.takeout.PersonPlanUtil;
import cn.edu.zucc.takeout.model.BeanGoods_order;
import cn.edu.zucc.takeout.model.BeanManager;
import cn.edu.zucc.takeout.model.BeanUser;
import cn.edu.zucc.takeout.util.BaseException;
import cn.edu.zucc.takeout.util.DBUtil;
import cn.edu.zucc.takeout.util.DbException;

import javax.swing.JFrame;   //顶层容器 (框架)
import javax.swing.JPanel; //中间容器 
import javax.swing.JLabel;   //标签
import javax.swing.JRadioButton; //单�?�框实现�?
import javax.swing.ButtonGroup;
import javax.swing.JFrame;   //顶层容器 (框架)
import javax.swing.JPanel; //中间容器 
import javax.swing.JLabel;   //标签
import javax.swing.JRadioButton; //单�?�框实现�?
import javax.swing.ButtonGroup;

public class Frm_ModifyAssessrider extends JDialog implements ActionListener {
	private JPanel toolBar = new JPanel();
	private JPanel toolBar2 = new JPanel();
	private JPanel workPane = new JPanel();
	private JButton btnLogin = new JButton("确认");
	private JButton btnCancel = new JButton("返回");
	static JRadioButton c1 = new JRadioButton("1😫",true);
	static JRadioButton c2 = new JRadioButton("2😞");
	static JRadioButton c3 = new JRadioButton("3😐");
	static JRadioButton c4 = new JRadioButton("4🙂");
	static JRadioButton c5 = new JRadioButton("5😀");
	private JLabel labelAssessrider = new JLabel("评价骑手");
	private JTextField edtAssessrider = new JTextField(30);
	BeanGoods_order goodsorder=null;
	

	public Frm_ModifyAssessrider(BeanGoods_order goodsorder) {
		this.goodsorder=goodsorder;
		ButtonGroup  group= new ButtonGroup();
		group.add(c1);group.add(c2);group.add(c3);group.add(c4);group.add(c5);
		toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
		toolBar.add(c1);toolBar.add(c2);toolBar.add(c3);toolBar.add(c4);toolBar.add(c5);
		toolBar2.add(btnLogin);
		toolBar2.add(btnCancel);
		
		workPane.add(labelAssessrider);
		workPane.add(edtAssessrider);
		this.getContentPane().add(workPane, BorderLayout.CENTER);
		this.getContentPane().add(toolBar2, BorderLayout.SOUTH);
		this.getContentPane().add(toolBar, BorderLayout.NORTH);
		this.setSize(300, 180);
		// 屏幕居中显示
		double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		this.setLocation((int) (width - this.getWidth()) / 2,
				(int) (height - this.getHeight()) / 2);
       

		btnLogin.addActionListener(this);
		btnCancel.addActionListener(this);

		
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == this.btnCancel) {
			this.setVisible(false);
		}
		else if(e.getSource() == this.btnLogin) {
			String assesscontent=this.edtAssessrider.getText(); 
			Connection conn=null;
			try {
				conn=DBUtil.getConnection();
				conn.setAutoCommit(false);
				int level=0;
				if(c1.isSelected()) {
					level=1;
				}
				else if(c2.isSelected()) {
					level=2;
				}
				else if(c3.isSelected()) {
					level=3;
				}
				else if(c4.isSelected()) {
					level=4;
				}
				else if(c5.isSelected()) {
					level=5;
				}
				double money=0;
				if(level==5) {
					money=0.5;
				}
				if(level==1) {
					money=-20;
				}
				
				
				String sql="update goods_order set assessrider_status=? where order_id=? and store_id=? and user_id="+BeanUser.currentLoginUser.getUser_id();
				java.sql.PreparedStatement pst=conn.prepareStatement(sql);
				pst.setString(1,"已评价");
				pst.setInt(2,this.goodsorder.getOrder_id());
				pst.setInt(3,this.goodsorder.getStore_id());
				pst.execute();
				
				 sql="update getmoney set user_access=?,assesscontent=?,income=income+? where rider_id=? and order_id="+this.goodsorder.getOrder_id();
				pst=conn.prepareStatement(sql);
				pst.setInt(1,level);
				pst.setString(2,assesscontent);
				pst.setDouble(3,money);
				pst.setInt(4,this.goodsorder.getRider_id());
				pst.execute();
				
				
				
				pst.close();
				conn.commit();
			}catch(SQLException ex) {
		        ex.printStackTrace();
				try {
					conn.rollback();
				}catch(SQLException e1) {
					e1.printStackTrace();
				}
			}finally {
				if(conn!=null) {
					try {
						conn.close();
					}catch(SQLException e1) {
						e1.printStackTrace();
					}
				}
			}
			this.setVisible(false);
		}

	}}
