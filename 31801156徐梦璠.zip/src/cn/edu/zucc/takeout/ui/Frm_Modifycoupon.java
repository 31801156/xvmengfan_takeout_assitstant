
package cn.edu.zucc.takeout.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import cn.edu.zucc.takeout.PersonPlanUtil;
import cn.edu.zucc.takeout.model.BeanGooddetails;
import cn.edu.zucc.takeout.model.BeanManager;
import cn.edu.zucc.takeout.model.BeanStore;
import cn.edu.zucc.takeout.util.BaseException;
import cn.edu.zucc.takeout.util.DBUtil;
import cn.edu.zucc.takeout.util.DbException;

public class Frm_Modifycoupon extends JDialog implements ActionListener {
	private JPanel toolBar = new JPanel();
	private JPanel workPane = new JPanel();
	private Button btnOk = new Button("ȷ��");
	private Button btnCancel = new Button("ȡ��");
	

	private JLabel conponid = new JLabel("*�Ż�ȯID: ");
	private JTextField edtconponid = new JTextField(18);
	private JLabel couponmoney = new JLabel("*�Ż�����: ");
	private JTextField edtcouponmoney = new JTextField(18);
	private JLabel couponrequirenumber = new JLabel("*����Ҫ����: ");
	private JTextField edtcouponrequirenumber = new JTextField(18);
	private JLabel couponbegintime = new JLabel("*�Ż�ȯ��ʼʱ��: ");
	private JTextField edtcouponbegintime = new JTextField(18);
	private JLabel couponendtime = new JLabel("*�Ż�ȯ����ʱ��: ");
	private JTextField edtcouponendtime = new JTextField(18);
	private FrmLogin dlgLogin=null;
	public Frm_Modifycoupon(Frame f, String s, boolean b,FrmLogin dlgLogin) {
		super(f, s, b);
		this.dlgLogin=dlgLogin;
		toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
		toolBar.add(this.btnOk);
		toolBar.add(btnCancel);
		this.getContentPane().add(toolBar, BorderLayout.SOUTH);
		workPane.add(conponid);
		workPane.add(edtconponid);
		workPane.add(couponmoney);
		workPane.add(edtcouponmoney);
		workPane.add(couponrequirenumber);
		workPane.add(edtcouponrequirenumber);
		workPane.add(couponbegintime);
		workPane.add(edtcouponbegintime);
		workPane.add(couponendtime);
		workPane.add(edtcouponendtime);
		this.getContentPane().add(workPane, BorderLayout.CENTER);
		this.setSize(220,350);
		// ��Ļ������ʾ
				double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
				double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
				this.setLocation((int) (width - this.getWidth()) / 2,
						(int) (height - this.getHeight()) / 2);
				
				
		this.btnCancel.addActionListener(this);
		this.btnOk.addActionListener(this);
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.btnCancel)
			this.setVisible(false);
		else if(e.getSource()==this.btnOk){
			try {
				Timestamp begin=Timestamp.valueOf(this.edtcouponbegintime.getText());
				Timestamp end=Timestamp.valueOf(this.edtcouponendtime.getText());
				PersonPlanUtil.CouponManager.addcoupon(Integer.parseInt(this.edtconponid.getText()),Integer.parseInt(this.edtcouponmoney.getText()),
						Integer.parseInt(this.edtcouponrequirenumber.getText()),begin,end);
			} catch (NumberFormatException | DbException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			this.setVisible(false);
	}}}