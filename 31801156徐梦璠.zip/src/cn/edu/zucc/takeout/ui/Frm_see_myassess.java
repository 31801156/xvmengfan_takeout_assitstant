
package cn.edu.zucc.takeout.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import cn.edu.zucc.takeout.PersonPlanUtil;
import cn.edu.zucc.takeout.model.BeanGoodsassess;
import cn.edu.zucc.takeout.model.BeanShoppingcart;
import cn.edu.zucc.takeout.model.BeanStore;
import cn.edu.zucc.takeout.model.BeanUser;
import cn.edu.zucc.takeout.util.DBUtil;
import cn.edu.zucc.takeout.util.DbException;
public class Frm_see_myassess extends JDialog implements ActionListener {
	private JPanel toolBar = new JPanel();
	private Button btnOk = new Button("ȷ��");
	private Button btnCancel = new Button("ȡ��");
	
	
	Object tblreloadsee_myassessTitle[]=BeanShoppingcart.tableTitles;
	Object tblreloadsee_myassessData[][];
	static DefaultTableModel tabreloadsee_myassessModel=new DefaultTableModel();
	static JTable dataTablereloadsee_myassess=new JTable(tabreloadsee_myassessModel);
	
	BeanGoodsassess curreloadsee_myassess=null;
	 List<BeanGoodsassess> allreloadsee_myassess=null;
	 void reloadsee_myassessTable() throws DbException {
		allreloadsee_myassess=PersonPlanUtil.UserManager.loadAll3();
		tblreloadsee_myassessData =  new Object[allreloadsee_myassess.size()][BeanGoodsassess.tableTitles.length];
		for(int i=0;i<allreloadsee_myassess.size();i++){
			for(int j=0;j<BeanGoodsassess.tableTitles.length;j++)
				tblreloadsee_myassessData[i][j]=allreloadsee_myassess.get(i).getCell(j);
		}
		tabreloadsee_myassessModel.setDataVector(tblreloadsee_myassessData,tblreloadsee_myassessTitle);
		this.dataTablereloadsee_myassess.validate();
		this.dataTablereloadsee_myassess.repaint();
	}
	
	
	public Frm_see_myassess(Frame f, String s, boolean b,FrmLogin dlgLogin) throws DbException {
		super(f, s, b);
		this.getContentPane().add(new JScrollPane(this.dataTablereloadsee_myassess), BorderLayout.WEST);
		reloadsee_myassessTable();
		toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
		toolBar.add(btnOk);
		toolBar.add(btnCancel);
		this .getContentPane().add(toolBar, BorderLayout.SOUTH);
		this.setSize(800, 500);
		
		// ��Ļ������ʾ
				double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
				double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
				this.setLocation((int) (width - this.getWidth()) / 2,
						(int) (height - this.getHeight()) / 2);
				
		this.btnCancel.addActionListener(this);
		this.btnOk.addActionListener(this);
		}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.btnCancel)
			this.setVisible(false);
		else if(e.getSource()==this.btnOk){
			;
			this.setVisible(false);
		}
		}
		
	}
