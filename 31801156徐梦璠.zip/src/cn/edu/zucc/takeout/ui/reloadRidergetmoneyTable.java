
package cn.edu.zucc.takeout.ui;
import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import cn.edu.zucc.takeout.PersonPlanUtil;
import cn.edu.zucc.takeout.model.BeanCoupon;
import cn.edu.zucc.takeout.model.BeanGetmoney;
import cn.edu.zucc.takeout.model.BeanRider;
import cn.edu.zucc.takeout.model.BeanStore;
import cn.edu.zucc.takeout.model.BeanUserconpon;
import cn.edu.zucc.takeout.util.BaseException;
import cn.edu.zucc.takeout.util.DbException;

public class reloadRidergetmoneyTable{

	Object tblRidergetmoneyTitle[]=BeanGetmoney.tableTitles;
	Object tblRidergetmoneyData[][];
	static DefaultTableModel tabRidergetmoneyModel=new DefaultTableModel();
	static JTable dataTableRidergetmoney=new JTable(tabRidergetmoneyModel);
	
	BeanGetmoney curRidergetmoney=null;
	List<BeanGetmoney> allRidergetmoney=null;
	public reloadRidergetmoneyTable(BeanRider rider) throws DbException{
		try {
			allRidergetmoney=PersonPlanUtil.GetmoneyManager.loadAll(rider);
		} catch (BaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		tblRidergetmoneyData =  new Object[allRidergetmoney.size()][BeanGetmoney.tableTitles.length];
		for(int i=0;i<allRidergetmoney.size();i++){
			for(int j=0;j<BeanGetmoney.tableTitles.length;j++)
				tblRidergetmoneyData[i][j]=allRidergetmoney.get(i).getCell(j);
		}
		tabRidergetmoneyModel.setDataVector(tblRidergetmoneyData,tblRidergetmoneyTitle);
		this.dataTableRidergetmoney.validate();
		this.dataTableRidergetmoney.repaint();
	}
}