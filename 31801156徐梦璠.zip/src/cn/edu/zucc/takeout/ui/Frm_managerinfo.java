
package cn.edu.zucc.takeout.ui;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class Frm_managerinfo extends JDialog implements ActionListener {
	private JPanel toolBar = new JPanel();
	private Button btnOk = new Button("ȷ��");
	private Button btnCancel = new Button("ȡ��");
	
	public Frm_managerinfo() {
		this.getContentPane().add(new JScrollPane(reloadManagerTable.dataTableManager), BorderLayout.CENTER);
		new reloadManagerTable();
		toolBar.setLayout(new FlowLayout(FlowLayout.CENTER));
		toolBar.add(btnOk);
		toolBar.add(btnCancel);
		this .getContentPane().add(toolBar, BorderLayout.SOUTH);
		this.setSize(600,300);
		
		// ��Ļ������ʾ
				double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
				double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
				this.setLocation((int) (width - this.getWidth()) / 2,
						(int) (height - this.getHeight()) / 2);
				
		this.btnCancel.addActionListener(this);
		this.btnOk.addActionListener(this);
		}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.btnCancel)
			this.setVisible(false);
		else if(e.getSource()==this.btnOk){
			;
			this.setVisible(false);
		}	
		
	}

}
