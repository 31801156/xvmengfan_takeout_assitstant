package cn.edu.zucc.takeout.ui;
import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import cn.edu.zucc.takeout.PersonPlanUtil;
import cn.edu.zucc.takeout.model.BeanCoupon;
import cn.edu.zucc.takeout.util.BaseException;
import cn.edu.zucc.takeout.util.DbException;

public class reloadseecouponTable{

	Object tblseecouponTitle[]=BeanCoupon.tableTitles;
	Object tblseecouponData[][];
	static DefaultTableModel tabseecouponModel=new DefaultTableModel();
	static JTable dataTableseecoupon=new JTable(tabseecouponModel);
	
	BeanCoupon curseecoupon=null;
	List<BeanCoupon> allseecoupon=null;
	public reloadseecouponTable() throws DbException{
		allseecoupon=PersonPlanUtil.CouponManager.loadAll1();
		tblseecouponData =  new Object[allseecoupon.size()][BeanCoupon.tableTitles.length];
		for(int i=0;i<allseecoupon.size();i++){
			for(int j=0;j<BeanCoupon.tableTitles.length;j++)
				tblseecouponData[i][j]=allseecoupon.get(i).getCell(j);
		}
		tabseecouponModel.setDataVector(tblseecouponData,tblseecouponTitle);
		this.dataTableseecoupon.validate();
		this.dataTableseecoupon.repaint();
	}
}