package cn.edu.zucc.takeout.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import cn.edu.zucc.takeout.PersonPlanUtil;
import cn.edu.zucc.takeout.itf.IGoods_orderManager;
import cn.edu.zucc.takeout.model.BeanGoods_order;
import cn.edu.zucc.takeout.model.BeanOrder_details;
import cn.edu.zucc.takeout.model.BeanRider;
import cn.edu.zucc.takeout.model.BeanUser;
import cn.edu.zucc.takeout.util.BaseException;
import cn.edu.zucc.takeout.util.BusinessException;
import cn.edu.zucc.takeout.util.DBUtil;
import cn.edu.zucc.takeout.util.DbException;
public class Frm_Goods_order_and_Order_details extends JDialog implements ActionListener {
	private JPanel toolBar = new JPanel();
	private Button btnOk = new Button("ȷ��");
	private Button btnCancel = new Button("ȡ��");
	private Button getgoods = new Button("ȷ���ջ�");
	private Button deleteorder = new Button("ȡ������");
	private Button assessstore = new Button("�����̵�");
	private Button assessrider = new Button("��������");
	private Window dlg;
	//�ҵĶ���
	Object tblGoods_orderTitle[]=BeanGoods_order.tableTitles;
	Object tblGoods_orderData[][];
	static DefaultTableModel tabGoods_orderModel=new DefaultTableModel();
	static JTable dataTableGoods_order=new JTable(tabGoods_orderModel);
	
	BeanGoods_order curGoods_order=null;
	List<BeanGoods_order> allGoods_order=null;
	void reloadGoods_orderTable(){
		try {
			allGoods_order=PersonPlanUtil.Goods_orderManager.loadAll();
		} catch (BaseException e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
			return;
		}
		tblGoods_orderData =  new Object[allGoods_order.size()][BeanGoods_order.tableTitles.length];
		for(int i=0;i<allGoods_order.size();i++){
			for(int j=0;j<BeanGoods_order.tableTitles.length;j++)
				tblGoods_orderData[i][j]=allGoods_order.get(i).getCell(j);
		}
		tabGoods_orderModel.setDataVector(tblGoods_orderData,tblGoods_orderTitle);
		this.dataTableGoods_order.validate();
		this.dataTableGoods_order.repaint();
	}
	
	//��������
	Object tblorder_detailsTitle[]=BeanOrder_details.tableTitles;
	Object tblorder_detailsData[][];
	static DefaultTableModel taborder_detailsModel=new DefaultTableModel();
	static JTable dataTableorder_details=new JTable(taborder_detailsModel);
	
	BeanOrder_details curorder_details=null;
	List<BeanOrder_details> allorder_details=null;
	void reloadorder_detailsTable(int k) throws BaseException{
		if(k<0) {
			return;
		}
		try {
		curGoods_order=allGoods_order.get(k);
		allorder_details=PersonPlanUtil.Order_detailsManager.loadAll(curGoods_order);
		} catch (BaseException e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
			return;
		}
		tblorder_detailsData =  new Object[allorder_details.size()][BeanOrder_details.tableTitles.length];
		for(int i=0;i<allorder_details.size();i++){
			for(int j=0;j<BeanOrder_details.tableTitles.length;j++)
				tblorder_detailsData[i][j]=allorder_details.get(i).getCell(j);
		}
		taborder_detailsModel.setDataVector(tblorder_detailsData,tblorder_detailsTitle);
		this.dataTableorder_details.validate();
		this.dataTableorder_details.repaint();
	}
	
	private FrmLogin dlgLogin=null;
	public Frm_Goods_order_and_Order_details(Frame f, String s, boolean b,FrmLogin dlgLogin) {
		super(f, s, b);
		this.dlgLogin=dlgLogin;
		this.getContentPane().add(new JScrollPane(this.dataTableGoods_order), BorderLayout.CENTER);
	    this.dataTableGoods_order.addMouseListener(new MouseAdapter (){

			@Override
			public void mouseClicked(MouseEvent e) {
				int i=Frm_Goods_order_and_Order_details.this.dataTableGoods_order.getSelectedRow();
				if(i<0) {
					return;
				}
				try {
					Frm_Goods_order_and_Order_details.this.reloadorder_detailsTable(i);
				} catch (BaseException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
	    	
	    });
	    this.getContentPane().add(new JScrollPane(this.dataTableorder_details), BorderLayout.EAST);
	    
		reloadGoods_orderTable();
		toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
		toolBar.add(btnOk);
		toolBar.add(btnCancel);
		toolBar.add(getgoods);
		toolBar.add(deleteorder);
		toolBar.add(assessstore);
		toolBar.add(assessrider);

		this .getContentPane().add(toolBar, BorderLayout.SOUTH);
		this.setSize(1500,500);
		// ��Ļ������ʾ
				double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
				double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
				this.setLocation((int) (width - this.getWidth()) / 2,
						(int) (height - this.getHeight()) / 2);
				
				
		this.btnCancel.addActionListener(this);
		this.btnOk.addActionListener(this);
		this.getgoods.addActionListener(this);
		this.deleteorder.addActionListener(this);
		this.assessstore.addActionListener(this);
		this.assessrider.addActionListener(this);
//		
//		  this.addWindowListener(new WindowAdapter(){   
//		    	public void windowClosing(WindowEvent e){ 
//		    		System.exit(0);
//	             }
//	        });
//		    this.setVisible(true);
		}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.btnCancel)
			this.setVisible(false);
		else if(e.getSource()==this.btnOk){
			this.setVisible(false);
		}	
		else if(e.getSource()==this.getgoods){
			//�޸Ķ���״̬��������������

			int i=this.dataTableGoods_order.getSelectedRow();
			if(i<0) {
				JOptionPane.showMessageDialog(null, "��ѡ�񶩵�", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			BeanGoods_order goodsorder=allGoods_order.get(i);
			try {
				new Frm_getgoods(goodsorder);
			} catch (DbException e1) {
				e1.printStackTrace();
			}
			this.setVisible(false);
		}

		else if(e.getSource()==this.deleteorder){
			//ȡ���������޸Ķ���״̬��
			int i=this.dataTableGoods_order.getSelectedRow();
			if(i<0) {
				JOptionPane.showMessageDialog(null, "��ѡ�񶩵�", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			BeanGoods_order goodsorder=allGoods_order.get(i);
			
			if((goodsorder.getOrder_status().equals("���ʹ�")))
					JOptionPane.showMessageDialog(null, "�ö������ջ�!!!", "����",JOptionPane.ERROR_MESSAGE);

			Connection conn=null;
			try {
				conn=DBUtil.getConnection();
				String sql="update goods_order set order_status=? where order_status!=? and order_id="+goodsorder.getOrder_id();
				java.sql.PreparedStatement pst=conn.prepareStatement(sql);
				pst.setString(1,"ȡ������");
				pst.setString(2,"���ʹ�");
				pst.execute();
				BeanGoods_order a=new BeanGoods_order();
				a.setOrder_status("ȡ������");
			}catch(SQLException ex) {
		        ex.printStackTrace();
				try {
					throw new DbException(ex);
				} catch (DbException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}finally {
				if(conn!=null) {
					try {
						conn.close();
					}catch(SQLException e1) {
						e1.printStackTrace();
					}
				}
			}
			this.setVisible(false);
		}
		else if(e.getSource()==this.assessstore){
			//ȥ����
			int i=this.dataTableGoods_order.getSelectedRow();
			int j=this.dataTableorder_details.getSelectedRow();
			if(i<0) {
				JOptionPane.showMessageDialog(null, "��ѡ���̵�", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			if(j<0) {
				JOptionPane.showMessageDialog(null, "��Ҫȥ����ö����е�һ����Ʒ", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			BeanGoods_order goodsorder=allGoods_order.get(i);
			BeanOrder_details orderdetails=allorder_details.get(j);
			if(!goodsorder.getOrder_status().equals("���ʹ�")) {
				JOptionPane.showMessageDialog(null, "δ�յ���������������", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			if(!goodsorder.getAssessstore_status().equals("δ����")) {
				JOptionPane.showMessageDialog(null, "�̵�������,��ѡ������ѡ��", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			Frm_ModifyAssess dlg=new Frm_ModifyAssess(goodsorder,orderdetails);
			dlg.setVisible(true);
			dlg.setAlwaysOnTop(true);
			this.setVisible(false);
		}
		else if(e.getSource()==this.assessrider){
			//ȥ����
			int i=this.dataTableGoods_order.getSelectedRow();
			if(i<0) {
				JOptionPane.showMessageDialog(null, "��ѡ�񶩵�", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			BeanGoods_order goodsorder=allGoods_order.get(i);
			if(!goodsorder.getAssessrider_status().equals("δ����")) {
				JOptionPane.showMessageDialog(null, "����������,��ѡ������ѡ��", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			if(!goodsorder.getOrder_status().equals("���ʹ�")) {
				JOptionPane.showMessageDialog(null, "δ�յ���������������", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			Frm_ModifyAssessrider dlg=new Frm_ModifyAssessrider(goodsorder);
			dlg.setVisible(true);
			dlg.setAlwaysOnTop(true);
			this.setVisible(false);
		}
	}


}