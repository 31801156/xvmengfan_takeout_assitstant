package cn.edu.zucc.takeout.util;

public class BusinessException extends BaseException {
	public BusinessException(String msg){
		super(msg);
	}
}
