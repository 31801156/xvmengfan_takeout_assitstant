package manager_to_modify;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Date;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import cn.edu.zucc.takeout.PersonPlanUtil;
import cn.edu.zucc.takeout.model.BeanRider;
import cn.edu.zucc.takeout.model.BeanStore;
import cn.edu.zucc.takeout.model.BeanUser;
import cn.edu.zucc.takeout.ui.FrmLogin;
import cn.edu.zucc.takeout.util.BaseException;
import cn.edu.zucc.takeout.util.BusinessException;

public class FrmModifyRiderinformation extends JDialog implements ActionListener {
	private JPanel toolBar = new JPanel();
	private JPanel workPane = new JPanel();
	private Button btnOk = new Button("����");
	private Button btnCancel = new Button("ȡ��");
	
	private JLabel labelrider_name = new JLabel("*����������");
	private JLabel labelrider_identity = new JLabel("*�������ݣ�");
	private JTextField edtrider_name = new JTextField(20);
	private JTextField edtrider_identity = new JTextField(20);
	private FrmLogin dlgLogin=null;
	private BeanRider rider=null;
	public FrmModifyRiderinformation(Frame f, String s, boolean b,FrmLogin dlgLogin, BeanRider rider) {
		super(f, s, b);
		this.dlgLogin=dlgLogin;
		this.rider=rider;
		toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
		toolBar.add(this.btnOk);
		toolBar.add(btnCancel);
		this.getContentPane().add(toolBar, BorderLayout.SOUTH);
		workPane.add(labelrider_name);
		workPane.add(edtrider_name);
		workPane.add(labelrider_identity);
		workPane.add(edtrider_identity);
		this.getContentPane().add(workPane, BorderLayout.CENTER);
		this.setSize(300, 180);
		
		// ��Ļ������ʾ
				double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
				double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
				this.setLocation((int) (width - this.getWidth()) / 2,
						(int) (height - this.getHeight()) / 2);
				
		this.btnCancel.addActionListener(this);
		this.btnOk.addActionListener(this);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.btnCancel)
			this.setVisible(false);
		if(e.getSource()==this.btnOk){
			String rider_name=this.edtrider_name.getText();
			String rider_identity=this.edtrider_identity.getText();
			
			try {
				PersonPlanUtil.RiderManager.changeRiderinfo(this.rider,rider_name,rider_identity);
			} catch (BusinessException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			this.setVisible(false);
			
		}

	}


}


