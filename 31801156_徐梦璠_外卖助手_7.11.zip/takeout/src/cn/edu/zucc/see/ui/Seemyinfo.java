package cn.edu.zucc.see.ui;

import java.util.List;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import cn.edu.zucc.personplan.PersonPlanUtil;
import cn.edu.zucc.personplan.model.BeanUser;
import cn.edu.zucc.personplan.util.BaseException;

public class Seemyinfo {
	//�ҵĻ�����Ϣ
		private Object tblUserTitle[]=BeanUser.tableTitles;
		private Object tblUserData[][];
		DefaultTableModel tabUserModel=new DefaultTableModel();
		private JTable dataTableUser=new JTable(tabUserModel);
		
		private BeanUser curUser=null;
		List<BeanUser> allUser=null;
		private void reloadUserTable() throws BaseException{//���ǲ������ݣ���Ҫ��ʵ�����滻
			allUser=PersonPlanUtil.userManager.loadAll();
			tblUserData =  new Object[allUser.size()][BeanUser.tableTitles.length];
			System.out.print(allUser.size());
			for(int i=0;i<allUser.size();i++){
				for(int j=0;j<BeanUser.tableTitles.length;j++)
					tblUserData[i][j]=allUser.get(i).getCell(j);
			}
			tabUserModel.setDataVector(tblUserData,tblUserTitle);
			this.dataTableUser.validate();
			this.dataTableUser.repaint();
		}
}
