package cn.edu.zucc.personplan.model;

import java.sql.Struct;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class BeanGoodsassess{
	public static final String[] tableTitles={"goods_id","store_id","user_id",
			"content","time","level","photo"};
	    private int goods_id;
	    private int store_id;
	    private int user_id;
	    private String content;
	    private Date time;
	    private int level;
//	    private longblob coupon_money;
	    
	    public int getGoods_id() {
	    	return goods_id;
	    }
		public void setGoods_id(int goods_id) {
			this.goods_id=goods_id;
			
		}//
	    public int getStore_id() {
	    	return store_id;
	    }
		public void setStore_id(int store_id) {
			this.store_id=store_id;
			
		}//
	    public int getUser_id() {
	    	return user_id;
	    }
		public void setUser_id(int user_id) {
			this.user_id=user_id;
			
		}//
	    public String getContent() {
	    	return content;
	    }
		public void setContent(String content) {
			this.content=content;
			
		}//
	    public Date getTime() {
	    	return time;
	    }
		public void setTime(Date time) {
			this.time=time;
			
		}//
	    public int getLevel() {
	    	return level;
	    }
		public void setLevel(int level) {
			this.level=level;
			
		}//
	public String getCell(int col){
		if(col==0) return Integer.toString(this.goods_id);
		else if(col==1) return Integer.toString(this.store_id);
		else if(col==2) return Integer.toString(this.user_id);
		else if(col==3) return this.content;
		//else if(col==4) return Double.toString(this.time);
		else if(col==5) return Integer.toString(this.level);
		//else if(col==6) return Double.toString(this.photo);
		else return "";
	}

}


