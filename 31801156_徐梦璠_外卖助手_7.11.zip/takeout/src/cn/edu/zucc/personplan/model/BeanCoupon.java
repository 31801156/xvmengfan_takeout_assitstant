package cn.edu.zucc.personplan.model;

import java.sql.Struct;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class BeanCoupon{
	public static final String[] tableTitles={"coupon_id","coupon_money","coupon_require_number","coupon_begin_time",
			"coupon_end_time"};
	    private int coupon_id;
	    private int coupon_money;
	    private int coupon_require_number;
	    private Date coupon_begin_time;
	    private Date coupon_end_time;
	    
	    public int getCoupon_id() {
	    	return coupon_id;
	    }
		public void setCoupon_id(int coupon_id) {
			this.coupon_id=coupon_id;
			
		}//
	    public int getCoupon_money() {
	    	return coupon_money;
	    }
		public void setCoupon_money(int coupon_money) {
			this.coupon_money=coupon_money;
			
		}//
	    public int getCoupon_require_number() {
	    	return coupon_require_number;
	    }
		public void setCoupon_require_number(int coupon_require_number) {
			this.coupon_require_number=coupon_require_number;
			
		}//
	    public Date getCoupon_begin_time() {
	    	return coupon_begin_time;
	    }
		public void setCoupon_begin_time(Date coupon_begin_time) {
			this.coupon_begin_time=coupon_begin_time;
			
		}//
	    public Date getCoupon_end_time() {
	    	return coupon_end_time;
	    }
		public void setCoupon_end_time(Date coupon_end_time) {
			this.coupon_end_time=coupon_end_time;
			
		}//
	public String getCell(int col){
		if(col==0) return Integer.toString(this.coupon_id);
		else if(col==1) return Integer.toString(this.coupon_money);
		else if(col==2) return Integer.toString(coupon_require_number);
//		else if(col==3) return Double.toString(this.goods_money);
//		else if(col==4) return Double.toString(this.coupon_money);
		else return "";
	}

}


