package cn.edu.zucc.personplan.model;

import java.text.SimpleDateFormat;
import java.util.Date;

public class BeanRider {
	public final static String[] tableTitles={"rider_id","rider_name",
			"rider_entrydate","rider_identity"};
	    private int rider_id;
	    private String rider_name;
	    private Date rider_entrydate;
	    private String rider_identity;
	    
	    public int getRider_id() {
	    	return rider_id;
	    }
		public void setRider_id(int rider_id) {
			this.rider_id=rider_id;
			
		}//
	    public String getRider_name() {
	    	return rider_name;
	    }
		public void setRider_name(String rider_name) {
			this.rider_name=rider_name;
			
		}//
	    public Date getRider_entrydate() {
	    	return rider_entrydate;
	    }
		public void setRider_entrydate(Date rider_entrydate) {
			this.rider_entrydate=rider_entrydate;
			
		}//
	    public String getRider_identity() {
	    	return rider_identity;
	    }
		public void setRider_identity(String rider_identity) {
			this.rider_identity=rider_identity;
			
		}//
	public String getCell(int col){
		if(col==0) return Integer.toString(this.rider_id);
		else if(col==1) return this.rider_name;
		else if(col==2) return new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(this.rider_entrydate);
		else if(col==3) return this.rider_identity;
		else return "";
	}

}


