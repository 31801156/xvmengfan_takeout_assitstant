
	package cn.edu.zucc.personplan.model;

	import java.sql.Struct;
	import java.text.SimpleDateFormat;
	import java.util.Date;
	import java.util.List;

	public class BeanGetmoney{
		public static final String[] tableTitles={"rider_id","order_id","gettime",
				"user_access","income"};
		    private int rider_id;
		    private int order_id;
		    private Date gettime;
		    private String user_access;
		    private double income;
		    
		    public int getRider_id() {
		    	return rider_id;
		    }
			public void setRider_id(int rider_id) {
				this.rider_id=rider_id;
				
			}//
		    public int getOrder_id() {
		    	return order_id;
		    }
			public void setOrder_id(int order_id) {
				this.order_id=order_id;
				
			}//
		    public Date getGettime() {
		    	return gettime;
		    }
			public void setGettime(Date gettime) {
				this.gettime=gettime;
				
			}//
		    public String getUser_access() {
		    	return user_access;
		    }
			public void setUser_access(String user_access) {
				this.user_access=user_access;
				
			}//
		    public double getIncome() {
		    	return income;
		    }
			public void setIncome(double income) {
				this.income=income;
				
			}//
		public String getCell(int col){
			if(col==0) return Integer.toString(this.rider_id);
			else if(col==1) return Integer.toString(this.order_id);
			//else if(col==2) return this.gettime;
			else if(col==3) return this.user_access;
			else if(col==4) return Double.toString(this.income);
			else return "";
		}

	}


