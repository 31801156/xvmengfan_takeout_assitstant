package cn.edu.zucc.personplan.model;

import java.sql.Struct;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class BeanGoods_order{
	public static final String[] tableTitles={"order_id","store_id","user_id","rider_id",
			"original_money","end_money","fullreduction_id","coupon_id",
			"order_time","require_arrive_time","address_id","order_status"};
	    private int order_id;
	    private int store_id;
	    private int user_id;
	    private int rider_id;
	    private double original_money;
	    private double end_money;
	    private int fullreduction_id;
	    private int coupon_id;
	    private Date order_time;
	    private Date require_arrive_time;
	    private int address_id;
	    private String order_status;

	    public int getOrder_id() {
	    	return order_id;
	    }
		public void setOrder_id(int order_id) {
			this.order_id=order_id;
			
		}//
	    public int getStore_id() {
	    	return store_id;
	    }
		public void setStore_id(int store_id) {
			this.store_id=store_id;
			
		}//
	    public int getUser_id() {
	    	return user_id;
	    }
		public void setUser_id(int user_id) {
			this.user_id=user_id;
			
		}//
	    public int getRider_id() {
	    	return rider_id;
	    }
		public void setRider_id(int rider_id) {
			this.rider_id=rider_id;
			
		}//
	    public double getOriginal_money() {
	    	return original_money;
	    }
		public void setOriginal_money(double original_money) {
			this.original_money=original_money;
			
		}//
	    public double getEnd_money() {
	    	return end_money;
	    }
		public void setEnd_money(double end_money) {
			this.end_money=end_money;
			
		}//
	    public int getFullreduction_id() {
	    	return fullreduction_id;
	    }
		public void setFullreduction_id(int fullreduction_id) {
			this.fullreduction_id=fullreduction_id;
			
		}//
	    public int getCoupon_id() {
	    	return coupon_id;
	    }
		public void setCoupon_id(int coupon_id) {
			this.coupon_id=coupon_id;
			
		}//
	    public Date getOrder_time() {
	    	return order_time;
	    }
		public void setOrder_time(Date order_time) {
			this.order_time=order_time;
			
		}//
	    public Date getRequire_arrive_time() {
	    	return require_arrive_time;
	    }
		public void setRequire_arrive_time(Date require_arrive_time) {
			this.require_arrive_time=require_arrive_time;
			
		}//
	    public int getAddress_id() {
	    	return address_id;
	    }
		public void setAddress_id(int address_id) {
			this.address_id=address_id;
			
		}//
	    public String getOrder_status() {
	    	return order_status;
	    }
		public void setOrder_status(String order_status) {
			this.order_status=order_status;
			
		}//
	public String getCell(int col){
		if(col==0) return Integer.toString(this.order_id);
		else if(col==1) return Integer.toString(this.store_id);
		else if(col==2) return Integer.toString(this.user_id);
		else if(col==3) return Integer.toString(this.rider_id);
		else if(col==4) return Double.toString(this.original_money);
		else if(col==5) return Double.toString(this.end_money);
		else if(col==6) return Integer.toString(this.fullreduction_id);
		else if(col==7) return Integer.toString(this.coupon_id);
		else if(col==8) return new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(this.order_time);
		else if(col==9) return new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(this.require_arrive_time);
		else if(col==10) return Integer.toString(this.address_id);
		else if(col==11) return this.order_status;
		else return "";
	}

}


