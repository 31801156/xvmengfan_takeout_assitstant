package cn.edu.zucc.personplan.model;

import java.sql.Struct;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class BeanGoodstype{
	public static final String[] tableTitles={"type_id","type_name","goods_count"};
	    private int type_id;
	    private String type_name;
	    private int goods_count;

	    public int getType_id() {
	    	return type_id;
	    }
		public void setType_id(int type_id) {
			this.type_id=type_id;
			
		}//
	    public String getType_name() {
	    	return type_name;
	    }
		public void setType_name(String type_name) {
			this.type_name=type_name;
			
		}//
	    public int getGoods_count() {
	    	return goods_count;
	    }
		public void setGoods_count(int goods_count) {
			this.goods_count=goods_count;
			
		}//
	public String getCell(int col){
		if(col==0) return Integer.toString(this.type_id);
		else if(col==1) return this.type_name;
		else if(col==2) return Integer.toString(this.goods_count);
		else return "";
	}

}


