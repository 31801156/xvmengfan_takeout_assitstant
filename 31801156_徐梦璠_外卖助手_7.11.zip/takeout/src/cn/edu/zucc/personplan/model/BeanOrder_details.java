package cn.edu.zucc.personplan.model;

import java.sql.Struct;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class BeanOrder_details{
	public static final String[] tableTitles={"order_id","goods_id","count","money","per_reduce_money"};
	    private int order_id;
	    private int goods_id;
	    private int count;
	    private double money;
	    private int per_reduce_money;
	    
	    public int getOrder_id() {
	    	return order_id;
	    }
		public void setOrder_id(int order_id) {
			this.order_id=order_id;
			
		}//
	    public int getGoods_id() {
	    	return order_id;
	    }
		public void setGoods_id(int goods_id) {
			this.goods_id=goods_id;
			
		}//
	    public int getCount() {
	    	return count;
	    }
		public void setCount(int count) {
			this.count=count;
			
		}//
	    public double getMoney() {
	    	return money;
	    }
		public void setMoney(double money) {
			this.money=money;
			
		}//
	    public int getPer_reduce_money() {
	    	return per_reduce_money;
	    }
		public void setPer_reduce_money(int per_reduce_money) {
			this.per_reduce_money=per_reduce_money;
			
		}//
	public String getCell(int col){
		if(col==0) return Integer.toString(this.order_id);
		else if(col==1) return Integer.toString(this.goods_id);
		else if(col==2) return Integer.toString(this.count);
		else if(col==3) return Double.toString(this.money);
		else if(col==4) return Integer.toString(this.per_reduce_money);
		else return "";
	}

}


