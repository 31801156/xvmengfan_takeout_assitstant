package cn.edu.zucc.personplan.comtrol.example;

import java.util.List;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import cn.edu.zucc.personplan.itf.IGooddetailsManager;
import cn.edu.zucc.personplan.model.BeanGooddetails;
import cn.edu.zucc.personplan.model.BeanGoodstype;
import cn.edu.zucc.personplan.model.BeanUser;
import cn.edu.zucc.personplan.util.BaseException;
import cn.edu.zucc.personplan.util.DBUtil;
import cn.edu.zucc.personplan.util.DbException;

public class GooddetailsManager implements IGooddetailsManager {
@Override
public List<BeanGooddetails> loadAll(BeanGoodstype goodstype) throws BaseException {
	List<BeanGooddetails> result=new ArrayList<BeanGooddetails>();
	Connection conn=null;
	try {
		conn=DBUtil.getConnection();
		System.out.println(goodstype.getType_id());
		String sql="select * from gooddetails where type_id=?";
		java.sql.PreparedStatement pst=conn.prepareStatement(sql);
		pst.setInt(1,goodstype.getType_id());
		java.sql.ResultSet rs=pst.executeQuery();
		while(rs.next()) {
			BeanGooddetails p=new BeanGooddetails();
			p.setGoods_id(rs.getInt(1));;
			p.setType_id(rs.getInt(2));;
			p.setGoods_name(rs.getString(3));
			p.setGoods_money(rs.getDouble(4));;
			p.setCoupon_money(rs.getDouble(5));
			result.add(p);
		}
		rs.close();
		pst.close();
		conn.close();
		return result;
	}catch(SQLException ex) {
        ex.printStackTrace();
		throw new DbException(ex);
	}finally {
		if(conn!=null) {
			try {
				conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
}