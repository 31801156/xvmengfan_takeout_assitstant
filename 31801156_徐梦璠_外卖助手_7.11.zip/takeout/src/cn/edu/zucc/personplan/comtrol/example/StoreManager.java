package cn.edu.zucc.personplan.comtrol.example;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import cn.edu.zucc.personplan.itf.IStoreManager;
import cn.edu.zucc.personplan.model.BeanStore;
import cn.edu.zucc.personplan.model.BeanUser;
import cn.edu.zucc.personplan.util.BaseException;
import cn.edu.zucc.personplan.util.BusinessException;
import cn.edu.zucc.personplan.util.DBUtil;
import cn.edu.zucc.personplan.util.DbException;

public class StoreManager implements IStoreManager {
	@Override
	public BeanStore addStore(String store_name, String store_level, 
			String store_per_consumption, String store_totalsales) throws BaseException {
		Connection conn=null;
		int store_id=0;
		try {
			conn=DBUtil.getConnection();
			String sql="select store_name from store where store_name=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,store_name);
			java.sql.ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				rs.close();
				pst.close();
				throw new BusinessException("ͬ���̵��Ѵ���");
			}
			rs.close();
			pst.close();
			
			sql="select max(store_id) from store";
			java.sql.Statement st=conn.createStatement();
			rs=st.executeQuery(sql);
			if(rs.next()) {
				store_id=rs.getInt(1)+1;
			}else {
				store_id=1;
			}
			rs.close();
			
			sql= "insert into store(store_id,store_name,store_level,"
					+ "store_per_consumption,store_totalsales)"
						+ " values(?,?,?,?,?)";
			pst=conn.prepareStatement(sql);
			pst.setInt(1,store_id);
			pst.setString(2,store_name);
			pst.setDouble(3,Double.parseDouble(store_level));
			pst.setInt(4,Integer.parseInt(store_per_consumption));
			pst.setInt(5,Integer.parseInt(store_totalsales));
			pst.execute();
			BeanStore p=new BeanStore();
			p.setStore_name(store_name);;
			p.setStore_level(Double.parseDouble(store_level));
			p.setStore_per_consumption(Integer.parseInt(store_per_consumption));
			p.setStore_totalsales(Integer.parseInt(store_totalsales));
			return p;
			}catch(SQLException ex) {
	        ex.printStackTrace();
			throw new DbException(ex);
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	@Override
	public List<BeanStore> loadAll() throws BaseException {
		List<BeanStore> result=new ArrayList<BeanStore>();
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from store";
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			while(rs.next()) {
				BeanStore p=new BeanStore();
				p.setStore_id(rs.getInt(1));;
				p.setStore_name(rs.getString(2));
				p.setStore_level(rs.getDouble(3));
				p.setStore_per_consumption(rs.getInt(4));
				p.setStore_totalsales(rs.getInt(5));
				result.add(p);
			}
			rs.close();
			st.close();
			conn.close();
			return result;
		}catch(SQLException ex) {
	        ex.printStackTrace();
			throw new DbException(ex);
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}

	}
	@Override
	public void deleteStore(BeanStore store) throws BaseException, SQLException {
		int store_id=store.getStore_id();
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			conn.setAutoCommit(false);
			String sql="select count(*) from goods_order where order_status='������' or order_status='��ʱ' and store_id="+store_id;
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(rs.next()){
				if(rs.getInt(1)>0) {
					rs.close();
					st.close();
					throw new BusinessException("���̵����δ�����Ķ���������ɾ��");
				}
			}
			rs.close();
			sql="select store_id from store where store_id="+store_id;
			rs=st.executeQuery(sql);
			int store_store_id=0;
			if(rs.next()) {
				store_store_id=rs.getInt(1);
			}else {
				rs.close();
				st.close();
				throw new BusinessException("���̵겻����");
			}
			rs.close();
			if(!(store.getStore_id()==(store_store_id))) {
				st.close();
				throw new BusinessException("����ɾ�������̵�");
			}
			sql="delete from store where store_id="+store_id;
			st.execute(sql);
			st.close();
			conn.commit();
		}catch(BaseException e) {
			try {
				conn.rollback();
			}catch(SQLException ex) {
				e.printStackTrace();
			}
			throw e;
		}
		catch(SQLException ex) {
	        ex.printStackTrace();
			try {
				conn.rollback();
			}catch(SQLException e) {
				e.printStackTrace();
			}
			throw new DbException(ex);
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}


	@Override
	public void addStoreconpon(BeanStore store,int couponid) throws DbException {
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql= "insert into relationship_store_coupon(coupon_id,store_id) values(?,?)";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, couponid);
			pst.setInt(2,store.getStore_id());
			pst.execute();
			store.setStore_id(store.getStore_id());
			}catch(SQLException ex) {
			throw new DbException(ex);
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	@Override
	public void addStoretype(BeanStore store, int typeid) throws DbException {
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql= "insert into relationship_store_goodstype(store_id,type_id) values(?,?)";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, store.getStore_id());
			pst.setInt(2,typeid);
			pst.execute();
			store.setStore_id(store.getStore_id());
			}catch(SQLException ex) {
			throw new DbException(ex);
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}}
//
//	@Override
//	public void changeName(BeanStore store,String newName) throws BaseException {
//		if(newName==null||"".equals(newName))
//			throw new BusinessException("�û�������Ϊ��");
//		Connection conn=null;
//		try {
//			conn=DBUtil.getConnection();
//			String sql= "update store set store_name=? where store_id=?";
//			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
//			pst.setString(1,newName);
//			pst.setString(2,store.getStore_id());
//			pst.execute();
//			store.setStore_name(newName);
//			store.setStore_id(store.getStore_id());
//			}catch(SQLException ex) {
//			throw new DbException(ex);
//		}finally {
//			if(conn!=null) {
//				try {
//					conn.close();
//				}catch(SQLException e) {
//					e.printStackTrace();
//				}
//			}
//		}
//	}
//}