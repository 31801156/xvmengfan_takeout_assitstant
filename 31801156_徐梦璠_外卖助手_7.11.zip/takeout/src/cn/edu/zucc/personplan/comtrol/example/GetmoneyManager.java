
package cn.edu.zucc.personplan.comtrol.example;

import java.util.List;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import cn.edu.zucc.personplan.itf.IGetmoneyManager;
import cn.edu.zucc.personplan.itf.IGooddetailsManager;
import cn.edu.zucc.personplan.model.BeanGetmoney;
import cn.edu.zucc.personplan.model.BeanGooddetails;
import cn.edu.zucc.personplan.model.BeanGoodstype;
import cn.edu.zucc.personplan.model.BeanRider;
import cn.edu.zucc.personplan.model.BeanUser;
import cn.edu.zucc.personplan.util.BaseException;
import cn.edu.zucc.personplan.util.DBUtil;
import cn.edu.zucc.personplan.util.DbException;

public class GetmoneyManager implements IGetmoneyManager {
@Override
public List<BeanGetmoney> loadAll(BeanRider rider) throws BaseException {
	List<BeanGetmoney> result=new ArrayList<BeanGetmoney>();
	Connection conn=null;
	try {
		conn=DBUtil.getConnection();
		String sql="select * from getmoney where rider_id=?";
		java.sql.PreparedStatement pst=conn.prepareStatement(sql);
		pst.setInt(1,rider.getRider_id());
		java.sql.ResultSet rs=pst.executeQuery();
		while(rs.next()) {
			BeanGetmoney p=new BeanGetmoney();
			p.setRider_id(rs.getInt(1));;
			p.setOrder_id(rs.getInt(2));;
			p.setGettime(rs.getDate(3));
			p.setUser_access(rs.getString(4));;
			p.setIncome(rs.getDouble(5));
			result.add(p);
		}
		rs.close();
		pst.close();
		conn.close();
		return result;
	}catch(SQLException ex) {
        ex.printStackTrace();
		throw new DbException(ex);
	}finally {
		if(conn!=null) {
			try {
				conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}

}

}