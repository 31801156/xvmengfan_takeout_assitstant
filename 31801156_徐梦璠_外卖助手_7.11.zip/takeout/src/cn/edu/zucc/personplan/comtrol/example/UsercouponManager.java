
package cn.edu.zucc.personplan.comtrol.example;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import cn.edu.zucc.personplan.itf.IUsercouponManager;
import cn.edu.zucc.personplan.model.BeanUserconpon;
import cn.edu.zucc.personplan.model.BeanUser;
import cn.edu.zucc.personplan.util.BaseException;
import cn.edu.zucc.personplan.util.DBUtil;
import cn.edu.zucc.personplan.util.DbException;

public class UsercouponManager implements IUsercouponManager {
@Override
public List<BeanUserconpon> loadAll() throws BaseException {
	List<BeanUserconpon> result=new ArrayList<BeanUserconpon>();
	Connection conn=null;
	try {
		conn=DBUtil.getConnection();

		String sql="select * from usercoupon where user_id=?";
		java.sql.Statement st=conn.createStatement();
		java.sql.PreparedStatement pst=conn.prepareStatement(sql);
		pst.setInt(1,BeanUser.currentLoginUser.getUser_id());
		java.sql.ResultSet rs=pst.executeQuery();
		while(rs.next()) {
			BeanUserconpon p=new BeanUserconpon();
			p.setUser_id(rs.getInt(1));;
			p.setCoupon_id(rs.getInt(2));;
			p.setStore_id(rs.getInt(3));
			p.setCoupon_money(rs.getInt(4));
			p.setCoupon_count(rs.getInt(5));
			//p.setCoupon_end_time(rs.getDate(5));
			result.add(p);
		}
		rs.close();
		pst.close();
		conn.close();
		return result;
	}catch(SQLException ex) {
        ex.printStackTrace();
		throw new DbException(ex);
	}finally {
		if(conn!=null) {
			try {
				conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}

}}