package cn.edu.zucc.personplan.comtrol.example;

import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import cn.edu.zucc.personplan.itf.IRiderManager;
import cn.edu.zucc.personplan.model.BeanRider;
import cn.edu.zucc.personplan.model.BeanStore;
import cn.edu.zucc.personplan.util.BaseException;
import cn.edu.zucc.personplan.util.BusinessException;
import cn.edu.zucc.personplan.util.DBUtil;
import cn.edu.zucc.personplan.util.DbException;

public class RiderManager implements IRiderManager {
	@Override
	public BeanRider addRider(String rider_name, String rider_entrydate,
			String rider_identity) throws BaseException {
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
		Connection conn=null;
		try {
			int rider_id=0;
			conn=DBUtil.getConnection();
			String sql="select rider_name from rider where rider_name=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,rider_name);
			java.sql.ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				rs.close();
				pst.close();
				throw new BusinessException("�������Ѵ���");
			}
			rs.close();
			pst.close();
			
			sql="select max(rider_id) from rider";
			java.sql.Statement st=conn.createStatement();
			rs=st.executeQuery(sql);
			if(rs.next()) {
				rider_id=rs.getInt(1)+1;
			}else {
				rider_id=1;
			}
			rs.close();
			pst.close();
			
			sql= "insert into rider(rider_id,rider_name,rider_entrydate,rider_identity)"
						+ " values(?,?,?,?)";
			pst=conn.prepareStatement(sql);
			pst.setInt(1,rider_id);
			pst.setString(2,rider_name);
			try {
				pst.setDate(3,(Date)sdf.parse(rider_entrydate));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			pst.setString(4,rider_identity);
			pst.execute();
			BeanRider p=new BeanRider();
			p.setRider_name(rider_name);
			try {
				p.setRider_entrydate((Date)sdf.parse(rider_entrydate));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			p.setRider_identity(rider_identity);
			return p;
			}catch(SQLException ex) {
	        ex.printStackTrace();
			throw new DbException(ex);
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
	@Override
	public List<BeanRider> loadAll() throws BaseException {
		List<BeanRider> result=new ArrayList<BeanRider>();
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from rider";
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			while(rs.next()) {
				BeanRider p=new BeanRider();
				p.setRider_id(rs.getInt(1));;
				p.setRider_name(rs.getString(2));
				p.setRider_entrydate(rs.getDate(3));
				p.setRider_identity(rs.getString(4));
				result.add(p);
			}
			rs.close();
			st.close();
			conn.close();
			return result;
		}catch(SQLException ex) {
	        ex.printStackTrace();
			throw new DbException(ex);
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}

	}
	@Override
	public void deleteRider(BeanRider rider) throws BaseException, SQLException {
		int rider_id=rider.getRider_id();
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			conn.setAutoCommit(false);
			String sql="select count(*) from goods_order where order_status='������' or order_status='��ʱ' and rider_id="+rider_id;
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			if(rs.next()){
				if(rs.getInt(1)>0) {
					rs.close();
					st.close();
					throw new BusinessException("�����ִ���δ�����Ķ���������ɾ��");
				}
			}
			rs.close();
			sql="select rider_id from rider where rider_id="+rider_id;
			rs=st.executeQuery(sql);
			int rider_rider_id=0;
			if(rs.next()) {
				rider_rider_id=rs.getInt(1);
			}else {
				rs.close();
				st.close();
				throw new BusinessException("�����ֲ�����");
			}
			rs.close();
			if(!(rider.getRider_id()==(rider_rider_id))) {
				st.close();
				throw new BusinessException("����ɾ����������");
			}
			sql="delete from rider where rider_id="+rider_id;
			st.execute(sql);
			st.close();
			conn.commit();
		}catch(BaseException e) {
			try {
				conn.rollback();
			}catch(SQLException ex) {
				e.printStackTrace();
			}
			throw e;
		}
		catch(SQLException ex) {
	        ex.printStackTrace();
			try {
				conn.rollback();
			}catch(SQLException e) {
				e.printStackTrace();
			}
			throw new DbException(ex);
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
	@Override
	public void changeRiderinfo(BeanRider rider, String rider_name, String rider_entrydate, String rider_identity) throws BusinessException {
		if(rider_name==null||"".equals(rider_name))
			throw new BusinessException("����������Ϊ��");
		Connection conn=null;
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			conn=DBUtil.getConnection();
			String sql= "update rider set rider_name=?,rider_entrydate=?,rider_identity=? where rider_id=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,rider_name);
			try {
				pst.setDate(2,(Date)sdf.parse(rider_entrydate));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			pst.setString(3,rider_identity);
			pst.setInt(4,rider.getRider_id());
			pst.execute();
			rider.setRider_name(rider_name);
			try {
				rider.setRider_entrydate((Date)sdf.parse(rider_entrydate));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			rider.setRider_identity(rider_identity);
			}catch(SQLException ex) {
			try {
				throw new DbException(ex);
			} catch (DbException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
	}
	}