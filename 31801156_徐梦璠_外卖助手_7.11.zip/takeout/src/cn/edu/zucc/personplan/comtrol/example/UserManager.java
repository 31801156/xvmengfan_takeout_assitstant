package cn.edu.zucc.personplan.comtrol.example;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import cn.edu.zucc.personplan.itf.IUserManager;
import cn.edu.zucc.personplan.model.BeanAddress;
import cn.edu.zucc.personplan.model.BeanManager;
import cn.edu.zucc.personplan.model.BeanRider;
import cn.edu.zucc.personplan.model.BeanUser;
import cn.edu.zucc.personplan.util.BaseException;
import cn.edu.zucc.personplan.util.BusinessException;
import cn.edu.zucc.personplan.util.DBUtil;
import cn.edu.zucc.personplan.util.DbException;

public class UserManager implements IUserManager {

	@Override
	public BeanUser reg(String username, String pwd,String pwd2) throws BaseException {
		if(username==null||"".equals(username))
			throw new BusinessException("�û�������Ϊ��");
		if(pwd==null||"".equals(pwd))
			throw new BusinessException("���벻��Ϊ��");
		if(!pwd.equals(pwd2))
			throw new BusinessException("������������벻һ��");
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql= "select user_name from user where user_name=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,username);
			java.sql.ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				rs.close();
				pst.close();
				throw new BusinessException("�û��Ѵ���");
			}
//			rs.close();
//			pst.close();
			
			sql="select max(user_id) from user";
			java.sql.Statement st=conn.createStatement();
			rs=st.executeQuery(sql);
			int user_id=0;
			if(rs.next()) {
				user_id=rs.getInt(1)+1;
			}
			else
				user_id=1;

			rs.close();
			st.close();
			
			sql= "insert into user(user_id,user_name,password,registration_time) values(?,?,?,?)";
			pst=conn.prepareStatement(sql);
			pst.setInt(1,user_id);
			pst.setString(2,username);
			pst.setString(3,pwd);
			pst.setTimestamp(4, new java.sql.Timestamp(System.currentTimeMillis()));
			pst.execute();
//			rs.close();
//			pst.close();
			BeanUser user=new BeanUser();
			user.setUser_id(user_id);
			user.setUser_name(username);
			user.setPassword(pwd);
			user.setRegistration_time(new Date());
			rs.close();
			pst.close();
			return user;
//			sql="insert into relationship_manager_user(manager_id,user_id) select manager_id,? from manager";
//			pst=conn.prepareStatement(sql);
//			pst.setInt(1,user_id);
//			pst.execute();
			}catch(SQLException ex) {
			throw new DbException(ex);
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}


	
	@Override
	public BeanUser login(String username, String pwd) throws BaseException {
		Connection conn=null;
		BeanUser user=null;
		try {
			conn=DBUtil.getConnection();
			int user_id=0;
			String sql= "select user_id,registration_time,password from user where user_name=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,username);
			java.sql.ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				user_id=rs.getInt(1);
				if(!pwd.equals(rs.getString(3))) {
					throw new BusinessException("�������");
				}
				System.out.print("��½setID:");
				System.out.println(user_id);
				
				rs.close();
				pst.close();
				
				user=new BeanUser();
				user.setUser_id(user_id);
				user.setUser_name(username);
				//user.setRegistration_time(rs.getTimestamp(1));
				user.setPassword(pwd);
				return user;
			}else {
				throw new BusinessException("�û�������");
			}
		}catch(SQLException ex) {
			throw new DbException(ex);
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}


	@Override
	public void changePwd(BeanUser user, String oldPwd, String newPwd,
			String newPwd2) throws BaseException {
		if(newPwd==null||"".equals(newPwd))
			throw new BusinessException("���벻��Ϊ��");
		if(!oldPwd.equals(user.getPassword()))
			throw new BusinessException("�������������");
		if(!newPwd.equals(newPwd2))
			throw new BusinessException("��������������벻һ��");
		if(oldPwd.equals(newPwd))
			throw new BusinessException("���������������ͬ");
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql= "update user set password=?,registration_time=? where user_name=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,newPwd);
			pst.setTimestamp(2, new java.sql.Timestamp(System.currentTimeMillis()));
			pst.setString(3,user.getUser_name());
			pst.execute();
			user.setRegistration_time(new Date());
			user.setUser_name(user.getUser_name());
			user.setUser_id(user.getUser_id());
			user.setPassword(newPwd);
			}catch(SQLException ex) {
			throw new DbException(ex);
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
//@Override
//public void changeName(BeanUser user,String newName) throws BaseException {
//	if(newName==null||"".equals(newName))
//		throw new BusinessException("�û�������Ϊ��");
//	Connection conn=null;
//	try {
//		conn=DBUtil.getConnection();
//		String sql= "update user set user_name=? where user_id=?";
//		java.sql.PreparedStatement pst=conn.prepareStatement(sql);
//		pst.setString(1,newName);
//		pst.setString(2,user.getUser_id());
//		pst.execute();
//		user.setUser_name(newName);
//		user.setUser_id(user.getUser_id());
//		}catch(SQLException ex) {
//		throw new DbException(ex);
//	}finally {
//		if(conn!=null) {
//			try {
//				conn.close();
//			}catch(SQLException e) {
//				e.printStackTrace();
//			}
//		}
//	}
//}
@Override
public void changeinFormation(String sex, String phonenumber, String email,
		String city, int member) throws DbException, ParseException {
	Connection conn=null;
	BeanUser user=BeanUser.currentLoginUser;
	SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
	try {
		conn=DBUtil.getConnection();
		String sql= "update user set sex=?,phonenumber=?,email=?,city=?,member=? where user_name=?";
		java.sql.PreparedStatement pst=conn.prepareStatement(sql);
		pst.setString(1,sex);
		pst.setString(2,phonenumber);
		pst.setString(3,email);
		pst.setString(4,city);
		pst.setInt(5,member);
		pst.setString(6,user.getUser_name());
		pst.execute();
		user.setSex(sex);
		user.setUser_name(user.getUser_name());
		user.setPhonenumber(phonenumber);
		user.setEmail(email);
		user.setCity(city);
		user.setMember(member);
		}catch(SQLException ex) {
		throw new DbException(ex);
	}finally {
		if(conn!=null) {
			try {
				conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}
}


@Override
public List<BeanUser> loadAll() throws BaseException {
	List<BeanUser> result=new ArrayList<BeanUser>();
	System.out.println(BeanUser.currentLoginUser.getUser_id());
	Connection conn=null;
	try {
		conn=DBUtil.getConnection();
		System.out.print(BeanUser.currentLoginUser.getUser_id());
		System.out.print(BeanUser.currentLoginUser.getUser_name());
		String sql="select * from user where user_name=?";
		java.sql.PreparedStatement pst=conn.prepareStatement(sql);
		pst.setString(1,BeanUser.currentLoginUser.getUser_name());
		java.sql.ResultSet rs=pst.executeQuery();
		while(rs.next()) {
			BeanUser p=new BeanUser();
			p.setUser_id(rs.getInt(1));
			p.setUser_name(rs.getString(2));;
			p.setSex(rs.getString(3));
			p.setPassword(rs.getString(4));
			p.setPhonenumber(rs.getString(5));
			p.setEmail(rs.getString(6));
			p.setCity(rs.getString(7));
			p.setRegistration_time(rs.getDate(8));
			p.setMember(rs.getInt(9));
			p.setMember_end_time(rs.getDate(10));
			result.add(p);
		}
		rs.close();
		pst.close();
		conn.close();
		return result;
	}catch(SQLException ex) {
        ex.printStackTrace();
		throw new DbException(ex);
	}finally {
		if(conn!=null) {
			try {
				conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}

	
}
@Override
public List<BeanUser> loadAll1() throws BaseException {
	List<BeanUser> result=new ArrayList<BeanUser>();
	Connection conn=null;
	try {
		conn=DBUtil.getConnection();
		String sql="select * from user";
		java.sql.Statement st=conn.createStatement();
		java.sql.ResultSet rs=st.executeQuery(sql);
		while(rs.next()) {
			BeanUser p=new BeanUser();
			p.setUser_id(rs.getInt(1));
			p.setUser_name(rs.getString(2));;
			p.setSex(rs.getString(3));
			p.setPassword(rs.getString(4));
			p.setPhonenumber(rs.getString(5));
			p.setEmail(rs.getString(6));
			p.setCity(rs.getString(7));
			p.setRegistration_time(rs.getDate(8));
			p.setMember(rs.getInt(9));
			p.setMember_end_time(rs.getDate(10));
			result.add(p);
		}
		rs.close();
		st.close();
		conn.close();
		return result;
	}catch(SQLException ex) {
        ex.printStackTrace();
		throw new DbException(ex);
	}finally {
		if(conn!=null) {
			try {
				conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}

	
}
@Override
public void deleteUser(BeanUser user) throws BaseException, SQLException {
	int user_id=user.getUser_id();
	Connection conn=null;
	try {
		conn=DBUtil.getConnection();
		conn.setAutoCommit(false);
		String sql="select count(*) from goods_order where order_status='������' or order_status='��ʱ' and user_id="+user_id;
		java.sql.Statement st=conn.createStatement();
		java.sql.ResultSet rs=st.executeQuery(sql);
		if(rs.next()){
			if(rs.getInt(1)>0) {
				rs.close();
				st.close();
				throw new BusinessException("���û���δ�����Ķ���������ɾ��");
			}
		}
		rs.close();
		sql="select user_id from user where user_id="+user_id;
		rs=st.executeQuery(sql);
		int user_user_id=0;
		if(rs.next()) {
			user_user_id=rs.getInt(1);
		}else {
			rs.close();
			st.close();
			throw new BusinessException("���û�������");
		}
		rs.close();
		if(!(user.getUser_id()==(user_user_id))){
			st.close();
			throw new BusinessException("����ɾ�������û�");
		}
		sql="delete from user where user_id="+user_id;
		st.execute(sql);
		st.close();
		conn.commit();
	}catch(BaseException e) {
		try {
			conn.rollback();
		}catch(SQLException ex) {
			e.printStackTrace();
		}
		throw e;
	}
	catch(SQLException ex) {
        ex.printStackTrace();
		try {
			conn.rollback();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		throw new DbException(ex);
	}finally {
		if(conn!=null) {
			try {
				conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
	
}
