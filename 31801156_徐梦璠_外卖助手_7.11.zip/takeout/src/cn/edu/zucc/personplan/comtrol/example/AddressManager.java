package cn.edu.zucc.personplan.comtrol.example;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import cn.edu.zucc.personplan.itf.IAddressManager;
import cn.edu.zucc.personplan.model.BeanAddress;
import cn.edu.zucc.personplan.model.BeanUser;
import cn.edu.zucc.personplan.util.BaseException;
import cn.edu.zucc.personplan.util.BusinessException;
import cn.edu.zucc.personplan.util.DBUtil;
import cn.edu.zucc.personplan.util.DbException;


public class AddressManager implements IAddressManager {
	@Override
	public BeanAddress addAddress(BeanUser user, int addressid, String province, String city, String area, String address,
			String username, String phonenumber) throws BaseException {//�������͵�ַ
		
		
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select address_id from address where address_id=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,addressid);
			java.sql.ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				rs.close();
				pst.close();
				throw new BusinessException("ͬ�����͵�ַ�Ѵ���");
			}
			rs.close();
			pst.close();
			sql= "insert into address(address_id,user_id,province,city,area,address,user_name,phonenumber)"
						+ " values(?,?,?,?,?,?,?,?)";
			pst=conn.prepareStatement(sql);
			pst.setInt(1,addressid);
			pst.setInt(2,BeanUser.currentLoginUser.getUser_id());
			pst.setString(3,province);
			pst.setString(4,city);
			pst.setString(5,area);
			pst.setString(6,address);
			pst.setString(7,user.getUser_name());
			pst.setString(8,phonenumber);
			pst.execute();
			BeanAddress p=new BeanAddress();
			p.setAddress_id(addressid);
			p.setUser_id(user.getUser_id());;
			p.setProvince(province);
			p.setCity(city);
			p.setArea(area);
			p.setAddress(address);
			p.setUser_name(username);
			p.setPhonenumber(phonenumber);
			rs.close();
			pst.close();
			return p;
			}catch(SQLException ex) {
	        ex.printStackTrace();
			throw new DbException(ex);
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	@Override
	public List<BeanAddress> loadAll() throws BaseException {
		List<BeanAddress> result=new ArrayList<BeanAddress>();
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from address where user_name=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,BeanUser.currentLoginUser.getUser_name());//BeanUser.currentLoginUser.getUser_id()
			java.sql.ResultSet rs=pst.executeQuery();
			while(rs.next()) {
				BeanAddress p=new BeanAddress();
				p.setAddress_id(rs.getInt(1));
				p.setUser_id(rs.getInt(2));;
				p.setProvince(rs.getString(3));
				p.setCity(rs.getString(4));
				p.setArea(rs.getString(5));
				p.setAddress(rs.getString(6));
				p.setUser_name(rs.getString(7));
				p.setPhonenumber(rs.getString(8));
				result.add(p);
			}
			rs.close();
			pst.close();
			conn.close();
			return result;
		}catch(SQLException ex) {
	        ex.printStackTrace();
			throw new DbException(ex);
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	
		
	}
	}
