package cn.edu.zucc.personplan.comtrol.example;

import cn.edu.zucc.personplan.itf.IOrder_detailsManager;

public class Order_detailsManager extends IOrder_detailsManager {

}
