package cn.edu.zucc.personplan.comtrol.example;

import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.SQLException;

import cn.edu.zucc.personplan.itf.ICouponManager;
import cn.edu.zucc.personplan.itf.IGooddetailsManager;
import cn.edu.zucc.personplan.model.BeanCoupon;
import cn.edu.zucc.personplan.model.BeanStore;
import cn.edu.zucc.personplan.util.DBUtil;
import cn.edu.zucc.personplan.util.DbException;

public class CouponManager implements ICouponManager {

	@Override
	public List<BeanCoupon> loadAll(BeanStore store) throws DbException {
		List<BeanCoupon> result=new ArrayList<BeanCoupon>();
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from coupon where coupon.coupon_id in"
					+ "(select relationship_store_coupon.coupon_id from relationship_store_coupon where store_id=?)";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,store.getStore_id());
			java.sql.ResultSet rs=pst.executeQuery();
			while(rs.next()) {
				BeanCoupon p=new BeanCoupon();
				p.setCoupon_id(rs.getInt(1));;
				p.setCoupon_money(rs.getInt(2));;
				p.setCoupon_require_number(rs.getInt(3));
				p.setCoupon_begin_time(rs.getDate(4));;
				p.setCoupon_end_time(rs.getDate(5));
				result.add(p);
			}
			rs.close();
			pst.close();
			conn.close();
			return result;
		}catch(SQLException ex) {
	        ex.printStackTrace();
			throw new DbException(ex);
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
}