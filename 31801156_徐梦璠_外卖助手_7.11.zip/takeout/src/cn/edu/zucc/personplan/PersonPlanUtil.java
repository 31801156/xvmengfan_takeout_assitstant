package cn.edu.zucc.personplan;


import cn.edu.zucc.personplan.comtrol.example.ManagerManager;
import cn.edu.zucc.personplan.comtrol.example.AddressManager;
import cn.edu.zucc.personplan.comtrol.example.UserManager;
import cn.edu.zucc.personplan.comtrol.example.Order_conponManager;
import cn.edu.zucc.personplan.comtrol.example.Order_detailsManager;
import cn.edu.zucc.personplan.comtrol.example.RiderManager;
import cn.edu.zucc.personplan.comtrol.example.StoreManager;
import cn.edu.zucc.personplan.comtrol.example.UsercouponManager;
import cn.edu.zucc.personplan.comtrol.example.Goods_orderManager;
import cn.edu.zucc.personplan.comtrol.example.GoodsassessManager;
import cn.edu.zucc.personplan.comtrol.example.GoodstypeManager;
import cn.edu.zucc.personplan.comtrol.example.GooddetailsManager;
import cn.edu.zucc.personplan.comtrol.example.CouponManager;
import cn.edu.zucc.personplan.comtrol.example.GetmoneyManager;
import cn.edu.zucc.personplan.itf.IAddressManager;
import cn.edu.zucc.personplan.itf.ICouponManager;
import cn.edu.zucc.personplan.itf.IGetmoneyManager;
import cn.edu.zucc.personplan.itf.IGooddetailsManager;
import cn.edu.zucc.personplan.itf.IGoods_orderManager;
import cn.edu.zucc.personplan.itf.IGoodsassessManager;
import cn.edu.zucc.personplan.itf.IGoodstypeManager;
import cn.edu.zucc.personplan.itf.IUsercouponManager;
import cn.edu.zucc.personplan.itf.IManager;
import cn.edu.zucc.personplan.itf.IOrder_conponManager;
import cn.edu.zucc.personplan.itf.IOrder_detailsManager;
import cn.edu.zucc.personplan.itf.IRiderManager;
import cn.edu.zucc.personplan.itf.IStoreManager;
import cn.edu.zucc.personplan.itf.IUserManager;

public class PersonPlanUtil {

	
	public static IOrder_conponManager Order_conponManager = new Order_conponManager();//������ȯ����
	public static IUserManager userManager=new UserManager();//�û�����
	public static IManager ManagerManager=new ManagerManager();//����Ա����
	public static IAddressManager AddressManager=new AddressManager();//�û����͵�ַ����
	public static IUsercouponManager UsercouponManager = new UsercouponManager();//�û��Ż�ȯ����
	public static IGoods_orderManager Goods_orderManager = new Goods_orderManager();//��Ʒ��������
	public static IStoreManager StoreManager = new StoreManager();//�̵����
	public static IRiderManager RiderManager = new RiderManager();//���ֹ���
	public static IGoodstypeManager GoodstypeManager = new GoodstypeManager();//��Ʒ�������
	public static IGooddetailsManager GooddetailsManager = new GooddetailsManager();//��Ʒ�������
	public static IOrder_detailsManager Order_detailsManager=new Order_detailsManager();//�����������
	public static ICouponManager CouponManager=new CouponManager();//�Ż�ȯ����
	public static IGoodsassessManager GoodsassessManager=new GoodsassessManager();//��Ʒ���۹���
	public static IGetmoneyManager GetmoneyManager= new GetmoneyManager();//�������˹���
}
