package cn.edu.zucc.personplan;

import cn.edu.zucc.personplan.ui.Frm_Main;

public class PersonPlanStarter {
	public static void main(String[] args) {
		new Frm_Main();//�����溯��
	}

}
