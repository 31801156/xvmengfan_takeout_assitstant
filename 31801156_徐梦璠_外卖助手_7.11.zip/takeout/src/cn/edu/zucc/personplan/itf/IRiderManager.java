package cn.edu.zucc.personplan.itf;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import cn.edu.zucc.personplan.model.BeanGetmoney;
import cn.edu.zucc.personplan.model.BeanRider;
import cn.edu.zucc.personplan.util.BaseException;
import cn.edu.zucc.personplan.util.BusinessException;

public interface IRiderManager {
	List<BeanRider> loadAll() throws BaseException;

	void deleteRider(BeanRider rider) throws BaseException, SQLException;

	void changeRiderinfo(BeanRider rider, String rider_name, String rider_entrydate, String rider_identity) throws BusinessException;

	BeanRider addRider(String rider_name, String rider_entrydate, String rider_identity) throws BaseException;

}
