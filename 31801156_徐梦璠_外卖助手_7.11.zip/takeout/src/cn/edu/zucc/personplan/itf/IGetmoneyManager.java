package cn.edu.zucc.personplan.itf;

import java.util.List;

import cn.edu.zucc.personplan.model.BeanGetmoney;
import cn.edu.zucc.personplan.model.BeanRider;
import cn.edu.zucc.personplan.util.BaseException;

public interface IGetmoneyManager {

	List<BeanGetmoney> loadAll(BeanRider rider) throws BaseException;

}
