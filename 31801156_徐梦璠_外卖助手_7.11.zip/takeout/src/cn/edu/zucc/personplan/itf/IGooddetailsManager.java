package cn.edu.zucc.personplan.itf;

import java.util.List;

import cn.edu.zucc.personplan.model.BeanGooddetails;
import cn.edu.zucc.personplan.model.BeanGoodstype;
import cn.edu.zucc.personplan.util.BaseException;

public interface IGooddetailsManager {

	List<BeanGooddetails> loadAll(BeanGoodstype goodstype) throws BaseException;

}
