package cn.edu.zucc.personplan.itf;

import java.util.List;

import cn.edu.zucc.personplan.model.BeanGoodstype;
import cn.edu.zucc.personplan.model.BeanStore;
import cn.edu.zucc.personplan.util.BaseException;
import cn.edu.zucc.personplan.util.DbException;

public interface IGoodstypeManager {
	List<BeanGoodstype> loadAll(BeanStore curStore) throws BaseException;


	void addTypegooods(BeanGoodstype goodtype, int goods_id, String goods_name, double goods_money, double coupon_money)
			throws DbException;
}
