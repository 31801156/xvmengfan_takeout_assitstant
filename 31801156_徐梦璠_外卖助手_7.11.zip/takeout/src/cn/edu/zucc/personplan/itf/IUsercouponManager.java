package cn.edu.zucc.personplan.itf;

import java.util.List;

import cn.edu.zucc.personplan.model.BeanUserconpon;
import cn.edu.zucc.personplan.util.BaseException;

public interface IUsercouponManager {

	List<BeanUserconpon> loadAll() throws BaseException;

}
