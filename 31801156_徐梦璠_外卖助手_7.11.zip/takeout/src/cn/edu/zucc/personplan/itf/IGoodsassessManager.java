package cn.edu.zucc.personplan.itf;

import java.util.List;

import cn.edu.zucc.personplan.model.BeanGooddetails;
import cn.edu.zucc.personplan.model.BeanGoodsassess;
import cn.edu.zucc.personplan.util.DbException;

public interface IGoodsassessManager {

	List<BeanGoodsassess> loadAll(BeanGooddetails gooddetails) throws DbException;

}
