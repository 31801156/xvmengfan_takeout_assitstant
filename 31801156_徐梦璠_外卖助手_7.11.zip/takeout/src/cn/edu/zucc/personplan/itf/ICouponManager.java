package cn.edu.zucc.personplan.itf;

import java.util.List;

import cn.edu.zucc.personplan.model.BeanCoupon;
import cn.edu.zucc.personplan.model.BeanStore;
import cn.edu.zucc.personplan.util.DbException;

public interface ICouponManager {

	List<BeanCoupon> loadAll(BeanStore store) throws DbException;

}
