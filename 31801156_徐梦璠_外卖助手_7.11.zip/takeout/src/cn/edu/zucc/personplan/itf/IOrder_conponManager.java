package cn.edu.zucc.personplan.itf;

import java.util.List;

import cn.edu.zucc.personplan.model.BeanAddress;
import cn.edu.zucc.personplan.model.BeanOrder_conpon;
import cn.edu.zucc.personplan.util.BaseException;

public interface  IOrder_conponManager {

	List<BeanOrder_conpon> loadAll() throws BaseException;

}
