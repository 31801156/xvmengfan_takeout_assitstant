package cn.edu.zucc.personplan.itf;

import java.util.List;

import cn.edu.zucc.personplan.model.BeanGoods_order;
import cn.edu.zucc.personplan.model.BeanGoodstype;
import cn.edu.zucc.personplan.model.BeanOrder_details;

public class IOrder_detailsManager {

	public List<BeanOrder_details> loadAll(BeanGoods_order curGoods_order) {
		// TODO Auto-generated method stub
		return null;
	}

}
