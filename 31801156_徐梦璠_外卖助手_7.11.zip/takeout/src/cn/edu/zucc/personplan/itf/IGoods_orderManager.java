package cn.edu.zucc.personplan.itf;

import java.util.List;

import cn.edu.zucc.personplan.model.BeanGoods_order;
import cn.edu.zucc.personplan.util.BaseException;

public interface IGoods_orderManager {
	List<BeanGoods_order> loadAll() throws BaseException;
}
