package cn.edu.zucc.personplan.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import cn.edu.zucc.personplan.PersonPlanUtil;
import cn.edu.zucc.personplan.model.BeanGooddetails;
import cn.edu.zucc.personplan.model.BeanGoodstype;
import cn.edu.zucc.personplan.model.BeanManager;
import cn.edu.zucc.personplan.model.BeanStore;
import cn.edu.zucc.personplan.util.BaseException;
import cn.edu.zucc.personplan.util.DBUtil;
import cn.edu.zucc.personplan.util.DbException;

public class Frm_Modifytypegooods extends JDialog implements ActionListener {
	private JPanel toolBar = new JPanel();
	private JPanel workPane = new JPanel();
	private Button btnOk = new Button("ȷ��");
	private Button btnCancel = new Button("ȡ��");
	

	private JLabel goodsid = new JLabel("��Ʒ���: ");
	private JLabel goodsname = new JLabel("��Ʒ��: ");
	private JLabel money = new JLabel("��Ʒ�۸�: ");
	private JLabel reducemoney = new JLabel("�Żݼ۸�: ");
	private JTextField edtgoodsid = new JTextField(18);
	private JTextField edtgoodsname = new JTextField(18);
	private JTextField edtmoney = new JTextField(18);
	private JTextField edtreducemoney = new JTextField(18);
	private FrmLogin dlgLogin=null;
	private BeanGoodstype goodtype=null;
	public Frm_Modifytypegooods(Frame f, String s, boolean b,FrmLogin dlgLogin, BeanGoodstype goodtype) {
		super(f, s, b);
		this.dlgLogin=dlgLogin;
		this.goodtype=goodtype;
		System.out.print("�������");
		toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
		toolBar.add(this.btnOk);
		toolBar.add(btnCancel);
		this.getContentPane().add(toolBar, BorderLayout.SOUTH);
		workPane.add(goodsid);
		workPane.add(edtgoodsid);
		workPane.add(goodsname);
		workPane.add(edtgoodsname);
		workPane.add(money);
		workPane.add(edtmoney);
		workPane.add(reducemoney);
		workPane.add(edtreducemoney);
		this.getContentPane().add(workPane, BorderLayout.CENTER);
		this.setSize(250, 500);
		this.btnCancel.addActionListener(this);
		this.btnOk.addActionListener(this);
		this.setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.btnCancel)
			this.setVisible(false);
		else if(e.getSource()==this.btnOk){
			this.setVisible(false);
			try {
				PersonPlanUtil.GoodstypeManager.addTypegooods(this.goodtype,Integer.parseInt(edtgoodsid.getText()),
						edtgoodsname.getText(),Integer.parseInt(edtmoney.getText()),Integer.parseInt(edtreducemoney.getText()));
				System.out.print("ȷ�ϵ��");
			} catch (NumberFormatException | DbException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}	
	}	
	}
