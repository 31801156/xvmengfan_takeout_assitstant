	package cn.edu.zucc.personplan.ui;

	import java.awt.BorderLayout;
	import java.awt.Button;
	import java.awt.Dialog;
	import java.awt.FlowLayout;
	import java.awt.Frame;
	import java.awt.event.ActionEvent;
	import java.awt.event.ActionListener;
import java.text.ParseException;

import javax.swing.JDialog;
	import javax.swing.JLabel;
	import javax.swing.JOptionPane;
	import javax.swing.JPanel;
	import javax.swing.JPasswordField;
	import javax.swing.JTextField;

	import cn.edu.zucc.personplan.PersonPlanUtil;
	import cn.edu.zucc.personplan.model.BeanManager;
	import cn.edu.zucc.personplan.model.BeanUser;
	import cn.edu.zucc.personplan.util.BaseException;
import cn.edu.zucc.personplan.util.BusinessException;
import cn.edu.zucc.personplan.util.DbException;


public class FrmModifyAddress extends JDialog implements ActionListener {
	private JPanel toolBar = new JPanel();
	private JPanel workPane = new JPanel();
	private Button btnOk = new Button("ȷ��");
	private Button btnCancel = new Button("ȡ��");
	

	private JLabel address_id = new JLabel("��ַ��� ��  ");
	private JLabel province = new JLabel("ʡ ��  ");
	private JLabel city = new JLabel("�У�");
	private JLabel area = new JLabel("����");
	private JLabel address = new JLabel("��ַ��");
	private JLabel user_name = new JLabel("��ϵ�ˣ�");
	private JLabel phonenumber = new JLabel("�绰��");
	private JTextField edtaddress_id = new JTextField(18);
	private JTextField edtprovince = new JTextField(18);
	private JTextField edtcity = new JTextField(18);
	private JTextField edtarea = new JTextField(18);
	private JTextField edtaddress= new JTextField(18);
	private JTextField edtuser_name= new JTextField(18);
	private JTextField edtphonenumber= new JTextField(18);
	private FrmLogin dlgLogin=null;
	public FrmModifyAddress(Frame f, String s, boolean b,FrmLogin dlgLogin) {
		super(f, s, b);
		this.dlgLogin=dlgLogin;
		toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
		toolBar.add(this.btnOk);
		toolBar.add(btnCancel);
		this.getContentPane().add(toolBar, BorderLayout.SOUTH);
		workPane.add(address_id);
		workPane.add(edtaddress_id);
		workPane.add(province);
		workPane.add(edtprovince);
		workPane.add(city);
		workPane.add(edtcity);
		workPane.add(area);
		workPane.add(edtarea);
		workPane.add(address);
		workPane.add(edtaddress);
		workPane.add(user_name);
		workPane.add(edtuser_name);;
		workPane.add(phonenumber);
		workPane.add(edtphonenumber);
		this.getContentPane().add(workPane, BorderLayout.CENTER);
		this.setSize(220, 500);
		this.btnCancel.addActionListener(this);
		this.btnOk.addActionListener(this);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.btnCancel)
			this.setVisible(false);
		else if(e.getSource()==this.btnOk){
//			
//			if(edtaddress_id.getText()==null||"".equals(edtaddress_id.getText()))
//				try {
//					throw new BusinessException("��ַ��Ų���Ϊ��");
//				} catch (BusinessException e2) {
//					// TODO Auto-generated catch block
//					e2.printStackTrace();
//				}
//			if(edtprovince.getText()==null||"".equals(edtprovince.getText()))
//				try {
//					throw new BusinessException("ʡ�ݲ���Ϊ��");
//				} catch (BusinessException e2) {
//					// TODO Auto-generated catch block
//					e2.printStackTrace();
//				}
//			if(edtcity.getText()==null||"".equals(edtcity.getText()))
//				try {
//					throw new BusinessException("���в���Ϊ��");
//				} catch (BusinessException e2) {
//					// TODO Auto-generated catch block
//					e2.printStackTrace();
//				}
//			if(edtarea.getText()==null||"".equals(edtarea.getText()))
//				try {
//					throw new BusinessException("��������Ϊ��");
//				} catch (BusinessException e2) {
//					// TODO Auto-generated catch block
//					e2.printStackTrace();
//				}
//			if(edtaddress.getText()==null||"".equals(edtaddress_id.getText()))
//				try {
//					throw new BusinessException("��ַ����Ϊ��");
//				} catch (BusinessException e2) {
//					// TODO Auto-generated catch block
//					e2.printStackTrace();
//				}
//			if(edtuser_name.getText()==null||"".equals(edtuser_name.getText()))
//				try {
//					throw new BusinessException("�ջ��˲���Ϊ��");
//				} catch (BusinessException e2) {
//					// TODO Auto-generated catch block
//					e2.printStackTrace();
//				}
//			if(edtphonenumber.getText()==null||"".equals(edtphonenumber.getText()))
//				try {
//					throw new BusinessException("�ջ��˵绰����Ϊ��");
//				} catch (BusinessException e2) {
//					// TODO Auto-generated catch block
//					e2.printStackTrace();
//				}
			
			try {
				PersonPlanUtil.AddressManager.addAddress(BeanUser.currentLoginUser,Integer.parseInt((edtaddress_id.getText())),
						new String(edtprovince.getText()),new String(edtcity.getText()),
						new String(edtarea.getText()),new String(edtaddress.getText()),
				new String(edtuser_name.getText()),new String(edtphonenumber.getText()));
			} catch (DbException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (BaseException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			this.setVisible(false);
		}	
		
	}


}

