package cn.edu.zucc.personplan.ui;

import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import cn.edu.zucc.personplan.PersonPlanUtil;
import cn.edu.zucc.personplan.model.BeanAddress;
import cn.edu.zucc.personplan.model.BeanOrder_conpon;
import cn.edu.zucc.personplan.util.BaseException;

public class reloadOrder_conponTable{
//	�ҵ����͵�ַ
	Object tblOrder_conponTitle[]=BeanOrder_conpon.tableTitles;
	Object tblOrder_conponData[][];
	static DefaultTableModel tabOrder_conponModel=new DefaultTableModel();
	static JTable dataTableOrder_conpon=new JTable(tabOrder_conponModel);
	
	BeanOrder_conpon curOrder_conpon=null;
	List<BeanOrder_conpon> allOrder_conpon=null;
	public reloadOrder_conponTable(){
		try {
			allOrder_conpon=PersonPlanUtil.Order_conponManager.loadAll();
		} catch (BaseException e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
			return;
		}
		tblOrder_conponData =  new Object[allOrder_conpon.size()][BeanAddress.tableTitles.length];
		System.out.print(allOrder_conpon.size());
		for(int i=0;i<allOrder_conpon.size();i++){
			for(int j=0;j<BeanAddress.tableTitles.length;j++)
				tblOrder_conponData[i][j]=allOrder_conpon.get(i).getCell(j);
		}
		tabOrder_conponModel.setDataVector(tblOrder_conponData,tblOrder_conponTitle);
		this.dataTableOrder_conpon.validate();
		this.dataTableOrder_conpon.repaint();
	}
}