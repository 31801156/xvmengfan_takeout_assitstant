
package cn.edu.zucc.personplan.ui;
import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import cn.edu.zucc.personplan.PersonPlanUtil;
import cn.edu.zucc.personplan.model.BeanUserconpon;
import cn.edu.zucc.personplan.util.BaseException;

public class reloadUsercouponTable{
//	�ҵ����͵�ַ
	Object tblConponTitle[]=BeanUserconpon.tableTitles;
	Object tblConponData[][];
	static DefaultTableModel tabConponModel=new DefaultTableModel();
	static JTable dataTableConpon=new JTable(tabConponModel);
	
	BeanUserconpon curConpon=null;
	List<BeanUserconpon> allConpon=null;
	public reloadUsercouponTable(){
		try {
			allConpon=PersonPlanUtil.UsercouponManager.loadAll();
		} catch (BaseException e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
			return;
		}
		tblConponData =  new Object[allConpon.size()][BeanUserconpon.tableTitles.length];
		System.out.print(allConpon.size());
		for(int i=0;i<allConpon.size();i++){
			for(int j=0;j<BeanUserconpon.tableTitles.length;j++)
				tblConponData[i][j]=allConpon.get(i).getCell(j);
		}
		tabConponModel.setDataVector(tblConponData,tblConponTitle);
		this.dataTableConpon.validate();
		this.dataTableConpon.repaint();
	}
}