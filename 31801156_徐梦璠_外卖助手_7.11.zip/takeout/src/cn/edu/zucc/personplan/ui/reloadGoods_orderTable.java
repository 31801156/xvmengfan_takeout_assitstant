package cn.edu.zucc.personplan.ui;

import java.awt.Component;
import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import cn.edu.zucc.personplan.PersonPlanUtil;
import cn.edu.zucc.personplan.model.BeanGoods_order;
import cn.edu.zucc.personplan.util.BaseException;

public class reloadGoods_orderTable{
//	�ҵ����͵�ַ
	Object tblGoods_orderTitle[]=BeanGoods_order.tableTitles;
	Object tblGoods_orderData[][];
	static DefaultTableModel tabGoods_orderModel=new DefaultTableModel();
	static JTable dataTableGoods_order=new JTable(tabGoods_orderModel);
	
	BeanGoods_order curGoods_order=null;
	List<BeanGoods_order> allGoods_order=null;
	public reloadGoods_orderTable(){
		try {
			allGoods_order=PersonPlanUtil.Goods_orderManager.loadAll();
		} catch (BaseException e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
			return;
		}
		tblGoods_orderData =  new Object[allGoods_order.size()][BeanGoods_order.tableTitles.length];
		System.out.print(allGoods_order.size());
		for(int i=0;i<allGoods_order.size();i++){
			for(int j=0;j<BeanGoods_order.tableTitles.length;j++)
				tblGoods_orderData[i][j]=allGoods_order.get(i).getCell(j);
		}
		tabGoods_orderModel.setDataVector(tblGoods_orderData,tblGoods_orderTitle);
		this.dataTableGoods_order.validate();
		this.dataTableGoods_order.repaint();
	}
}