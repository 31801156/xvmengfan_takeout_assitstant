package cn.edu.zucc.personplan.ui;
import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import cn.edu.zucc.personplan.PersonPlanUtil;
import cn.edu.zucc.personplan.model.BeanGooddetails;
import cn.edu.zucc.personplan.model.BeanGoodsassess;
import cn.edu.zucc.personplan.model.BeanStore;
import cn.edu.zucc.personplan.util.BaseException;
import cn.edu.zucc.personplan.util.DbException;

public class reloadGoodsassessTable{

	Object tblGoodsaccessTitle[]=BeanGoodsassess.tableTitles;
	Object tblGoodsassessData[][];
	static DefaultTableModel tabGoodsassessModel=new DefaultTableModel();
	static JTable dataTableGoodsassess=new JTable(tabGoodsassessModel);
	
	BeanGoodsassess curGoodsassess=null;
	List<BeanGoodsassess> allGoodsassess=null;
	public reloadGoodsassessTable(BeanGooddetails gooddetails) throws DbException{
		allGoodsassess=PersonPlanUtil.GoodsassessManager.loadAll(gooddetails);
		tblGoodsassessData =  new Object[allGoodsassess.size()][BeanGoodsassess.tableTitles.length];
		for(int i=0;i<allGoodsassess.size();i++){
			for(int j=0;j<BeanGoodsassess.tableTitles.length;j++)
				tblGoodsassessData[i][j]=allGoodsassess.get(i).getCell(j);
		}
		tabGoodsassessModel.setDataVector(tblGoodsassessData,tblGoodsaccessTitle);
		this.dataTableGoodsassess.validate();
		this.dataTableGoodsassess.repaint();
	}
}