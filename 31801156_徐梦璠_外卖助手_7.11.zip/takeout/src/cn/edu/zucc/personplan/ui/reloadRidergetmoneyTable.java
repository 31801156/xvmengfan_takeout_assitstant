
package cn.edu.zucc.personplan.ui;
import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import cn.edu.zucc.personplan.PersonPlanUtil;
import cn.edu.zucc.personplan.model.BeanCoupon;
import cn.edu.zucc.personplan.model.BeanGetmoney;
import cn.edu.zucc.personplan.model.BeanRider;
import cn.edu.zucc.personplan.model.BeanStore;
import cn.edu.zucc.personplan.model.BeanUserconpon;
import cn.edu.zucc.personplan.util.BaseException;
import cn.edu.zucc.personplan.util.DbException;

public class reloadRidergetmoneyTable{

	Object tblRidergetmoneyTitle[]=BeanGetmoney.tableTitles;
	Object tblRidergetmoneyData[][];
	static DefaultTableModel tabRidergetmoneyModel=new DefaultTableModel();
	static JTable dataTableRidergetmoney=new JTable(tabRidergetmoneyModel);
	
	BeanGetmoney curRidergetmoney=null;
	List<BeanGetmoney> allRidergetmoney=null;
	public reloadRidergetmoneyTable(BeanRider rider) throws DbException{
		try {
			allRidergetmoney=PersonPlanUtil.GetmoneyManager.loadAll(rider);
		} catch (BaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		tblRidergetmoneyData =  new Object[allRidergetmoney.size()][BeanCoupon.tableTitles.length];
		for(int i=0;i<allRidergetmoney.size();i++){
			for(int j=0;j<BeanGetmoney.tableTitles.length;j++)
				tblRidergetmoneyData[i][j]=allRidergetmoney.get(i).getCell(j);
		}
		tabRidergetmoneyModel.setDataVector(tblRidergetmoneyData,tblRidergetmoneyTitle);
		this.dataTableRidergetmoney.validate();
		this.dataTableRidergetmoney.repaint();
	}
}