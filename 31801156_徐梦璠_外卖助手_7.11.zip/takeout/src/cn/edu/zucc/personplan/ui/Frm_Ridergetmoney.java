
package cn.edu.zucc.personplan.ui;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import cn.edu.zucc.personplan.model.BeanRider;
import cn.edu.zucc.personplan.model.BeanStore;
import cn.edu.zucc.personplan.model.BeanUser;
import cn.edu.zucc.personplan.util.DbException;

public class Frm_Ridergetmoney extends JDialog implements ActionListener {
	private JPanel toolBar = new JPanel();
	private Button btnOk = new Button("ȷ��");
	private Button btnCancel = new Button("ȡ��");
	
	public Frm_Ridergetmoney(BeanRider rider) {
		this.getContentPane().add(new JScrollPane(reloadRidergetmoneyTable.dataTableRidergetmoney), BorderLayout.WEST);
		try {
			new reloadRidergetmoneyTable(rider);
		} catch (DbException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
		toolBar.add(btnOk);
		toolBar.add(btnCancel);
		this .getContentPane().add(toolBar, BorderLayout.SOUTH);
		this.setSize(250, 500);
		this.btnCancel.addActionListener(this);
		this.btnOk.addActionListener(this);
		}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.btnCancel)
			this.setVisible(false);
		else if(e.getSource()==this.btnOk){
			;
			this.setVisible(false);
		}	
		
	}

}
