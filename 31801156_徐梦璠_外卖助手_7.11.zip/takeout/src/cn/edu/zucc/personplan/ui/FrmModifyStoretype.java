package cn.edu.zucc.personplan.ui;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import cn.edu.zucc.personplan.PersonPlanUtil;
import cn.edu.zucc.personplan.model.BeanStore;
import cn.edu.zucc.personplan.model.BeanUser;
import cn.edu.zucc.personplan.ui.FrmLogin;
import cn.edu.zucc.personplan.util.BaseException;
import cn.edu.zucc.personplan.util.DbException;


public class FrmModifyStoretype extends JDialog implements ActionListener {
private JPanel toolBar = new JPanel();
private JPanel workPane = new JPanel();
private Button btnOk = new Button("ȷ��");
private Button btnCancel = new Button("ȡ��");


private JLabel type_id = new JLabel("������ ��  ");
private JTextField edttype_id = new JTextField(18);
private FrmLogin dlgLogin=null;
private BeanStore store=null;
public FrmModifyStoretype(Frame f, String s, boolean b,FrmLogin dlgLogin,BeanStore store) {
	super(f, s, b);
	this.dlgLogin=dlgLogin;
	this.store=store;
	toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
	toolBar.add(this.btnOk);
	toolBar.add(btnCancel);
	this.getContentPane().add(toolBar, BorderLayout.SOUTH);
	workPane.add(type_id);
	workPane.add(edttype_id);
	this.getContentPane().add(workPane, BorderLayout.CENTER);
	this.setSize(220, 500);
	this.btnCancel.addActionListener(this);
	this.btnOk.addActionListener(this);
}

@Override
public void actionPerformed(ActionEvent e) {
	if(e.getSource()==this.btnCancel)
		this.setVisible(false);
	else if(e.getSource()==this.btnOk){
		try {
			PersonPlanUtil.StoreManager.addStoretype(this.store,Integer.parseInt(edttype_id.getText()));
		} catch (NumberFormatException | DbException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		this.setVisible(false);
	}	
	
}


}

