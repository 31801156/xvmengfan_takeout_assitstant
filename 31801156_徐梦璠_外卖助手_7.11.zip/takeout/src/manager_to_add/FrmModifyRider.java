
package manager_to_add;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Date;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import cn.edu.zucc.personplan.PersonPlanUtil;
import cn.edu.zucc.personplan.model.BeanRider;
import cn.edu.zucc.personplan.model.BeanUser;
import cn.edu.zucc.personplan.ui.FrmLogin;
import cn.edu.zucc.personplan.util.BaseException;

public class FrmModifyRider extends JDialog implements ActionListener {
	private JPanel toolBar = new JPanel();
	private JPanel workPane = new JPanel();
	private Button btnOk = new Button("����");
	private Button btnCancel = new Button("ȡ��");
	
	private JLabel labelrider_id = new JLabel("���ֱ�ţ�");
	private JLabel labelrider_name = new JLabel("����������");
	private JLabel labelrider_entrydate = new JLabel("��ְ���ڣ�");
	private JLabel labelrider_identity = new JLabel("�������ݣ�");
	private JTextField edtrider_id = new JTextField(20);
	private JTextField edtrider_name = new JTextField(20);
	private JTextField edtrider_entrydate = new JPasswordField(20);
	private JTextField edtrider_identity = new JPasswordField(20);
	
	public FrmModifyRider(Frame f, String s, boolean b,FrmLogin dlgLogin) {
		super(f, s, b);
		toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
		toolBar.add(this.btnOk);
		toolBar.add(btnCancel);
		this.getContentPane().add(toolBar, BorderLayout.SOUTH);
		workPane.add(labelrider_id);
		workPane.add(edtrider_id);
		workPane.add(labelrider_name);
		workPane.add(edtrider_name);
		workPane.add(labelrider_identity);
		workPane.add(edtrider_identity);
		workPane.add(labelrider_entrydate);
		workPane.add(edtrider_entrydate);
		this.getContentPane().add(workPane, BorderLayout.CENTER);
		this.setSize(300, 180);
		this.btnCancel.addActionListener(this);
		this.btnOk.addActionListener(this);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.btnCancel)
			this.setVisible(false);
		if(e.getSource()==this.btnOk){
			String rider_name=this.edtrider_name.getText();
			String rider_entrydate=this.edtrider_entrydate.getText();
			String rider_identity=this.edtrider_identity.getText();
			
			try {
				PersonPlanUtil.RiderManager.addRider(rider_name,rider_entrydate,rider_identity);
				this.setVisible(false);
			} catch (BaseException e1) {
				JOptionPane.showMessageDialog(null, e1.getMessage(),"����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			
		}

	}


}


