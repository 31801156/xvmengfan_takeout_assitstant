/*
Navicat MySQL Data Transfer

Source Server         : zucc
Source Server Version : 50720
Source Host           : localhost:3306
Source Database       : takeout

Target Server Type    : MYSQL
Target Server Version : 50720
File Encoding         : 65001

Date: 2020-07-12 00:04:58
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for address
-- ----------------------------
DROP TABLE IF EXISTS `address`;
CREATE TABLE `address` (
  `address_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `province` varchar(20) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `area` varchar(20) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `user_name` varchar(20) DEFAULT NULL,
  `phonenumber` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`address_id`),
  KEY `FK_Reference_20` (`user_id`),
  CONSTRAINT `FK_Reference_20` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of address
-- ----------------------------
INSERT INTO `address` VALUES ('89', '1', '山东省', '泰安市', '东平县', '洲际泰', 'xmf', '178576');
INSERT INTO `address` VALUES ('1213', '1', '浙江省', '杭州市', '拱墅区', '浙江大学城市学院', 'xmf', '21371');
INSERT INTO `address` VALUES ('1323', '1', '北京市', '北京市', '房山区', '677', 'xmf', '657381');
INSERT INTO `address` VALUES ('3241', '1', '', '上海市', '上海市', '009', 'as', '41328');

-- ----------------------------
-- Table structure for coupon
-- ----------------------------
DROP TABLE IF EXISTS `coupon`;
CREATE TABLE `coupon` (
  `coupon_id` int(11) NOT NULL,
  `coupon_money` int(11) DEFAULT NULL,
  `coupon_require_number` int(11) DEFAULT NULL,
  `coupon_begin_time` datetime DEFAULT NULL,
  `coupon_end_time` datetime DEFAULT NULL,
  PRIMARY KEY (`coupon_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of coupon
-- ----------------------------
INSERT INTO `coupon` VALUES ('1', '1', '1', '2020-07-11 00:59:39', '2020-07-11 00:59:42');
INSERT INTO `coupon` VALUES ('2', '2', '2', '2020-07-11 01:02:33', '2020-07-11 01:02:36');

-- ----------------------------
-- Table structure for fullreduction
-- ----------------------------
DROP TABLE IF EXISTS `fullreduction`;
CREATE TABLE `fullreduction` (
  `fullreduction_id` int(11) NOT NULL,
  `fullreduction_money` int(11) DEFAULT NULL,
  `reduction_money` int(11) DEFAULT NULL,
  `with_coupon` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`fullreduction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of fullreduction
-- ----------------------------

-- ----------------------------
-- Table structure for getmoney
-- ----------------------------
DROP TABLE IF EXISTS `getmoney`;
CREATE TABLE `getmoney` (
  `rider_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `gettime` datetime DEFAULT NULL,
  `user_access` varchar(20) DEFAULT NULL,
  `income` double(11,0) DEFAULT NULL,
  PRIMARY KEY (`rider_id`,`order_id`),
  CONSTRAINT `FK_Reference_16` FOREIGN KEY (`rider_id`) REFERENCES `rider` (`rider_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of getmoney
-- ----------------------------
INSERT INTO `getmoney` VALUES ('1', '1', '2020-07-11 18:46:32', '1', '1');

-- ----------------------------
-- Table structure for gooddetails
-- ----------------------------
DROP TABLE IF EXISTS `gooddetails`;
CREATE TABLE `gooddetails` (
  `goods_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `goods_name` varchar(20) DEFAULT NULL,
  `goods_money` decimal(10,2) DEFAULT NULL,
  `coupon_money` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`goods_id`,`type_id`),
  KEY `FK_Reference_13` (`type_id`),
  CONSTRAINT `FK_Reference_13` FOREIGN KEY (`type_id`) REFERENCES `goodstype` (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of gooddetails
-- ----------------------------
INSERT INTO `gooddetails` VALUES ('1', '1', '1', '1.00', '1.00');
INSERT INTO `gooddetails` VALUES ('1', '2', '1', '12.00', '23.00');
INSERT INTO `gooddetails` VALUES ('2', '1', '432', '34.00', '4343.00');

-- ----------------------------
-- Table structure for goodsassess
-- ----------------------------
DROP TABLE IF EXISTS `goodsassess`;
CREATE TABLE `goodsassess` (
  `goods_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `content` varchar(200) DEFAULT NULL,
  `time` datetime NOT NULL,
  `level` int(11) DEFAULT NULL,
  `photo` longblob,
  PRIMARY KEY (`goods_id`,`store_id`,`user_id`,`time`),
  KEY `FK_Reference_14` (`store_id`),
  KEY `FK_Reference_15` (`user_id`),
  CONSTRAINT `FK_Reference_14` FOREIGN KEY (`store_id`) REFERENCES `store` (`store_id`),
  CONSTRAINT `FK_Reference_15` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of goodsassess
-- ----------------------------

-- ----------------------------
-- Table structure for goodstype
-- ----------------------------
DROP TABLE IF EXISTS `goodstype`;
CREATE TABLE `goodstype` (
  `type_id` int(11) NOT NULL,
  `type_name` varchar(20) DEFAULT NULL,
  `goods_count` int(11) DEFAULT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of goodstype
-- ----------------------------
INSERT INTO `goodstype` VALUES ('1', '1', '1');
INSERT INTO `goodstype` VALUES ('2', '2', '1');

-- ----------------------------
-- Table structure for goods_order
-- ----------------------------
DROP TABLE IF EXISTS `goods_order`;
CREATE TABLE `goods_order` (
  `order_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `user_id` varchar(20) DEFAULT NULL,
  `rider_id` varchar(20) DEFAULT NULL,
  `original_money` decimal(10,1) DEFAULT NULL,
  `end_money` decimal(10,1) DEFAULT NULL,
  `fullreduction_id` varchar(20) DEFAULT NULL,
  `coupon_id` varchar(20) DEFAULT NULL,
  `order_time` datetime DEFAULT NULL,
  `require_arrive_time` datetime DEFAULT NULL,
  `address_id` varchar(50) DEFAULT NULL,
  `order_status` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`order_id`,`store_id`),
  KEY `FK_Reference_23` (`store_id`),
  CONSTRAINT `FK_Reference_23` FOREIGN KEY (`store_id`) REFERENCES `store` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of goods_order
-- ----------------------------
INSERT INTO `goods_order` VALUES ('1', '1', '1', '1', '1.0', '1.0', '1', '1', '2020-07-11 01:05:03', '2020-07-11 01:05:07', '1', '1');

-- ----------------------------
-- Table structure for manager
-- ----------------------------
DROP TABLE IF EXISTS `manager`;
CREATE TABLE `manager` (
  `manager_id` int(11) NOT NULL,
  `manager_name` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`manager_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of manager
-- ----------------------------
INSERT INTO `manager` VALUES ('1', 'a', 'a');
INSERT INTO `manager` VALUES ('2', 'b', 'bx');
INSERT INTO `manager` VALUES ('3', 'c', 'cx');

-- ----------------------------
-- Table structure for orders_conpons
-- ----------------------------
DROP TABLE IF EXISTS `orders_conpons`;
CREATE TABLE `orders_conpons` (
  `user_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `conpon_id` int(11) NOT NULL,
  `conpon_require_number` int(11) DEFAULT NULL,
  `ordercount` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`,`store_id`,`conpon_id`),
  KEY `FK_Reference_22` (`store_id`),
  CONSTRAINT `FK_Reference_21` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `FK_Reference_22` FOREIGN KEY (`store_id`) REFERENCES `store` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of orders_conpons
-- ----------------------------
INSERT INTO `orders_conpons` VALUES ('1', '1', '1', '23', '23');

-- ----------------------------
-- Table structure for order_details
-- ----------------------------
DROP TABLE IF EXISTS `order_details`;
CREATE TABLE `order_details` (
  `order_id` int(11) NOT NULL,
  `goods_id` int(11) NOT NULL,
  `count` int(11) DEFAULT NULL,
  `money` decimal(10,1) DEFAULT NULL,
  `per_reduce_money` int(11) DEFAULT NULL,
  PRIMARY KEY (`order_id`,`goods_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of order_details
-- ----------------------------

-- ----------------------------
-- Table structure for relationship_manager_rider
-- ----------------------------
DROP TABLE IF EXISTS `relationship_manager_rider`;
CREATE TABLE `relationship_manager_rider` (
  `manager_id` int(11) NOT NULL,
  `rider_id` int(11) NOT NULL,
  PRIMARY KEY (`manager_id`,`rider_id`),
  KEY `FK_relationship_manager_rider2` (`rider_id`),
  CONSTRAINT `FK_relationship_manager_rider` FOREIGN KEY (`manager_id`) REFERENCES `manager` (`manager_id`),
  CONSTRAINT `FK_relationship_manager_rider2` FOREIGN KEY (`rider_id`) REFERENCES `rider` (`rider_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of relationship_manager_rider
-- ----------------------------

-- ----------------------------
-- Table structure for relationship_manager_store
-- ----------------------------
DROP TABLE IF EXISTS `relationship_manager_store`;
CREATE TABLE `relationship_manager_store` (
  `manager_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  PRIMARY KEY (`manager_id`,`store_id`),
  KEY `FK_relationship_manager_store2` (`store_id`),
  CONSTRAINT `FK_relationship_manager_store` FOREIGN KEY (`manager_id`) REFERENCES `manager` (`manager_id`),
  CONSTRAINT `FK_relationship_manager_store2` FOREIGN KEY (`store_id`) REFERENCES `store` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of relationship_manager_store
-- ----------------------------

-- ----------------------------
-- Table structure for relationship_manager_user
-- ----------------------------
DROP TABLE IF EXISTS `relationship_manager_user`;
CREATE TABLE `relationship_manager_user` (
  `manager_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`manager_id`,`user_id`),
  KEY `FK_relationship_manager_user2` (`user_id`),
  CONSTRAINT `FK_relationship_manager_user` FOREIGN KEY (`manager_id`) REFERENCES `manager` (`manager_id`),
  CONSTRAINT `FK_relationship_manager_user2` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of relationship_manager_user
-- ----------------------------

-- ----------------------------
-- Table structure for relationship_store_coupon
-- ----------------------------
DROP TABLE IF EXISTS `relationship_store_coupon`;
CREATE TABLE `relationship_store_coupon` (
  `coupon_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  PRIMARY KEY (`coupon_id`,`store_id`),
  KEY `FK_relationship_store_coupon2` (`store_id`),
  CONSTRAINT `FK_relationship_store_coupon` FOREIGN KEY (`coupon_id`) REFERENCES `coupon` (`coupon_id`),
  CONSTRAINT `FK_relationship_store_coupon2` FOREIGN KEY (`store_id`) REFERENCES `store` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of relationship_store_coupon
-- ----------------------------
INSERT INTO `relationship_store_coupon` VALUES ('1', '3');

-- ----------------------------
-- Table structure for relationship_store_fullreduction
-- ----------------------------
DROP TABLE IF EXISTS `relationship_store_fullreduction`;
CREATE TABLE `relationship_store_fullreduction` (
  `store_id` int(11) NOT NULL,
  `fullreduction_id` int(11) NOT NULL,
  PRIMARY KEY (`store_id`,`fullreduction_id`),
  KEY `FK_relationship_store_fullreduction2` (`fullreduction_id`),
  CONSTRAINT `FK_relationship_store_fullreduction` FOREIGN KEY (`store_id`) REFERENCES `store` (`store_id`),
  CONSTRAINT `FK_relationship_store_fullreduction2` FOREIGN KEY (`fullreduction_id`) REFERENCES `fullreduction` (`fullreduction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of relationship_store_fullreduction
-- ----------------------------

-- ----------------------------
-- Table structure for relationship_store_goodstype
-- ----------------------------
DROP TABLE IF EXISTS `relationship_store_goodstype`;
CREATE TABLE `relationship_store_goodstype` (
  `store_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  PRIMARY KEY (`store_id`,`type_id`),
  KEY `FK_relationship_store_goodstype2` (`type_id`),
  CONSTRAINT `FK_relationship_store_goodstype` FOREIGN KEY (`store_id`) REFERENCES `store` (`store_id`),
  CONSTRAINT `FK_relationship_store_goodstype2` FOREIGN KEY (`type_id`) REFERENCES `goodstype` (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of relationship_store_goodstype
-- ----------------------------
INSERT INTO `relationship_store_goodstype` VALUES ('1', '1');
INSERT INTO `relationship_store_goodstype` VALUES ('2', '1');
INSERT INTO `relationship_store_goodstype` VALUES ('3', '1');
INSERT INTO `relationship_store_goodstype` VALUES ('1', '2');
INSERT INTO `relationship_store_goodstype` VALUES ('2', '2');
INSERT INTO `relationship_store_goodstype` VALUES ('3', '2');

-- ----------------------------
-- Table structure for rider
-- ----------------------------
DROP TABLE IF EXISTS `rider`;
CREATE TABLE `rider` (
  `rider_id` int(11) NOT NULL,
  `rider_name` varchar(20) DEFAULT NULL,
  `rider_entrydate` datetime DEFAULT NULL,
  `rider_identity` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`rider_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of rider
-- ----------------------------
INSERT INTO `rider` VALUES ('1', '1', '2020-07-11 01:46:26', '新手');
INSERT INTO `rider` VALUES ('2', '2', '2020-07-12 00:02:13', '新手');

-- ----------------------------
-- Table structure for store
-- ----------------------------
DROP TABLE IF EXISTS `store`;
CREATE TABLE `store` (
  `store_id` int(11) NOT NULL,
  `store_name` varchar(20) DEFAULT NULL,
  `store_level` decimal(2,1) DEFAULT NULL,
  `store_per_consumption` int(11) DEFAULT NULL,
  `store_totalsales` int(11) DEFAULT NULL,
  PRIMARY KEY (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of store
-- ----------------------------
INSERT INTO `store` VALUES ('1', '华莱士', '4.5', '67', '474');
INSERT INTO `store` VALUES ('2', '炸鸡', '4.7', '45', '237');
INSERT INTO `store` VALUES ('3', '粥饭世家', '4.1', '23', '1243');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(20) DEFAULT NULL,
  `sex` varchar(4) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `phonenumber` varchar(20) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `registration_time` datetime DEFAULT NULL,
  `member` tinyint(1) DEFAULT NULL,
  `member_end_time` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'xmf', '男', 'a', '1735', '12384@', '北京', '2020-07-11 00:57:35', '1', '2020-09-01 00:03:49');
INSERT INTO `user` VALUES ('2', 'lsm', '女', '2', '143554', '34456@', '杭州', '2020-07-10 20:57:57', '0', null);
INSERT INTO `user` VALUES ('3', 'lxj', '女', '3', '6546457', null, '济南', '2020-07-10 20:58:06', '1', '2024-01-12 00:04:06');
INSERT INTO `user` VALUES ('4', 'cz', '男', '3', '5477', null, '上海', '2020-07-10 20:58:23', '1', '2020-09-01 00:04:12');
INSERT INTO `user` VALUES ('5', 'lxk', '女', '4', '22456', null, '广州', '2020-07-10 20:58:37', '0', null);

-- ----------------------------
-- Table structure for usercoupon
-- ----------------------------
DROP TABLE IF EXISTS `usercoupon`;
CREATE TABLE `usercoupon` (
  `user_id` int(11) NOT NULL,
  `coupon_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `coupon_money` int(11) DEFAULT NULL,
  `coupon_count` int(11) DEFAULT NULL,
  `coupon_end_time` date DEFAULT NULL,
  PRIMARY KEY (`user_id`,`coupon_id`,`store_id`),
  KEY `FK_Reference_18` (`coupon_id`),
  KEY `FK_Reference_19` (`store_id`),
  CONSTRAINT `FK_Reference_17` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `FK_Reference_18` FOREIGN KEY (`coupon_id`) REFERENCES `coupon` (`coupon_id`),
  CONSTRAINT `FK_Reference_19` FOREIGN KEY (`store_id`) REFERENCES `store` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of usercoupon
-- ----------------------------
INSERT INTO `usercoupon` VALUES ('1', '1', '1', '1', '1', '2020-07-11');
